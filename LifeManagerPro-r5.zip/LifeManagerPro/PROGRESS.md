# Progress (the user says "continue" to resume from here)

## Phase 1 - DONE
- Gradle project, GitHub Actions APK build (logic in ci/build.sh), fixed signing key
- Full Room schema (every module's tables, version 1), DataStore settings
- Bangla / English (in-app switch), light / dark / system theme
- Home dashboard, Daily Planner (today / tomorrow / upcoming / previous / calendar, search,
  filters, categories), Settings (language, theme, name, PIN, fingerprint/face, screenshot privacy)

## Phase 2 - DONE (revision r4)
- Habits: daily / weekly / monthly targets, streaks, completion %, calendar history (tap a day to
  mark/unmark), archive instead of delete, quick ideas (reading, exercise, water, ...)
- Goals: 7 categories, milestones (progress follows milestones), progress slider + history log,
  active / completed / archived tabs, archive keeps all history
- Reminders: exact alarms, daily / weekly / monthly / custom repeat, survives restart (boot and
  clock-change receivers + 6-hour safety worker), missed-reminder notice, notification and
  battery / Xiaomi autostart helpers
- Task reminders (at start / 10 / 30 / 60 minutes before)
- Home dashboard now shows habits, goals and upcoming reminders; 5 bottom tabs

## Phase 3 - DONE (revision r5)
- Diary: entries with mood, date/time and photos, search, month calendar, edit/delete,
  PDF export (whole diary, selected day, or one entry; Bangla text)
- Time tracker: start/stop timer that survives closing the app, manual entries, categories,
  daily / weekly / monthly summary
- Focus timer: 25 / 5 minutes (changeable), alarm when time is up, session history
- Money (৳): income and expense by category, monthly budget and remaining budget, savings goals with
  deposit history, every month kept separately, monthly report with PDF export
- Home dashboard: quick access (focus, diary, money) and this month's money

## Phase 4: Islamic life (prayer log chosen manually, Quran tracker, amal, good and bad deeds journal)
   / 15-day self review + improvement letter (PDF)
## Phase 5: Personal library / Life Score (Islamic activities excluded) / Analytics + PDF reports
   (Bangla fonts) / Backup + Restore (safety backup, no duplicates, no silent overwrite) / polish
