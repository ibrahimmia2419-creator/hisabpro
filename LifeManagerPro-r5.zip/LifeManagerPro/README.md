# Life Manager Pro

Offline-first personal life manager for Android (Kotlin, Jetpack Compose, Material 3, Room, MVVM,
Coroutines, DataStore, WorkManager, Navigation Compose). Minimum Android 8.0 (API 26).
All data stays on the phone. Bangla and English, light / dark / system theme.

## How the APK is built (no computer needed)
1. Upload `LifeManagerPro.zip` to the root of the GitHub repository.
2. Create the file `.github/workflows/build-apk.yml` (copy it from `docs/build-apk.yml`).
   The real build steps live in `ci/build.sh` inside the zip, so this small file rarely changes.
3. GitHub Actions builds the app. Open the repository, then Releases, then download `LifeManagerPro.apk`.
4. Install the APK on the phone. Every new build installs over the old one and keeps your data
   (the signing key is created once and stored in the repository under `keystore/`).

## Database
The complete database (all planned modules) is defined from version 1 in
`data/Entities.kt`, so later versions only add screens and never lose data.

See `PROGRESS.md` for what is finished and what comes next.
