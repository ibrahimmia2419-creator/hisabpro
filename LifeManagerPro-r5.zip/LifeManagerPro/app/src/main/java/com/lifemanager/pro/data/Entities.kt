package com.lifemanager.pro.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

/*
 * FULL database schema (version 1). Every table of the finished app is declared here
 * from day one, so later versions of the app only add screens and never lose data.
 * All primary keys are UUID strings (or deterministic keys) so a backup can be merged
 * back without creating duplicates.
 */

@Serializable
@Entity(tableName = "tasks", indices = [Index("epochDay"), Index("status")])
data class TaskEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String = "",
    val epochDay: Long,
    val startMin: Int = -1,
    val endMin: Int = -1,
    val priority: Int = 1,
    val category: String = "personal",
    val status: String = "PENDING",
    val remindBefore: Int = -1,
    val completedAt: Long = 0L,
    val createdAt: Long,
    val updatedAt: Long
)

@Serializable
@Entity(tableName = "goals", indices = [Index("archived")])
data class GoalEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String = "",
    val category: String = "personal",
    val startEpochDay: Long,
    val targetEpochDay: Long = 0L,
    val progress: Int = 0,
    val status: String = "ACTIVE",
    val notes: String = "",
    val archived: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

@Serializable
@Entity(tableName = "milestones", indices = [Index("goalId")])
data class MilestoneEntity(
    @PrimaryKey val id: String,
    val goalId: String,
    val title: String,
    val done: Boolean = false,
    val sortOrder: Int = 0,
    val createdAt: Long,
    val updatedAt: Long
)

@Serializable
@Entity(tableName = "goal_logs", indices = [Index("goalId")])
data class GoalLogEntity(
    @PrimaryKey val id: String,
    val goalId: String,
    val epochDay: Long,
    val progress: Int,
    val note: String = "",
    val createdAt: Long
)

@Serializable
@Entity(tableName = "habits")
data class HabitEntity(
    @PrimaryKey val id: String,
    val name: String,
    val emoji: String = "✅",
    val frequency: String = "DAILY",
    val target: Int = 1,
    val archived: Boolean = false,
    val sortOrder: Int = 0,
    val createdAt: Long,
    val updatedAt: Long
)

@Serializable
@Entity(tableName = "habit_logs", indices = [Index("habitId"), Index("epochDay")])
data class HabitLogEntity(
    @PrimaryKey val id: String,
    val habitId: String,
    val epochDay: Long,
    val createdAt: Long
)

@Serializable
@Entity(tableName = "reminders", indices = [Index("triggerAt")])
data class ReminderEntity(
    @PrimaryKey val id: String,
    val title: String,
    val note: String = "",
    val triggerAt: Long,
    val repeatMode: String = "NONE",
    val intervalDays: Int = 1,
    val enabled: Boolean = true,
    val linkedTaskId: String = "",
    val createdAt: Long,
    val updatedAt: Long
)

@Serializable
@Entity(tableName = "diary", indices = [Index("epochDay")])
data class DiaryEntity(
    @PrimaryKey val id: String,
    val title: String = "",
    val body: String = "",
    val mood: Int = 0,
    val epochDay: Long,
    val timeMin: Int = 0,
    val photos: String = "",
    val createdAt: Long,
    val updatedAt: Long
)

@Serializable
@Entity(tableName = "time_entries", indices = [Index("epochDay")])
data class TimeEntryEntity(
    @PrimaryKey val id: String,
    val title: String,
    val category: String = "other",
    val startAt: Long,
    val endAt: Long,
    val seconds: Long,
    val manual: Boolean = false,
    val epochDay: Long,
    val createdAt: Long,
    val updatedAt: Long
)

@Serializable
@Entity(tableName = "focus_sessions", indices = [Index("epochDay")])
data class FocusSessionEntity(
    @PrimaryKey val id: String,
    val label: String = "",
    val startAt: Long,
    val endAt: Long,
    val plannedMin: Int,
    val actualMin: Int,
    val kind: String = "FOCUS",
    val completed: Boolean = true,
    val epochDay: Long
)

@Serializable
@Entity(tableName = "txns", indices = [Index("monthKey"), Index("epochDay")])
data class TxnEntity(
    @PrimaryKey val id: String,
    val type: String,
    val amount: Double,
    val category: String = "other",
    val note: String = "",
    val epochDay: Long,
    val monthKey: String,
    val createdAt: Long,
    val updatedAt: Long
)

@Serializable
@Entity(tableName = "budgets")
data class BudgetEntity(
    @PrimaryKey val id: String,
    val monthKey: String,
    val amount: Double,
    val updatedAt: Long
)

@Serializable
@Entity(tableName = "savings_goals")
data class SavingsGoalEntity(
    @PrimaryKey val id: String,
    val name: String,
    val target: Double,
    val targetEpochDay: Long = 0L,
    val archived: Boolean = false,
    val createdAt: Long,
    val updatedAt: Long
)

@Serializable
@Entity(tableName = "savings_entries", indices = [Index("goalId")])
data class SavingsEntryEntity(
    @PrimaryKey val id: String,
    val goalId: String,
    val amount: Double,
    val epochDay: Long,
    val note: String = "",
    val createdAt: Long
)

@Serializable
@Entity(tableName = "prayers", indices = [Index("epochDay")])
data class PrayerEntity(
    @PrimaryKey val id: String,
    val epochDay: Long,
    val prayer: String,
    val status: String,
    val updatedAt: Long
)

@Serializable
@Entity(tableName = "quran_logs", indices = [Index("epochDay")])
data class QuranLogEntity(
    @PrimaryKey val id: String,
    val epochDay: Long,
    val surah: Int,
    val fromAyah: Int,
    val toAyah: Int,
    val startIdx: Int,
    val endIdx: Int,
    val minutes: Int = 0,
    val note: String = "",
    val createdAt: Long,
    val updatedAt: Long
)

@Serializable
@Entity(tableName = "amals")
data class AmalEntity(
    @PrimaryKey val id: String,
    val name: String,
    val slug: String = "",
    val target: Int = 1,
    val archived: Boolean = false,
    val sortOrder: Int = 0,
    val createdAt: Long,
    val updatedAt: Long
)

@Serializable
@Entity(tableName = "amal_logs", indices = [Index("amalId"), Index("epochDay")])
data class AmalLogEntity(
    @PrimaryKey val id: String,
    val amalId: String,
    val epochDay: Long,
    val cnt: Int,
    val updatedAt: Long
)

@Serializable
@Entity(tableName = "deeds", indices = [Index("epochDay")])
data class DeedEntity(
    @PrimaryKey val id: String,
    val epochDay: Long,
    val kind: String,
    val content: String,
    val createdAt: Long,
    val updatedAt: Long
)

@Serializable
@Entity(tableName = "reviews")
data class ReviewEntity(
    @PrimaryKey val id: String,
    val startEpochDay: Long,
    val endEpochDay: Long,
    val learned: String = "",
    val experiences: String = "",
    val improvements: String = "",
    val nextGoals: String = "",
    val notes: String = "",
    val summary: String = "",
    val createdAt: Long,
    val updatedAt: Long
)

@Serializable
@Entity(tableName = "letters", indices = [Index("reviewId")])
data class LetterEntity(
    @PrimaryKey val id: String,
    val reviewId: String = "",
    val title: String,
    val body: String,
    val createdAt: Long,
    val updatedAt: Long
)

@Serializable
@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey val id: String,
    val title: String,
    val body: String = "",
    val category: String = "general",
    val tags: String = "",
    val favorite: Boolean = false,
    val files: String = "",
    val createdAt: Long,
    val updatedAt: Long
)

@Serializable
@Entity(tableName = "categories", indices = [Index("kind")])
data class CategoryEntity(
    @PrimaryKey val id: String,
    val kind: String,
    val name: String,
    val emoji: String = "🏷️",
    val custom: Boolean = false,
    val archived: Boolean = false,
    val sortOrder: Int = 0
)
