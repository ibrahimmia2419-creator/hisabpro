@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.lifemanager.pro.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController
import com.lifemanager.pro.R
import com.lifemanager.pro.data.AppSettings
import com.lifemanager.pro.data.BootPrefs
import com.lifemanager.pro.data.Graph
import com.lifemanager.pro.security.Biometrics
import com.lifemanager.pro.ui.components.AppCard
import com.lifemanager.pro.ui.components.AppScaffold
import com.lifemanager.pro.ui.components.ChoiceChips
import com.lifemanager.pro.util.applySecure
import com.lifemanager.pro.util.findActivity
import kotlinx.coroutines.launch

private enum class PinMode { SET, CHANGE, REMOVE }

private fun launchIntent(ctx: Context, intent: Intent) {
    try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
    } catch (e: Exception) {
        // Some phones do not have every settings page; ignore silently.
    }
}

@Composable
fun SettingsScreen(nav: NavHostController) {
    val ctx = LocalContext.current
    val prefs = Graph.prefs
    val s by prefs.settings.collectAsState(initial = AppSettings())
    val scope = rememberCoroutineScope()

    var nameText by remember(s.userName) { mutableStateOf(s.userName) }
    var pinDialog by remember { mutableStateOf<PinMode?>(null) }
    val bioAvailable = remember { Biometrics.available(ctx) }

    val notifInitial = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
        PackageManager.PERMISSION_GRANTED
    var notifOk by remember { mutableStateOf(notifInitial) }
    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> notifOk = granted }

    val version = remember {
        try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    AppScaffold(
        title = stringResource(R.string.settings_title),
        onBack = { nav.popBackStack() }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SettingsCard(stringResource(R.string.set_appearance)) {
                Text(stringResource(R.string.set_language), style = MaterialTheme.typography.labelLarge)
                ChoiceChips(
                    options = listOf("bn", "en"),
                    selected = s.lang,
                    onSelect = { code ->
                        scope.launch {
                            prefs.setLang(code)
                            BootPrefs.applyAppearance(ctx)
                        }
                    }
                ) { code -> if (code == "bn") stringResource(R.string.lang_bn) else stringResource(R.string.lang_en) }

                Text(stringResource(R.string.set_theme), style = MaterialTheme.typography.labelLarge)
                ChoiceChips(
                    options = listOf("system", "light", "dark"),
                    selected = s.theme,
                    onSelect = { mode ->
                        scope.launch {
                            prefs.setTheme(mode)
                            BootPrefs.applyAppearance(ctx)
                        }
                    }
                ) { mode ->
                    when (mode) {
                        "light" -> stringResource(R.string.theme_light)
                        "dark" -> stringResource(R.string.theme_dark)
                        else -> stringResource(R.string.theme_system)
                    }
                }
            }

            SettingsCard(stringResource(R.string.set_profile)) {
                OutlinedTextField(
                    value = nameText,
                    onValueChange = { nameText = it },
                    singleLine = true,
                    label = { Text(stringResource(R.string.set_name)) },
                    supportingText = { Text(stringResource(R.string.set_name_hint)) },
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = { scope.launch { prefs.setName(nameText.trim()) } }) {
                    Text(stringResource(R.string.save))
                }
            }

            SettingsCard(stringResource(R.string.set_security)) {
                Text(
                    stringResource(if (s.pinSet) R.string.pin_on else R.string.pin_off),
                    style = MaterialTheme.typography.bodyMedium
                )
                if (!s.pinSet) {
                    Button(onClick = { pinDialog = PinMode.SET }) {
                        Text(stringResource(R.string.pin_set))
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { pinDialog = PinMode.CHANGE }) {
                            Text(stringResource(R.string.pin_change))
                        }
                        OutlinedButton(onClick = { pinDialog = PinMode.REMOVE }) {
                            Text(stringResource(R.string.pin_remove))
                        }
                    }
                }
                SwitchRow(
                    title = stringResource(R.string.set_biometric),
                    subtitle = stringResource(
                        if (!bioAvailable) R.string.biometric_unavailable
                        else if (!s.pinSet) R.string.biometric_needs_pin
                        else R.string.biometric_hint
                    ),
                    checked = s.biometric,
                    enabled = s.pinSet && bioAvailable,
                    onChange = { v -> scope.launch { prefs.setBiometric(v) } }
                )
                SwitchRow(
                    title = stringResource(R.string.set_secure),
                    subtitle = stringResource(R.string.set_secure_hint),
                    checked = s.secure,
                    enabled = true,
                    onChange = { v ->
                        scope.launch { prefs.setSecure(v) }
                        ctx.findActivity()?.applySecure(v)
                    }
                )
            }

            SettingsCard(stringResource(R.string.set_notifications)) {
                if (!notifOk) {
                    Text(
                        stringResource(R.string.notif_not_allowed),
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Button(onClick = {
                        if (Build.VERSION.SDK_INT >= 33) {
                            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }) { Text(stringResource(R.string.notif_allow)) }
                }
                OutlinedButton(onClick = {
                    val i = Intent(AndroidSettings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(AndroidSettings.EXTRA_APP_PACKAGE, ctx.packageName)
                    launchIntent(ctx, i)
                }) { Text(stringResource(R.string.set_notif_open)) }

                Text(
                    stringResource(R.string.set_battery_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        launchIntent(ctx, Intent(AndroidSettings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    }) { Text(stringResource(R.string.set_battery)) }
                    OutlinedButton(onClick = {
                        val i = Intent(
                            AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:" + ctx.packageName)
                        )
                        launchIntent(ctx, i)
                    }) { Text(stringResource(R.string.set_app_info)) }
                }
            }

            SettingsCard(stringResource(R.string.set_about)) {
                Text(stringResource(R.string.app_name), fontWeight = FontWeight.Bold)
                Text(
                    stringResource(R.string.about_version) + ": " + version,
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    stringResource(R.string.about_text),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    val mode = pinDialog
    if (mode != null) {
        PinDialog(mode = mode, onDismiss = { pinDialog = null })
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            content()
        }
    }
}

@Composable
private fun SwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
private fun PinField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { v -> if (v.length <= 6 && v.all { it.isDigit() }) onChange(v) },
        singleLine = true,
        label = { Text(label) },
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun PinDialog(mode: PinMode, onDismiss: () -> Unit) {
    val prefs = Graph.prefs
    val scope = rememberCoroutineScope()
    var cur by remember { mutableStateOf("") }
    var p1 by remember { mutableStateOf("") }
    var p2 by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    val msgShort = stringResource(R.string.pin_too_short)
    val msgMismatch = stringResource(R.string.pin_mismatch)
    val msgWrong = stringResource(R.string.pin_wrong)
    val needCurrent = mode != PinMode.SET
    val needNew = mode != PinMode.REMOVE
    val titleRes = when (mode) {
        PinMode.SET -> R.string.pin_set
        PinMode.CHANGE -> R.string.pin_change
        PinMode.REMOVE -> R.string.pin_remove
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(titleRes)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (needCurrent) {
                    PinField(stringResource(R.string.pin_current), cur) { cur = it }
                }
                if (needNew) {
                    PinField(stringResource(R.string.pin_new), p1) { p1 = it }
                    PinField(stringResource(R.string.pin_confirm), p2) { p2 = it }
                }
                if (err.isNotEmpty()) {
                    Text(err, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                scope.launch {
                    if (needCurrent && !prefs.verifyPin(cur)) {
                        err = msgWrong
                        return@launch
                    }
                    if (needNew) {
                        if (p1.length < 4) {
                            err = msgShort
                            return@launch
                        }
                        if (p1 != p2) {
                            err = msgMismatch
                            return@launch
                        }
                        prefs.setPin(p1)
                    } else {
                        prefs.clearPin()
                    }
                    onDismiss()
                }
            }) { Text(stringResource(R.string.save)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        }
    )
}
