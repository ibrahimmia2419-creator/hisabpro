package com.lifemanager.pro.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Brand = Color(0xFF0F766E)
val BrandLight = Color(0xFF14B8A6)
val Success = Color(0xFF16A34A)
val Warning = Color(0xFFD97706)
val Danger = Color(0xFFDC2626)
val Info = Color(0xFF2563EB)
val Muted = Color(0xFF8A9A97)

private val LightColors = lightColorScheme(
    primary = Brand,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCDF3EC),
    onPrimaryContainer = Color(0xFF00302B),
    secondary = Color(0xFF4F46E5),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE3E7FF),
    onSecondaryContainer = Color(0xFF1B1A57),
    tertiary = Color(0xFFB45309),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFE6BD),
    onTertiaryContainer = Color(0xFF3A2200),
    background = Color(0xFFF4F7F6),
    onBackground = Color(0xFF0F1A19),
    surface = Color.White,
    onSurface = Color(0xFF0F1A19),
    surfaceVariant = Color(0xFFE4ECEA),
    onSurfaceVariant = Color(0xFF42524F),
    outline = Color(0xFFB2C1BE),
    error = Danger,
    onError = Color.White
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF3FD2C0),
    onPrimary = Color(0xFF00201C),
    primaryContainer = Color(0xFF0B4F49),
    onPrimaryContainer = Color(0xFFB9F4EA),
    secondary = Color(0xFFA5B4FC),
    onSecondary = Color(0xFF1B1A57),
    secondaryContainer = Color(0xFF2F2E7A),
    onSecondaryContainer = Color(0xFFE3E7FF),
    tertiary = Color(0xFFFFB84D),
    onTertiary = Color(0xFF3A2200),
    tertiaryContainer = Color(0xFF5A3600),
    onTertiaryContainer = Color(0xFFFFE6BD),
    background = Color(0xFF0D1514),
    onBackground = Color(0xFFE3ECEA),
    surface = Color(0xFF16211F),
    onSurface = Color(0xFFE3ECEA),
    surfaceVariant = Color(0xFF223330),
    onSurfaceVariant = Color(0xFFA9BBB7),
    outline = Color(0xFF4A5D59),
    error = Color(0xFFF87171),
    onError = Color(0xFF3A0000)
)

private val AppTypography = Typography(
    headlineSmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 24.sp, lineHeight = 32.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 20.sp, lineHeight = 28.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 24.sp),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 22.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 18.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 18.sp),
    labelSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 16.sp)
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp)
)

@Composable
fun LifeTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}
