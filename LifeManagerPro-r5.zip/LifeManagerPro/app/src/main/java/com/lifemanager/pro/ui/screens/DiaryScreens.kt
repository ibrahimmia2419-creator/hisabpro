@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.lifemanager.pro.ui.screens

import android.app.Application
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.lifemanager.pro.R
import com.lifemanager.pro.data.DiaryEntity
import com.lifemanager.pro.data.Graph
import com.lifemanager.pro.pdf.PdfBuilder
import com.lifemanager.pro.pdf.PdfExport
import com.lifemanager.pro.ui.components.AppCard
import com.lifemanager.pro.ui.components.AppScaffold
import com.lifemanager.pro.ui.components.ChoiceChips
import com.lifemanager.pro.ui.components.ConfirmDialog
import com.lifemanager.pro.ui.components.EmptyState
import com.lifemanager.pro.ui.components.FileImage
import com.lifemanager.pro.ui.components.MOOD_EMOJI
import com.lifemanager.pro.ui.components.MonthGrid
import com.lifemanager.pro.ui.components.PickerField
import com.lifemanager.pro.ui.components.moodLabel
import com.lifemanager.pro.ui.components.showDatePicker
import com.lifemanager.pro.ui.components.showTimePicker
import com.lifemanager.pro.ui.nav.Routes
import com.lifemanager.pro.util.Attachments
import com.lifemanager.pro.util.D
import com.lifemanager.pro.util.Fmt
import com.lifemanager.pro.util.currentLocale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.YearMonth
import java.util.Locale

class DiaryViewModel(app: Application) : AndroidViewModel(app) {
    val entries: StateFlow<List<DiaryEntity>> =
        Graph.repo.diary.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())
}

class DiaryEditViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Graph.repo

    suspend fun load(id: String): DiaryEntity? = repo.getDiary(id)

    fun save(e: DiaryEntity, removedPhotos: List<String>, onDone: () -> Unit) {
        viewModelScope.launch {
            repo.saveDiary(e)
            val app = getApplication<Application>()
            for (n in removedPhotos) Attachments.delete(app, n)
            onDone()
        }
    }

    fun delete(e: DiaryEntity, onDone: () -> Unit) {
        viewModelScope.launch {
            repo.deleteDiary(e.id)
            val app = getApplication<Application>()
            for (n in Attachments.split(e.photos)) Attachments.delete(app, n)
            onDone()
        }
    }

    fun importPhotos(uris: List<Uri>, onDone: (List<String>) -> Unit) {
        viewModelScope.launch {
            val app = getApplication<Application>()
            val names = withContext(Dispatchers.IO) { uris.mapNotNull { Attachments.importImage(app, it) } }
            onDone(names)
        }
    }
}

/** Builds the PDF content for some diary entries (oldest first). */
fun buildDiaryPdf(
    list: List<DiaryEntity>,
    loc: Locale,
    heading: String,
    moodNames: List<String>
): (PdfBuilder) -> Unit = { b ->
    b.title(heading)
    val sorted = list.sortedWith(compareBy<DiaryEntity>({ it.epochDay }, { it.timeMin }))
    for (e in sorted) {
        val mood = if (e.mood in 1..5) MOOD_EMOJI[e.mood] + " " + moodNames[e.mood] else ""
        var head = Fmt.date(e.epochDay, loc) + " · " + Fmt.time(e.timeMin, loc)
        if (mood.isNotEmpty()) head += " · " + mood
        b.heading(head)
        if (e.title.isNotBlank()) b.boldLine(e.title)
        if (e.body.isNotBlank()) b.paragraph(e.body)
        b.rule()
    }
}

@Composable
fun DiaryScreen(nav: NavHostController, vm: DiaryViewModel = viewModel()) {
    val entries by vm.entries.collectAsState()
    val ctx = LocalContext.current
    val loc = currentLocale()
    val scope = rememberCoroutineScope()
    var query by rememberSaveable { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var calendar by remember { mutableStateOf(false) }
    var selDay by remember { mutableStateOf(-1L) }
    var month by remember { mutableStateOf(YearMonth.now()) }
    var menu by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<((PdfBuilder) -> Unit)?>(null) }

    val moodNames = listOf(
        "", stringResource(R.string.mood_1), stringResource(R.string.mood_2), stringResource(R.string.mood_3),
        stringResource(R.string.mood_4), stringResource(R.string.mood_5)
    )
    val heading = stringResource(R.string.diary_title)
    val okMsg = stringResource(R.string.pdf_saved)
    val failMsg = stringResource(R.string.pdf_failed)
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val fill = pending
        pending = null
        if (uri != null && fill != null) {
            scope.launch {
                val ok = PdfExport.save(ctx, uri, heading, loc, fill)
                Toast.makeText(ctx, if (ok) okMsg else failMsg, Toast.LENGTH_SHORT).show()
            }
        }
    }

    val shown = entries.filter { e ->
        (selDay < 0L || e.epochDay == selDay) &&
            (query.isBlank() || e.title.contains(query, ignoreCase = true) || e.body.contains(query, ignoreCase = true))
    }
    val marked = remember(entries) { entries.map { it.epochDay }.toSet() }

    AppScaffold(
        title = stringResource(R.string.diary_title),
        onBack = { nav.popBackStack() },
        actions = {
            IconButton(onClick = {
                searching = !searching
                if (!searching) query = ""
            }) { Icon(Icons.Default.Search, contentDescription = null) }
            TextButton(onClick = { calendar = !calendar }) { Text("📅") }
            Box {
                TextButton(onClick = { menu = true }) { Text("PDF") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.diary_export_all)) },
                        onClick = {
                            menu = false
                            pending = buildDiaryPdf(entries, loc, heading, moodNames)
                            launcher.launch("life-manager-diary.pdf")
                        }
                    )
                    if (selDay >= 0L) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.diary_export_day)) },
                            onClick = {
                                menu = false
                                pending = buildDiaryPdf(entries.filter { it.epochDay == selDay }, loc, heading, moodNames)
                                launcher.launch("life-manager-diary-day.pdf")
                            }
                        )
                    }
                }
            }
        },
        fab = {
            FloatingActionButton(onClick = { nav.navigate(Routes.diaryEdit("new")) }) {
                Icon(Icons.Default.Add, contentDescription = null)
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (searching) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    placeholder = { Text(stringResource(R.string.diary_search_hint)) },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
            if (calendar) {
                Box(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    MonthGrid(
                        month = month,
                        selected = selDay,
                        marked = marked,
                        onSelect = { d -> selDay = if (selDay == d) -1L else d },
                        onPrev = { month = month.minusMonths(1) },
                        onNext = { month = month.plusMonths(1) }
                    )
                }
            }
            if (selDay >= 0L) {
                Row(
                    Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        Fmt.dateLong(selDay, loc),
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.titleMedium
                    )
                    TextButton(onClick = { selDay = -1L }) { Text(stringResource(R.string.clear)) }
                }
            }
            if (shown.isEmpty()) {
                EmptyState("📔", stringResource(R.string.diary_empty), Modifier.weight(1f))
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(shown, key = { it.id }) { e ->
                        DiaryCard(e, loc) { nav.navigate(Routes.diaryEdit(e.id)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun DiaryCard(e: DiaryEntity, loc: Locale, onOpen: () -> Unit) {
    val photoCount = Attachments.split(e.photos).size
    AppCard(Modifier.fillMaxWidth(), onClick = onOpen) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    Fmt.date(e.epochDay, loc) + " · " + Fmt.time(e.timeMin, loc),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )
                if (e.mood in 1..5) {
                    Text(MOOD_EMOJI[e.mood], fontSize = 20.sp)
                }
            }
            if (e.title.isNotBlank()) {
                Text(
                    e.title,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (e.body.isNotBlank()) {
                Text(
                    e.body,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (photoCount > 0) {
                Text("📷 " + Fmt.num(photoCount, loc), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun DiaryEditScreen(nav: NavHostController, id: String, vm: DiaryEditViewModel = viewModel()) {
    val ctx = LocalContext.current
    val loc = currentLocale()
    val scope = rememberCoroutineScope()
    val isNew = id == "new"
    var original by remember { mutableStateOf<DiaryEntity?>(null) }
    var title by rememberSaveable { mutableStateOf("") }
    var body by rememberSaveable { mutableStateOf("") }
    var mood by rememberSaveable { mutableStateOf(0) }
    var day by rememberSaveable { mutableStateOf(D.today()) }
    var timeMin by rememberSaveable { mutableStateOf(D.minuteOfDay(D.now())) }
    var photos by rememberSaveable { mutableStateOf("") }
    var added by rememberSaveable { mutableStateOf("") }
    var showErr by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<((PdfBuilder) -> Unit)?>(null) }

    LaunchedEffect(id) {
        if (!isNew) {
            val e = vm.load(id)
            if (e != null) {
                original = e
                if (title.isEmpty() && body.isEmpty()) {
                    title = e.title
                    body = e.body
                    mood = e.mood
                    day = e.epochDay
                    timeMin = e.timeMin
                    photos = e.photos
                }
            }
        }
    }

    val moodNames = listOf(
        "", stringResource(R.string.mood_1), stringResource(R.string.mood_2), stringResource(R.string.mood_3),
        stringResource(R.string.mood_4), stringResource(R.string.mood_5)
    )
    val heading = stringResource(R.string.diary_title)
    val okMsg = stringResource(R.string.pdf_saved)
    val failMsg = stringResource(R.string.pdf_failed)
    val pdfLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val fill = pending
        pending = null
        if (uri != null && fill != null) {
            scope.launch {
                val ok = PdfExport.save(ctx, uri, heading, loc, fill)
                Toast.makeText(ctx, if (ok) okMsg else failMsg, Toast.LENGTH_SHORT).show()
            }
        }
    }
    val photoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        if (uris.isNotEmpty()) {
            vm.importPhotos(uris) { names ->
                photos = Attachments.join(Attachments.split(photos) + names)
                added = Attachments.join(Attachments.split(added) + names)
            }
        }
    }

    val names = Attachments.split(photos)

    AppScaffold(
        title = stringResource(if (isNew) R.string.diary_new else R.string.diary_edit),
        onBack = { nav.popBackStack() }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .imePadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                singleLine = true,
                label = { Text(stringResource(R.string.diary_entry_title)) },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = body,
                onValueChange = { body = it },
                label = { Text(stringResource(R.string.diary_body)) },
                minLines = 8,
                isError = showErr && title.isBlank() && body.isBlank(),
                supportingText = {
                    if (showErr && title.isBlank() && body.isBlank()) Text(stringResource(R.string.diary_need_text))
                },
                modifier = Modifier.fillMaxWidth()
            )

            Text(stringResource(R.string.diary_mood), style = MaterialTheme.typography.labelLarge)
            ChoiceChips(
                options = listOf(0, 1, 2, 3, 4, 5),
                selected = mood,
                onSelect = { mood = it }
            ) { m -> if (m == 0) stringResource(R.string.mood_none) else MOOD_EMOJI[m] + " " + moodLabel(m) }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.weight(1f)) {
                    PickerField(stringResource(R.string.task_date), Fmt.date(day, loc)) {
                        showDatePicker(ctx, day) { picked -> day = picked }
                    }
                }
                Box(Modifier.weight(1f)) {
                    PickerField(stringResource(R.string.reminder_time), Fmt.time(timeMin, loc)) {
                        showTimePicker(ctx, timeMin) { picked -> timeMin = picked }
                    }
                }
            }

            Text(stringResource(R.string.diary_photos), style = MaterialTheme.typography.labelLarge)
            if (names.isNotEmpty()) {
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (name in names) {
                        Box(Modifier.size(96.dp)) {
                            FileImage(
                                Attachments.file(ctx, name),
                                Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp))
                            )
                            IconButton(
                                onClick = { photos = Attachments.join(names - name) },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .size(28.dp)
                                    .background(Color(0x99000000), CircleShape)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = null, tint = Color.White)
                            }
                        }
                    }
                }
            }
            OutlinedButton(onClick = { photoPicker.launch("image/*") }) {
                Text("📷 " + stringResource(R.string.diary_add_photos))
            }

            Spacer(Modifier.height(4.dp))
            Button(
                onClick = {
                    showErr = true
                    if (title.isNotBlank() || body.isNotBlank()) {
                        val now = D.now()
                        val o = original
                        val e = DiaryEntity(
                            id = o?.id ?: D.id(),
                            title = title.trim(),
                            body = body.trim(),
                            mood = mood,
                            epochDay = day,
                            timeMin = timeMin,
                            photos = photos,
                            createdAt = o?.createdAt ?: now,
                            updatedAt = now
                        )
                        val finalNames = Attachments.split(photos).toSet()
                        val everUsed = Attachments.split(o?.photos ?: "") + Attachments.split(added)
                        val removed = everUsed.filter { !finalNames.contains(it) }
                        vm.save(e, removed) { nav.popBackStack() }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text(stringResource(R.string.save))
            }

            if (!isNew) {
                OutlinedButton(
                    onClick = {
                        val o = original
                        val e = DiaryEntity(
                            id = o?.id ?: "x", title = title, body = body, mood = mood, epochDay = day,
                            timeMin = timeMin, photos = photos, createdAt = 0L, updatedAt = 0L
                        )
                        pending = buildDiaryPdf(listOf(e), loc, heading, moodNames)
                        pdfLauncher.launch("life-manager-diary-entry.pdf")
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(stringResource(R.string.diary_export_entry))
                }
                OutlinedButton(
                    onClick = { confirmDelete = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(stringResource(R.string.delete), color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }

    val cur = original
    if (confirmDelete && cur != null) {
        ConfirmDialog(
            title = stringResource(R.string.confirm_delete_title),
            text = stringResource(R.string.diary_delete_text),
            confirm = stringResource(R.string.delete),
            cancel = stringResource(R.string.cancel),
            onConfirm = {
                confirmDelete = false
                vm.delete(cur) { nav.popBackStack() }
            },
            onDismiss = { confirmDelete = false }
        )
    }
}
