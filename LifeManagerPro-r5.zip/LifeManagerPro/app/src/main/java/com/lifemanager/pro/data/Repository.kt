package com.lifemanager.pro.data

import com.lifemanager.pro.util.D
import kotlinx.coroutines.flow.Flow

class Repository(private val db: LifeDatabase) {

    // ---------- Tasks ----------
    val tasks: Flow<List<TaskEntity>> = db.taskDao().observeAll()

    suspend fun getTask(id: String): TaskEntity? = db.taskDao().get(id)

    suspend fun saveTask(t: TaskEntity) {
        db.taskDao().upsert(t)
    }

    suspend fun deleteTask(id: String) {
        db.taskDao().deleteById(id)
    }

    suspend fun setTaskStatus(t: TaskEntity, status: String) {
        val now = D.now()
        val completedAt = if (status == "COMPLETED") now else 0L
        db.taskDao().upsert(t.copy(status = status, completedAt = completedAt, updatedAt = now))
    }

    // ---------- Habits ----------
    val habits: Flow<List<HabitEntity>> = db.habitDao().observeAll()
    val habitLogs: Flow<List<HabitLogEntity>> = db.habitLogDao().observeAll()

    suspend fun getHabit(id: String): HabitEntity? = db.habitDao().get(id)

    suspend fun saveHabit(h: HabitEntity) {
        db.habitDao().upsert(h)
    }

    /** Marks / unmarks a habit for one day. The log id is fixed, so it can never be duplicated. */
    suspend fun toggleHabit(habitId: String, day: Long) {
        val id = habitId + "|" + day
        val dao = db.habitLogDao()
        if (dao.exists(id) > 0) {
            dao.deleteById(id)
        } else {
            dao.upsert(HabitLogEntity(id = id, habitId = habitId, epochDay = day, createdAt = D.now()))
        }
    }

    // ---------- Goals ----------
    val goals: Flow<List<GoalEntity>> = db.goalDao().observeAll()
    val milestones: Flow<List<MilestoneEntity>> = db.milestoneDao().observeAll()
    val goalLogs: Flow<List<GoalLogEntity>> = db.goalLogDao().observeAll()

    suspend fun getGoal(id: String): GoalEntity? = db.goalDao().get(id)

    suspend fun saveGoal(g: GoalEntity) {
        db.goalDao().upsert(g)
    }

    suspend fun addGoalLog(goalId: String, progress: Int, note: String = "") {
        db.goalLogDao().upsert(
            GoalLogEntity(
                id = D.id(), goalId = goalId, epochDay = D.today(),
                progress = progress, note = note, createdAt = D.now()
            )
        )
    }

    /** Changes a goal's progress and keeps a history entry, so earlier progress is never lost. */
    suspend fun setGoalProgress(g: GoalEntity, progress: Int) {
        val p = progress.coerceIn(0, 100)
        val status = when {
            p >= 100 -> "COMPLETED"
            g.status == "COMPLETED" -> "ACTIVE"
            else -> g.status
        }
        db.goalDao().upsert(g.copy(progress = p, status = status, updatedAt = D.now()))
        addGoalLog(g.id, p)
    }

    suspend fun saveMilestone(m: MilestoneEntity) {
        db.milestoneDao().upsert(m)
    }

    suspend fun deleteMilestone(id: String) {
        db.milestoneDao().deleteById(id)
    }

    /** When a goal has milestones, its progress follows the finished milestones. */
    suspend fun recomputeGoalFromMilestones(goalId: String) {
        val g = db.goalDao().get(goalId) ?: return
        val ms = db.milestoneDao().forGoal(goalId)
        if (ms.isEmpty()) return
        val p = 100 * ms.count { it.done } / ms.size
        if (p != g.progress) setGoalProgress(g, p)
    }

    // ---------- Reminders ----------
    val reminders: Flow<List<ReminderEntity>> = db.reminderDao().observeAll()

    suspend fun getReminder(id: String): ReminderEntity? = db.reminderDao().get(id)

    suspend fun allReminders(): List<ReminderEntity> = db.reminderDao().all()

    suspend fun saveReminder(r: ReminderEntity) {
        db.reminderDao().upsert(r)
    }

    suspend fun deleteReminder(id: String) {
        db.reminderDao().deleteById(id)
    }

    // ---------- Diary ----------
    val diary: Flow<List<DiaryEntity>> = db.diaryDao().observeAll()

    suspend fun getDiary(id: String): DiaryEntity? = db.diaryDao().get(id)

    suspend fun saveDiary(e: DiaryEntity) {
        db.diaryDao().upsert(e)
    }

    suspend fun deleteDiary(id: String) {
        db.diaryDao().deleteById(id)
    }

    // ---------- Time tracker and focus ----------
    val timeEntries: Flow<List<TimeEntryEntity>> = db.timeEntryDao().observeAll()
    val focusSessions: Flow<List<FocusSessionEntity>> = db.focusSessionDao().observeAll()

    suspend fun saveTimeEntry(e: TimeEntryEntity) {
        db.timeEntryDao().upsert(e)
    }

    suspend fun deleteTimeEntry(id: String) {
        db.timeEntryDao().deleteById(id)
    }

    suspend fun saveFocusSession(s: FocusSessionEntity) {
        db.focusSessionDao().upsert(s)
    }

    // ---------- Money ----------
    val txns: Flow<List<TxnEntity>> = db.txnDao().observeAll()
    val budgets: Flow<List<BudgetEntity>> = db.budgetDao().observeAll()
    val savingsGoals: Flow<List<SavingsGoalEntity>> = db.savingsGoalDao().observeAll()
    val savingsEntries: Flow<List<SavingsEntryEntity>> = db.savingsEntryDao().observeAll()

    suspend fun getTxn(id: String): TxnEntity? = db.txnDao().get(id)

    suspend fun saveTxn(t: TxnEntity) {
        db.txnDao().upsert(t)
    }

    suspend fun deleteTxn(id: String) {
        db.txnDao().deleteById(id)
    }

    /** One budget per month; the month key is also the id, so every month stays separate. */
    suspend fun setBudget(monthKey: String, amount: Double) {
        if (amount <= 0.0) {
            db.budgetDao().deleteById(monthKey)
        } else {
            db.budgetDao().upsert(BudgetEntity(id = monthKey, monthKey = monthKey, amount = amount, updatedAt = D.now()))
        }
    }

    suspend fun saveSavingsGoal(g: SavingsGoalEntity) {
        db.savingsGoalDao().upsert(g)
    }

    suspend fun saveSavingsEntry(e: SavingsEntryEntity) {
        db.savingsEntryDao().upsert(e)
    }

    suspend fun deleteSavingsEntry(id: String) {
        db.savingsEntryDao().deleteById(id)
    }

    // ---------- Categories ----------
    fun categories(kind: String): Flow<List<CategoryEntity>> = db.categoryDao().observe(kind)

    suspend fun addCategory(kind: String, name: String, emoji: String = "🏷️") {
        val clean = name.trim()
        if (clean.isEmpty()) return
        if (db.categoryDao().countByName(kind, clean) > 0) return
        db.categoryDao().upsert(
            CategoryEntity(
                id = D.id(), kind = kind, name = clean, emoji = emoji,
                custom = true, archived = false, sortOrder = 100
            )
        )
    }

    /** Safe to call on every start: uses fixed ids and IGNORE, so it never duplicates. */
    suspend fun seedDefaults() {
        val taskCats = listOf(
            "personal" to "👤", "work" to "💼", "study" to "📚", "health" to "💪",
            "family" to "👪", "finance" to "💰", "islamic" to "🕌", "other" to "🏷️"
        )
        val list = taskCats.mapIndexed { i, pair ->
            CategoryEntity(
                id = "cat_TASK_" + pair.first, kind = "TASK", name = pair.first,
                emoji = pair.second, custom = false, archived = false, sortOrder = i
            )
        }
        val timeCats = listOf(
            "work" to "💼", "study" to "📚", "health" to "💪", "family" to "👪",
            "rest" to "😌", "other" to "🏷️"
        )
        val incomeCats = listOf(
            "salary" to "💵", "bonus" to "🎁", "business" to "🏪", "gift" to "🎀", "other" to "🏷️"
        )
        val expenseCats = listOf(
            "food" to "🍽️", "transport" to "🚌", "bills" to "🧾", "rent" to "🏠", "health" to "💊",
            "education" to "🎓", "shopping" to "🛍️", "family" to "👪", "mobile" to "📱", "other" to "🏷️"
        )
        val all = ArrayList<CategoryEntity>(list)
        timeCats.forEachIndexed { i, p ->
            all.add(CategoryEntity(id = "cat_TIME_" + p.first, kind = "TIME", name = p.first, emoji = p.second, sortOrder = i))
        }
        incomeCats.forEachIndexed { i, p ->
            all.add(CategoryEntity(id = "cat_INCOME_" + p.first, kind = "INCOME", name = p.first, emoji = p.second, sortOrder = i))
        }
        expenseCats.forEachIndexed { i, p ->
            all.add(CategoryEntity(id = "cat_EXPENSE_" + p.first, kind = "EXPENSE", name = p.first, emoji = p.second, sortOrder = i))
        }
        db.categoryDao().insertIgnore(all)
    }
}
