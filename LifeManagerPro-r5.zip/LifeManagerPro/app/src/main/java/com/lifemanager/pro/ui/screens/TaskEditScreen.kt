@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.lifemanager.pro.ui.screens

import android.app.Application
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.lifemanager.pro.R
import com.lifemanager.pro.data.CategoryEntity
import com.lifemanager.pro.data.Graph
import com.lifemanager.pro.data.ReminderEntity
import com.lifemanager.pro.reminder.ReminderScheduler
import com.lifemanager.pro.data.TaskEntity
import com.lifemanager.pro.ui.components.AppScaffold
import com.lifemanager.pro.ui.components.ChoiceChips
import com.lifemanager.pro.ui.components.ConfirmDialog
import com.lifemanager.pro.ui.components.PickerField
import com.lifemanager.pro.ui.components.catLabel
import com.lifemanager.pro.ui.components.prioLabel
import com.lifemanager.pro.ui.components.remindLabel
import com.lifemanager.pro.ui.components.showDatePicker
import com.lifemanager.pro.ui.components.showTimePicker
import com.lifemanager.pro.ui.components.statusLabel
import com.lifemanager.pro.util.D
import com.lifemanager.pro.util.Fmt
import com.lifemanager.pro.util.currentLocale
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TaskEditViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Graph.repo

    val categories: StateFlow<List<CategoryEntity>> =
        repo.categories("TASK")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    suspend fun load(id: String): TaskEntity? = repo.getTask(id)

    fun save(t: TaskEntity, onDone: () -> Unit) {
        viewModelScope.launch {
            repo.saveTask(t)
            syncReminder(t)
            onDone()
        }
    }

    fun delete(id: String, onDone: () -> Unit) {
        viewModelScope.launch {
            repo.deleteTask(id)
            val rid = "task-" + id
            repo.deleteReminder(rid)
            ReminderScheduler.cancel(getApplication<Application>(), rid)
            onDone()
        }
    }

    /** A task with a start time can have one alarm; it is removed when the task is done. */
    private suspend fun syncReminder(t: TaskEntity) {
        val app = getApplication<Application>()
        val rid = "task-" + t.id
        val active = t.remindBefore >= 0 && t.startMin >= 0 &&
            t.status != "COMPLETED" && t.status != "CANCELLED"
        if (!active) {
            repo.deleteReminder(rid)
            ReminderScheduler.cancel(app, rid)
            return
        }
        val at = D.dayStartMillis(t.epochDay) + (t.startMin - t.remindBefore) * 60_000L
        val now = D.now()
        val old = repo.getReminder(rid)
        val r = ReminderEntity(
            id = rid, title = t.title, note = "", triggerAt = at, repeatMode = "NONE",
            intervalDays = 1, enabled = at > now, linkedTaskId = t.id,
            createdAt = old?.createdAt ?: now, updatedAt = now
        )
        repo.saveReminder(r)
        ReminderScheduler.schedule(app, r)
    }

    fun addCategory(name: String) {
        viewModelScope.launch { repo.addCategory("TASK", name) }
    }
}

@Composable
fun TaskEditScreen(
    nav: NavHostController,
    id: String,
    presetDay: Long,
    vm: TaskEditViewModel = viewModel()
) {
    val ctx = LocalContext.current
    val loc = currentLocale()
    val cats by vm.categories.collectAsState()
    val isNew = id == "new"

    var original by remember { mutableStateOf<TaskEntity?>(null) }
    var title by rememberSaveable { mutableStateOf("") }
    var desc by rememberSaveable { mutableStateOf("") }
    var day by rememberSaveable { mutableStateOf(if (presetDay >= 0L) presetDay else D.today()) }
    var startMin by rememberSaveable { mutableStateOf(-1) }
    var endMin by rememberSaveable { mutableStateOf(-1) }
    var priority by rememberSaveable { mutableStateOf(1) }
    var category by rememberSaveable { mutableStateOf("personal") }
    var status by rememberSaveable { mutableStateOf("PENDING") }
    var remind by rememberSaveable { mutableStateOf(-1) }
    var showErr by remember { mutableStateOf(false) }
    var timeErr by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var newCat by remember { mutableStateOf(false) }

    LaunchedEffect(id) {
        if (!isNew) {
            val t = vm.load(id)
            if (t != null) {
                original = t
                if (title.isEmpty() && desc.isEmpty()) {
                    title = t.title
                    desc = t.description
                    day = t.epochDay
                    startMin = t.startMin
                    endMin = t.endMin
                    priority = t.priority
                    category = t.category
                    status = t.status
                    remind = t.remindBefore
                }
            }
        }
    }

    AppScaffold(
        title = stringResource(if (isNew) R.string.task_new else R.string.task_edit),
        onBack = { nav.popBackStack() }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .imePadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text(stringResource(R.string.task_title)) },
                isError = showErr && title.isBlank(),
                supportingText = {
                    if (showErr && title.isBlank()) Text(stringResource(R.string.task_title_required))
                },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = desc,
                onValueChange = { desc = it },
                label = { Text(stringResource(R.string.task_desc)) },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )

            PickerField(stringResource(R.string.task_date), Fmt.date(day, loc)) {
                showDatePicker(ctx, day) { picked -> day = picked }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(Modifier.weight(1f)) {
                    PickerField(
                        stringResource(R.string.task_start),
                        if (startMin >= 0) Fmt.time(startMin, loc) else stringResource(R.string.task_no_time)
                    ) {
                        showTimePicker(ctx, if (startMin >= 0) startMin else 9 * 60) { picked -> startMin = picked }
                    }
                    if (startMin >= 0) {
                        TextButton(onClick = { startMin = -1 }) { Text(stringResource(R.string.clear)) }
                    }
                }
                Column(Modifier.weight(1f)) {
                    PickerField(
                        stringResource(R.string.task_end),
                        if (endMin >= 0) Fmt.time(endMin, loc) else stringResource(R.string.task_no_time)
                    ) {
                        showTimePicker(ctx, if (endMin >= 0) endMin else 10 * 60) { picked -> endMin = picked }
                    }
                    if (endMin >= 0) {
                        TextButton(onClick = { endMin = -1 }) { Text(stringResource(R.string.clear)) }
                    }
                }
            }
            if (timeErr) {
                Text(
                    stringResource(R.string.task_time_invalid),
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Text(stringResource(R.string.task_remind), style = MaterialTheme.typography.labelLarge)
            if (startMin >= 0) {
                ChoiceChips(
                    options = listOf(-1, 0, 10, 30, 60),
                    selected = remind,
                    onSelect = { remind = it }
                ) { m -> remindLabel(m) }
            } else {
                Text(
                    stringResource(R.string.task_remind_needs_time),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Text(stringResource(R.string.task_priority), style = MaterialTheme.typography.labelLarge)
            ChoiceChips(
                options = listOf(0, 1, 2),
                selected = priority,
                onSelect = { priority = it }
            ) { p -> prioLabel(p) }

            Text(stringResource(R.string.task_category), style = MaterialTheme.typography.labelLarge)
            ChoiceChips(
                options = cats.map { it.name } + "+",
                selected = category,
                onSelect = { c ->
                    if (c == "+") {
                        newCat = true
                    } else {
                        category = c
                    }
                }
            ) { c -> if (c == "+") "＋ " + stringResource(R.string.new_category) else catLabel(c) }

            Text(stringResource(R.string.task_status), style = MaterialTheme.typography.labelLarge)
            ChoiceChips(
                options = listOf("PENDING", "IN_PROGRESS", "COMPLETED", "CANCELLED"),
                selected = status,
                onSelect = { status = it }
            ) { s -> statusLabel(s) }

            Spacer(Modifier.height(4.dp))
            Button(
                onClick = {
                    showErr = true
                    val bad = startMin >= 0 && endMin >= 0 && endMin <= startMin
                    timeErr = bad
                    if (title.isNotBlank() && !bad) {
                        val now = D.now()
                        val o = original
                        val doneAt = if (status == "COMPLETED") {
                            val prev = o?.completedAt ?: 0L
                            if (prev > 0L) prev else now
                        } else {
                            0L
                        }
                        val t = TaskEntity(
                            id = o?.id ?: D.id(),
                            title = title.trim(),
                            description = desc.trim(),
                            epochDay = day,
                            startMin = startMin,
                            endMin = endMin,
                            priority = priority,
                            category = category,
                            status = status,
                            remindBefore = if (startMin >= 0) remind else -1,
                            completedAt = doneAt,
                            createdAt = o?.createdAt ?: now,
                            updatedAt = now
                        )
                        vm.save(t) { nav.popBackStack() }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text(stringResource(R.string.save))
            }

            if (!isNew) {
                OutlinedButton(
                    onClick = { confirmDelete = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(stringResource(R.string.delete), color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }

    if (confirmDelete) {
        ConfirmDialog(
            title = stringResource(R.string.confirm_delete_title),
            text = stringResource(R.string.confirm_delete_task),
            confirm = stringResource(R.string.delete),
            cancel = stringResource(R.string.cancel),
            onConfirm = {
                confirmDelete = false
                vm.delete(id) { nav.popBackStack() }
            },
            onDismiss = { confirmDelete = false }
        )
    }

    if (newCat) {
        var catName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { newCat = false },
            title = { Text(stringResource(R.string.new_category)) },
            text = {
                OutlinedTextField(
                    value = catName,
                    onValueChange = { catName = it },
                    singleLine = true,
                    label = { Text(stringResource(R.string.category_name)) }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (catName.isNotBlank()) {
                        vm.addCategory(catName)
                        category = catName.trim()
                    }
                    newCat = false
                }) { Text(stringResource(R.string.add)) }
            },
            dismissButton = {
                TextButton(onClick = { newCat = false }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }
}
