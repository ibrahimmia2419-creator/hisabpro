@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.lifemanager.pro.ui.screens

import android.app.Application
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.lifemanager.pro.R
import com.lifemanager.pro.data.BudgetEntity
import com.lifemanager.pro.data.FinanceMath
import com.lifemanager.pro.data.Graph
import com.lifemanager.pro.data.MonthTotals
import com.lifemanager.pro.data.SavingsEntryEntity
import com.lifemanager.pro.data.SavingsGoalEntity
import com.lifemanager.pro.data.TxnEntity
import com.lifemanager.pro.pdf.PdfBuilder
import com.lifemanager.pro.pdf.PdfExport
import com.lifemanager.pro.ui.components.AppCard
import com.lifemanager.pro.ui.components.AppScaffold
import com.lifemanager.pro.ui.components.CategoryPicker
import com.lifemanager.pro.ui.components.ChoiceChips
import com.lifemanager.pro.ui.components.ConfirmDialog
import com.lifemanager.pro.ui.components.EmptyState
import com.lifemanager.pro.ui.components.PickerField
import com.lifemanager.pro.ui.components.Pill
import com.lifemanager.pro.ui.components.ProgressBar
import com.lifemanager.pro.ui.components.SectionTitle
import com.lifemanager.pro.ui.components.StatTile
import com.lifemanager.pro.ui.components.catLabel
import com.lifemanager.pro.ui.components.showDatePicker
import com.lifemanager.pro.ui.nav.Routes
import com.lifemanager.pro.ui.theme.Danger
import com.lifemanager.pro.ui.theme.Info
import com.lifemanager.pro.ui.theme.Muted
import com.lifemanager.pro.ui.theme.Success
import com.lifemanager.pro.util.D
import com.lifemanager.pro.util.Fmt
import com.lifemanager.pro.util.currentLocale
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.YearMonth
import java.util.Locale

class FinanceViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Graph.repo

    val txns: StateFlow<List<TxnEntity>> =
        repo.txns.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    val budgets: StateFlow<List<BudgetEntity>> =
        repo.budgets.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    val goals: StateFlow<List<SavingsGoalEntity>> =
        repo.savingsGoals.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    val entries: StateFlow<List<SavingsEntryEntity>> =
        repo.savingsEntries.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    fun setBudget(monthKey: String, amount: Double) {
        viewModelScope.launch { repo.setBudget(monthKey, amount) }
    }

    fun saveGoal(g: SavingsGoalEntity) {
        viewModelScope.launch { repo.saveSavingsGoal(g) }
    }

    fun addDeposit(goalId: String, amount: Double, note: String, day: Long) {
        viewModelScope.launch {
            repo.saveSavingsEntry(
                SavingsEntryEntity(
                    id = D.id(), goalId = goalId, amount = amount, epochDay = day,
                    note = note, createdAt = D.now()
                )
            )
        }
    }

    fun deleteDeposit(id: String) {
        viewModelScope.launch { repo.deleteSavingsEntry(id) }
    }
}

class TxnEditViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Graph.repo

    suspend fun load(id: String): TxnEntity? = repo.getTxn(id)

    fun save(t: TxnEntity, onDone: () -> Unit) {
        viewModelScope.launch {
            repo.saveTxn(t)
            onDone()
        }
    }

    fun delete(id: String, onDone: () -> Unit) {
        viewModelScope.launch {
            repo.deleteTxn(id)
            onDone()
        }
    }
}

/** Only digits and one dot, always stored as plain 0-9. */
private fun cleanAmount(v: String): String? {
    val a = Fmt.ascii(v)
    if (a.length > 12) return null
    if (!a.all { it.isDigit() || it == '.' }) return null
    if (a.count { it == '.' } > 1) return null
    return a
}

private class FinPdfText(
    val title: String, val income: String, val expense: String, val balance: String,
    val budget: String, val remaining: String, val expByCat: String, val incByCat: String,
    val txns: String, val colItem: String, val colAmount: String, val colShare: String,
    val colDate: String, val colCategory: String, val colNote: String
)

@Composable
fun FinanceScreen(nav: NavHostController, vm: FinanceViewModel = viewModel()) {
    val txns by vm.txns.collectAsState()
    val budgets by vm.budgets.collectAsState()
    val goals by vm.goals.collectAsState()
    val entries by vm.entries.collectAsState()
    val loc = currentLocale()
    var tab by remember { mutableStateOf(0) }
    var month by remember { mutableStateOf(YearMonth.now()) }
    var budgetDialog by remember { mutableStateOf(false) }

    val key = month.toString()
    val tot = FinanceMath.totals(txns, key)
    val budget: Double? = budgets.firstOrNull { it.monthKey == key }?.amount
    val savingsTotal = FinanceMath.savingsTotal(entries)
    val monthTxns = txns.filter { it.monthKey == key }
    val tabs = listOf(R.string.fin_tab_overview, R.string.fin_tab_savings, R.string.fin_tab_report)

    AppScaffold(
        title = stringResource(R.string.finance_title),
        onBack = { nav.popBackStack() },
        fab = {
            if (tab == 0) {
                FloatingActionButton(onClick = { nav.navigate(Routes.txnEdit("new")) }) {
                    Icon(Icons.Default.Add, contentDescription = null)
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            TabRow(selectedTabIndex = tab) {
                tabs.forEachIndexed { i, res ->
                    Tab(
                        selected = tab == i,
                        onClick = { tab = i },
                        text = { Text(stringResource(res)) }
                    )
                }
            }
            if (tab != 1) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { month = month.minusMonths(1) }) { Text("‹", fontSize = 26.sp) }
                    Text(
                        Fmt.month(month, loc),
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.titleMedium
                    )
                    TextButton(onClick = { month = month.plusMonths(1) }) { Text("›", fontSize = 26.sp) }
                }
            }
            when (tab) {
                0 -> LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item { SummaryCard(tot, savingsTotal, budget, loc) { budgetDialog = true } }
                    if (monthTxns.isEmpty()) {
                        item { EmptyState("💰", stringResource(R.string.fin_empty)) }
                    } else {
                        items(monthTxns, key = { it.id }) { t ->
                            TxnRow(t, loc) { nav.navigate(Routes.txnEdit(t.id)) }
                        }
                    }
                }
                1 -> SavingsTab(goals, entries, loc, vm)
                else -> ReportTab(month, txns, tot, budget, loc)
            }
        }
    }

    if (budgetDialog) {
        BudgetDialog(
            monthLabel = Fmt.month(month, loc),
            current = budget,
            onSave = { amount ->
                vm.setBudget(key, amount)
                budgetDialog = false
            },
            onDismiss = { budgetDialog = false }
        )
    }
}

@Composable
private fun SummaryCard(
    tot: MonthTotals,
    savings: Double,
    budget: Double?,
    loc: Locale,
    onBudget: () -> Unit
) {
    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile(Fmt.money(tot.income, loc), stringResource(R.string.fin_income), Success, Modifier.weight(1f))
                StatTile(Fmt.money(tot.expense, loc), stringResource(R.string.fin_expense), Danger, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile(
                    Fmt.money(tot.balance, loc), stringResource(R.string.fin_balance),
                    MaterialTheme.colorScheme.primary, Modifier.weight(1f)
                )
                StatTile(Fmt.money(savings, loc), stringResource(R.string.fin_savings_total), Info, Modifier.weight(1f))
            }
            if (budget == null) {
                OutlinedButton(onClick = onBudget, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.fin_set_budget))
                }
            } else {
                val remaining = budget - tot.expense
                val frac = if (budget > 0.0) (tot.expense / budget).toFloat() else 0f
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            stringResource(R.string.fin_remaining_budget),
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            Fmt.money(remaining, loc),
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = if (remaining < 0.0) Danger else Success
                        )
                    }
                    TextButton(onClick = onBudget) { Text(stringResource(R.string.edit)) }
                }
                ProgressBar(frac, color = if (frac > 1f) Danger else MaterialTheme.colorScheme.primary)
                Text(
                    stringResource(R.string.fin_budget_used, Fmt.money(tot.expense, loc), Fmt.money(budget, loc)),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun TxnRow(t: TxnEntity, loc: Locale, onOpen: () -> Unit) {
    val income = t.type == "INCOME"
    AppCard(Modifier.fillMaxWidth(), onClick = onOpen) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(catLabel(t.category), style = MaterialTheme.typography.titleMedium)
                if (t.note.isNotBlank()) {
                    Text(
                        t.note,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Text(
                    Fmt.date(t.epochDay, loc),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                (if (income) "+" else "−") + Fmt.money(t.amount, loc),
                fontWeight = FontWeight.Bold,
                color = if (income) Success else Danger
            )
        }
    }
}

@Composable
private fun BudgetDialog(monthLabel: String, current: Double?, onSave: (Double) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(if (current != null) Fmt.plain(current) else "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.fin_budget_title, monthLabel)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { v -> cleanAmount(v)?.let { text = it } },
                    singleLine = true,
                    label = { Text(stringResource(R.string.fin_amount)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    stringResource(R.string.fin_budget_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(Fmt.parseAmount(text) ?: 0.0) }) {
                Text(stringResource(R.string.save))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        }
    )
}

@Composable
private fun SavingsTab(
    goals: List<SavingsGoalEntity>,
    entries: List<SavingsEntryEntity>,
    loc: Locale,
    vm: FinanceViewModel
) {
    var editGoal by remember { mutableStateOf<SavingsGoalEntity?>(null) }
    var newGoal by remember { mutableStateOf(false) }
    var depositFor by remember { mutableStateOf<SavingsGoalEntity?>(null) }
    var historyFor by remember { mutableStateOf<SavingsGoalEntity?>(null) }
    val sorted = goals.sortedBy { it.archived }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Button(onClick = { newGoal = true }, modifier = Modifier.fillMaxWidth()) {
                Text("＋ " + stringResource(R.string.fin_new_goal))
            }
        }
        if (sorted.isEmpty()) {
            item { EmptyState("🐖", stringResource(R.string.fin_goals_empty)) }
        } else {
            items(sorted, key = { it.id }) { g ->
                val saved = FinanceMath.savedFor(g.id, entries)
                AppCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                g.name,
                                style = MaterialTheme.typography.titleMedium,
                                modifier = Modifier.weight(1f)
                            )
                            if (g.archived) Pill(stringResource(R.string.goals_archived), Muted)
                        }
                        val frac = if (g.target > 0.0) (saved / g.target).toFloat() else 0f
                        ProgressBar(frac)
                        Text(
                            Fmt.money(saved, loc) + " / " + Fmt.money(g.target, loc) + "  (" +
                                Fmt.percent(frac.coerceIn(0f, 1f), loc) + ")",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        if (g.targetEpochDay > 0L) {
                            Text(
                                stringResource(R.string.goal_target) + ": " + Fmt.date(g.targetEpochDay, loc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Button(onClick = { depositFor = g }) { Text(stringResource(R.string.fin_add_deposit)) }
                            OutlinedButton(onClick = { historyFor = g }) { Text(stringResource(R.string.fin_history)) }
                            OutlinedButton(onClick = { editGoal = g }) { Text(stringResource(R.string.edit)) }
                        }
                    }
                }
            }
        }
    }

    if (newGoal) {
        GoalDialog(
            initial = null,
            onSave = {
                vm.saveGoal(it)
                newGoal = false
            },
            onDismiss = { newGoal = false }
        )
    }
    val eg = editGoal
    if (eg != null) {
        GoalDialog(
            initial = eg,
            onSave = {
                vm.saveGoal(it)
                editGoal = null
            },
            onDismiss = { editGoal = null }
        )
    }
    val dg = depositFor
    if (dg != null) {
        DepositDialog(
            goalName = dg.name,
            onSave = { amount, note, day ->
                vm.addDeposit(dg.id, amount, note, day)
                depositFor = null
            },
            onDismiss = { depositFor = null }
        )
    }
    val hg = historyFor
    if (hg != null) {
        val list = entries.filter { it.goalId == hg.id }
        AlertDialog(
            onDismissRequest = { historyFor = null },
            title = { Text(hg.name) },
            text = {
                Column(
                    Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (list.isEmpty()) {
                        Text(stringResource(R.string.fin_no_deposits))
                    }
                    list.forEach { e ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(Fmt.money(e.amount, loc), fontWeight = FontWeight.SemiBold)
                                Text(
                                    Fmt.date(e.epochDay, loc) + (if (e.note.isNotBlank()) " · " + e.note else ""),
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            TextButton(onClick = { vm.deleteDeposit(e.id) }) {
                                Text(stringResource(R.string.delete), color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { historyFor = null }) { Text(stringResource(R.string.ok)) }
            }
        )
    }
}

@Composable
private fun GoalDialog(initial: SavingsGoalEntity?, onSave: (SavingsGoalEntity) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val loc = currentLocale()
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var target by remember { mutableStateOf(if (initial != null) Fmt.plain(initial.target) else "") }
    var day by remember { mutableStateOf(initial?.targetEpochDay ?: 0L) }
    var archived by remember { mutableStateOf(initial?.archived ?: false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(if (initial == null) R.string.fin_new_goal else R.string.fin_edit_goal)) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    label = { Text(stringResource(R.string.fin_goal_name)) },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = target,
                    onValueChange = { v -> cleanAmount(v)?.let { target = it } },
                    singleLine = true,
                    label = { Text(stringResource(R.string.fin_goal_target)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
                PickerField(
                    stringResource(R.string.goal_target),
                    if (day > 0L) Fmt.date(day, loc) else stringResource(R.string.goal_no_date)
                ) {
                    showDatePicker(ctx, if (day > 0L) day else D.today() + 30L) { picked -> day = picked }
                }
                if (day > 0L) {
                    TextButton(onClick = { day = 0L }) { Text(stringResource(R.string.clear)) }
                }
                if (initial != null) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            stringResource(R.string.goals_archived),
                            modifier = Modifier.weight(1f)
                        )
                        Switch(checked = archived, onCheckedChange = { archived = it })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val t = Fmt.parseAmount(target) ?: 0.0
                if (name.isNotBlank() && t > 0.0) {
                    val now = D.now()
                    onSave(
                        SavingsGoalEntity(
                            id = initial?.id ?: D.id(),
                            name = name.trim(),
                            target = t,
                            targetEpochDay = day,
                            archived = archived,
                            createdAt = initial?.createdAt ?: now,
                            updatedAt = now
                        )
                    )
                }
            }) { Text(stringResource(R.string.save)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        }
    )
}

@Composable
private fun DepositDialog(goalName: String, onSave: (Double, String, Long) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val loc = currentLocale()
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var day by remember { mutableStateOf(D.today()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.fin_add_deposit) + " · " + goalName) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = amount,
                    onValueChange = { v -> cleanAmount(v)?.let { amount = it } },
                    singleLine = true,
                    label = { Text(stringResource(R.string.fin_amount)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    singleLine = true,
                    label = { Text(stringResource(R.string.fin_note)) },
                    modifier = Modifier.fillMaxWidth()
                )
                PickerField(stringResource(R.string.task_date), Fmt.date(day, loc)) {
                    showDatePicker(ctx, day) { picked -> day = picked }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val a = Fmt.parseAmount(amount) ?: 0.0
                if (a > 0.0) onSave(a, note.trim(), day)
            }) { Text(stringResource(R.string.save)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        }
    )
}

@Composable
private fun ReportTab(month: YearMonth, txns: List<TxnEntity>, tot: MonthTotals, budget: Double?, loc: Locale) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val key = month.toString()
    val expenseBy = FinanceMath.byCategory(txns, key, "EXPENSE")
    val incomeBy = FinanceMath.byCategory(txns, key, "INCOME")
    val monthTxns = txns.filter { it.monthKey == key }.sortedBy { it.epochDay }
    val expenseLabels = expenseBy.map { catLabel(it.first) }
    val incomeLabels = incomeBy.map { catLabel(it.first) }
    val txnLabels = monthTxns.map { catLabel(it.category) }
    var pending by remember { mutableStateOf<((PdfBuilder) -> Unit)?>(null) }

    val text = FinPdfText(
        title = stringResource(R.string.fin_report_title, Fmt.month(month, loc)),
        income = stringResource(R.string.fin_income),
        expense = stringResource(R.string.fin_expense),
        balance = stringResource(R.string.fin_balance),
        budget = stringResource(R.string.fin_budget),
        remaining = stringResource(R.string.fin_remaining_budget),
        expByCat = stringResource(R.string.fin_exp_by_cat),
        incByCat = stringResource(R.string.fin_inc_by_cat),
        txns = stringResource(R.string.fin_tab_overview),
        colItem = stringResource(R.string.pdf_col_item),
        colAmount = stringResource(R.string.fin_amount),
        colShare = stringResource(R.string.pdf_col_share),
        colDate = stringResource(R.string.task_date),
        colCategory = stringResource(R.string.task_category),
        colNote = stringResource(R.string.fin_note)
    )
    val okMsg = stringResource(R.string.pdf_saved)
    val failMsg = stringResource(R.string.pdf_failed)
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val fill = pending
        pending = null
        if (uri != null && fill != null) {
            scope.launch {
                val ok = PdfExport.save(ctx, uri, text.title, loc, fill)
                Toast.makeText(ctx, if (ok) okMsg else failMsg, Toast.LENGTH_SHORT).show()
            }
        }
    }

    val months = (5 downTo 0).map { month.minusMonths(it.toLong()) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        AppCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                SectionTitle(text.title)
                Text(text.income + ": " + Fmt.money(tot.income, loc), color = Success)
                Text(text.expense + ": " + Fmt.money(tot.expense, loc), color = Danger)
                Text(text.balance + ": " + Fmt.money(tot.balance, loc), fontWeight = FontWeight.Bold)
            }
        }

        CategoryBars(text.expByCat, expenseBy, expenseLabels, tot.expense, Danger, loc)
        CategoryBars(text.incByCat, incomeBy, incomeLabels, tot.income, Success, loc)

        AppCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                SectionTitle(stringResource(R.string.fin_last_months))
                months.forEach { m ->
                    val t = FinanceMath.totals(txns, m.toString())
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(Fmt.month(m, loc), modifier = Modifier.weight(1.2f), style = MaterialTheme.typography.bodySmall)
                        Text(Fmt.money(t.income, loc), modifier = Modifier.weight(1f), color = Success, style = MaterialTheme.typography.bodySmall)
                        Text(Fmt.money(t.expense, loc), modifier = Modifier.weight(1f), color = Danger, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        Button(
            onClick = {
                pending = { b ->
                    b.title(text.title)
                    val rows = ArrayList<List<String>>()
                    rows.add(listOf(text.income, Fmt.money(tot.income, loc)))
                    rows.add(listOf(text.expense, Fmt.money(tot.expense, loc)))
                    rows.add(listOf(text.balance, Fmt.money(tot.balance, loc)))
                    if (budget != null) {
                        rows.add(listOf(text.budget, Fmt.money(budget, loc)))
                        rows.add(listOf(text.remaining, Fmt.money(budget - tot.expense, loc)))
                    }
                    b.table(listOf(text.colItem, text.colAmount), rows, listOf(2f, 2f))
                    if (expenseBy.isNotEmpty()) {
                        b.heading(text.expByCat)
                        b.table(
                            listOf(text.colCategory, text.colAmount, text.colShare),
                            expenseBy.mapIndexed { i, p ->
                                listOf(expenseLabels[i], Fmt.money(p.second, loc), Fmt.percent(share(p.second, tot.expense), loc))
                            },
                            listOf(3f, 2.5f, 1.5f)
                        )
                    }
                    if (incomeBy.isNotEmpty()) {
                        b.heading(text.incByCat)
                        b.table(
                            listOf(text.colCategory, text.colAmount, text.colShare),
                            incomeBy.mapIndexed { i, p ->
                                listOf(incomeLabels[i], Fmt.money(p.second, loc), Fmt.percent(share(p.second, tot.income), loc))
                            },
                            listOf(3f, 2.5f, 1.5f)
                        )
                    }
                    if (monthTxns.isNotEmpty()) {
                        b.heading(text.txns)
                        b.table(
                            listOf(text.colDate, text.colCategory, text.colNote, text.colAmount),
                            monthTxns.mapIndexed { i, t ->
                                listOf(
                                    Fmt.date(t.epochDay, loc), txnLabels[i], t.note,
                                    (if (t.type == "INCOME") "+" else "−") + Fmt.money(t.amount, loc)
                                )
                            },
                            listOf(2f, 2f, 3f, 2.2f)
                        )
                    }
                }
                launcher.launch("life-manager-money-" + key + ".pdf")
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(stringResource(R.string.fin_export_pdf))
        }
    }
}

private fun share(part: Double, whole: Double): Float = if (whole > 0.0) (part / whole).toFloat() else 0f

@Composable
private fun CategoryBars(
    title: String,
    data: List<Pair<String, Double>>,
    labels: List<String>,
    total: Double,
    color: androidx.compose.ui.graphics.Color,
    loc: Locale
) {
    if (data.isEmpty()) return
    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionTitle(title)
            data.forEachIndexed { i, p ->
                val frac = share(p.second, total)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row {
                        Text(labels[i], modifier = Modifier.weight(1f))
                        Text(
                            Fmt.money(p.second, loc) + "  " + Fmt.percent(frac, loc),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    ProgressBar(frac, color = color)
                }
            }
        }
    }
}

@Composable
fun TxnEditScreen(nav: NavHostController, id: String, vm: TxnEditViewModel = viewModel()) {
    val ctx = LocalContext.current
    val loc = currentLocale()
    val isNew = id == "new"
    var original by remember { mutableStateOf<TxnEntity?>(null) }
    var type by rememberSaveable { mutableStateOf("EXPENSE") }
    var amount by rememberSaveable { mutableStateOf("") }
    var category by rememberSaveable { mutableStateOf("other") }
    var note by rememberSaveable { mutableStateOf("") }
    var day by rememberSaveable { mutableStateOf(D.today()) }
    var showErr by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    LaunchedEffect(id) {
        if (!isNew) {
            val t = vm.load(id)
            if (t != null) {
                original = t
                if (amount.isEmpty()) {
                    type = t.type
                    amount = Fmt.plain(t.amount)
                    category = t.category
                    note = t.note
                    day = t.epochDay
                }
            }
        }
    }

    val parsed = Fmt.parseAmount(amount) ?: 0.0

    AppScaffold(
        title = stringResource(if (isNew) R.string.fin_new_txn else R.string.fin_edit_txn),
        onBack = { nav.popBackStack() }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .imePadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            ChoiceChips(
                options = listOf("EXPENSE", "INCOME"),
                selected = type,
                onSelect = {
                    type = it
                    category = "other"
                }
            ) { t -> if (t == "INCOME") stringResource(R.string.fin_income) else stringResource(R.string.fin_expense) }

            OutlinedTextField(
                value = amount,
                onValueChange = { v -> cleanAmount(v)?.let { amount = it } },
                singleLine = true,
                label = { Text(stringResource(R.string.fin_amount) + " (৳)") },
                isError = showErr && parsed <= 0.0,
                supportingText = {
                    if (showErr && parsed <= 0.0) Text(stringResource(R.string.fin_amount_required))
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth()
            )

            Text(stringResource(R.string.task_category), style = MaterialTheme.typography.labelLarge)
            CategoryPicker(type, category) { category = it }

            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text(stringResource(R.string.fin_note)) },
                modifier = Modifier.fillMaxWidth()
            )
            PickerField(stringResource(R.string.task_date), Fmt.date(day, loc)) {
                showDatePicker(ctx, day) { picked -> day = picked }
            }

            Spacer(Modifier.height(4.dp))
            Button(
                onClick = {
                    showErr = true
                    if (parsed > 0.0) {
                        val now = D.now()
                        val o = original
                        val t = TxnEntity(
                            id = o?.id ?: D.id(),
                            type = type,
                            amount = parsed,
                            category = category,
                            note = note.trim(),
                            epochDay = day,
                            monthKey = D.monthKey(day),
                            createdAt = o?.createdAt ?: now,
                            updatedAt = now
                        )
                        vm.save(t) { nav.popBackStack() }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text(stringResource(R.string.save))
            }
            if (!isNew) {
                OutlinedButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.delete), color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }

    if (confirmDelete) {
        ConfirmDialog(
            title = stringResource(R.string.confirm_delete_title),
            text = stringResource(R.string.fin_delete_text),
            confirm = stringResource(R.string.delete),
            cancel = stringResource(R.string.cancel),
            onConfirm = {
                confirmDelete = false
                vm.delete(id) { nav.popBackStack() }
            },
            onDismiss = { confirmDelete = false }
        )
    }
}
