package com.lifemanager.pro.data

data class MonthTotals(val income: Double, val expense: Double) {
    val balance: Double get() = income - expense
}

/** Money calculations. Every month is calculated on its own, so old months never change. */
object FinanceMath {
    fun totals(txns: List<TxnEntity>, monthKey: String): MonthTotals {
        var income = 0.0
        var expense = 0.0
        for (t in txns) {
            if (t.monthKey != monthKey) continue
            if (t.type == "INCOME") income += t.amount else expense += t.amount
        }
        return MonthTotals(income, expense)
    }

    /** Category totals of one type in one month, biggest first. */
    fun byCategory(txns: List<TxnEntity>, monthKey: String, type: String): List<Pair<String, Double>> {
        val map = HashMap<String, Double>()
        for (t in txns) {
            if (t.monthKey != monthKey || t.type != type) continue
            map[t.category] = (map[t.category] ?: 0.0) + t.amount
        }
        return map.entries.map { it.key to it.value }.sortedByDescending { it.second }
    }

    fun savingsTotal(entries: List<SavingsEntryEntity>): Double = entries.sumOf { it.amount }

    fun savedFor(goalId: String, entries: List<SavingsEntryEntity>): Double =
        entries.filter { it.goalId == goalId }.sumOf { it.amount }
}
