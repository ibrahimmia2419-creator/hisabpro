package com.lifemanager.pro.reminder

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/** Runs every few hours as a safety net in case the phone's battery saver removed an alarm. */
class ReminderSyncWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        ReminderScheduler.rescheduleAll(applicationContext)
        return Result.success()
    }
}
