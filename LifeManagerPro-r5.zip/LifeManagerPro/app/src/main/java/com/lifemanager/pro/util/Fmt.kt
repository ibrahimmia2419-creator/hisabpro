package com.lifemanager.pro.util

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.view.WindowManager
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalConfiguration
import java.text.NumberFormat
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.DecimalStyle
import java.util.Locale

/** The locale the app is currently showing (follows the in-app language setting). */
@Composable
fun currentLocale(): Locale = LocalConfiguration.current.locales[0]

/** Display formatting only. Never use these results as database keys. */
object Fmt {
    private fun f(pattern: String, loc: Locale): DateTimeFormatter =
        DateTimeFormatter.ofPattern(pattern, loc).withDecimalStyle(DecimalStyle.of(loc))

    fun num(n: Int, loc: Locale): String = NumberFormat.getInstance(loc).format(n.toLong())
    fun num(n: Long, loc: Locale): String = NumberFormat.getInstance(loc).format(n)
    fun percent(p: Float, loc: Locale): String = NumberFormat.getPercentInstance(loc).format(p.toDouble())

    /** Taka amount such as ৳ 1,250.5 (digits follow the app language). */
    fun money(a: Double, loc: Locale): String {
        val nf = NumberFormat.getInstance(loc)
        nf.maximumFractionDigits = 2
        nf.minimumFractionDigits = 0
        return "৳ " + nf.format(a)
    }

    /** Turns any Unicode digits (for example Bangla ০১২৩) into 0123 so they can be parsed. */
    fun ascii(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            val d = Character.digit(c, 10)
            if (d >= 0) sb.append(('0' + d)) else sb.append(c)
        }
        return sb.toString()
    }

    fun parseAmount(s: String): Double? = ascii(s.trim()).toDoubleOrNull()

    fun parseInt(s: String): Int? = ascii(s.trim()).toIntOrNull()

    /** A plain machine number for text fields: 1250 or 1250.5 (never 1.25E3). */
    fun plain(a: Double): String =
        java.math.BigDecimal(a).setScale(2, java.math.RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()

    fun pad2(n: Int, loc: Locale): String = num(n / 10, loc) + num(n % 10, loc)

    /** 00:12:34 style clock for timers. */
    fun clock(totalSec: Long, loc: Locale): String {
        val s = if (totalSec < 0L) 0L else totalSec
        val h = (s / 3600L).toInt()
        val m = ((s % 3600L) / 60L).toInt()
        val sec = (s % 60L).toInt()
        return pad2(h, loc) + ":" + pad2(m, loc) + ":" + pad2(sec, loc)
    }

    fun date(epochDay: Long, loc: Locale): String =
        f("d MMM yyyy", loc).format(LocalDate.ofEpochDay(epochDay))

    fun dateLong(epochDay: Long, loc: Locale): String =
        f("EEEE, d MMMM yyyy", loc).format(LocalDate.ofEpochDay(epochDay))

    fun month(m: YearMonth, loc: Locale): String = f("MMMM yyyy", loc).format(m)

    fun time(minuteOfDay: Int, loc: Locale): String =
        f("hh:mm a", loc).format(LocalTime.of(minuteOfDay / 60, minuteOfDay % 60))
}

/** Finds the hosting Activity from any Context (Compose gives a wrapped context). */
fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/** Blocks screenshots / hides the app in the recent-apps preview. */
fun Activity.applySecure(on: Boolean) {
    if (on) {
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
    } else {
        window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }
}
