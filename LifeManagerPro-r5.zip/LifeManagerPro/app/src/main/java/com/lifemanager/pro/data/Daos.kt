package com.lifemanager.pro.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

interface BaseDao<T> {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: T)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<T>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(items: List<T>): List<Long>

    @Delete
    suspend fun delete(item: T)
}

@Dao
interface TaskDao : BaseDao<TaskEntity> {
    @Query("SELECT * FROM tasks ORDER BY epochDay ASC, startMin ASC")
    fun observeAll(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE id = :id LIMIT 1")
    suspend fun get(id: String): TaskEntity?

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("SELECT * FROM tasks")
    suspend fun all(): List<TaskEntity>

    @Query("DELETE FROM tasks")
    suspend fun clear()
}

@Dao
interface CategoryDao : BaseDao<CategoryEntity> {
    @Query("SELECT * FROM categories WHERE kind = :kind AND archived = 0 ORDER BY sortOrder ASC, name ASC")
    fun observe(kind: String): Flow<List<CategoryEntity>>

    @Query("SELECT COUNT(*) FROM categories WHERE kind = :kind AND name = :name")
    suspend fun countByName(kind: String, name: String): Int

    @Query("SELECT * FROM categories")
    suspend fun all(): List<CategoryEntity>

    @Query("DELETE FROM categories")
    suspend fun clear()
}

@Dao
interface HabitDao : BaseDao<HabitEntity> {
    @Query("SELECT * FROM habits ORDER BY sortOrder ASC, createdAt ASC")
    fun observeAll(): Flow<List<HabitEntity>>

    @Query("SELECT * FROM habits WHERE id = :id LIMIT 1")
    suspend fun get(id: String): HabitEntity?

    @Query("SELECT * FROM habits")
    suspend fun all(): List<HabitEntity>

    @Query("DELETE FROM habits")
    suspend fun clear()
}

@Dao
interface HabitLogDao : BaseDao<HabitLogEntity> {
    @Query("SELECT * FROM habit_logs")
    fun observeAll(): Flow<List<HabitLogEntity>>

    @Query("SELECT COUNT(*) FROM habit_logs WHERE id = :id")
    suspend fun exists(id: String): Int

    @Query("DELETE FROM habit_logs WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("SELECT * FROM habit_logs")
    suspend fun all(): List<HabitLogEntity>

    @Query("DELETE FROM habit_logs")
    suspend fun clear()
}

@Dao
interface GoalDao : BaseDao<GoalEntity> {
    @Query("SELECT * FROM goals ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<GoalEntity>>

    @Query("SELECT * FROM goals WHERE id = :id LIMIT 1")
    suspend fun get(id: String): GoalEntity?

    @Query("SELECT * FROM goals")
    suspend fun all(): List<GoalEntity>

    @Query("DELETE FROM goals")
    suspend fun clear()
}

@Dao
interface MilestoneDao : BaseDao<MilestoneEntity> {
    @Query("SELECT * FROM milestones ORDER BY sortOrder ASC, createdAt ASC")
    fun observeAll(): Flow<List<MilestoneEntity>>

    @Query("SELECT * FROM milestones WHERE goalId = :goalId")
    suspend fun forGoal(goalId: String): List<MilestoneEntity>

    @Query("DELETE FROM milestones WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("SELECT * FROM milestones")
    suspend fun all(): List<MilestoneEntity>

    @Query("DELETE FROM milestones")
    suspend fun clear()
}

@Dao
interface GoalLogDao : BaseDao<GoalLogEntity> {
    @Query("SELECT * FROM goal_logs ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<GoalLogEntity>>

    @Query("SELECT * FROM goal_logs")
    suspend fun all(): List<GoalLogEntity>

    @Query("DELETE FROM goal_logs")
    suspend fun clear()
}

@Dao
interface ReminderDao : BaseDao<ReminderEntity> {
    @Query("SELECT * FROM reminders ORDER BY triggerAt ASC")
    fun observeAll(): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders WHERE id = :id LIMIT 1")
    suspend fun get(id: String): ReminderEntity?

    @Query("DELETE FROM reminders WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("SELECT * FROM reminders")
    suspend fun all(): List<ReminderEntity>

    @Query("DELETE FROM reminders")
    suspend fun clear()
}

@Dao
interface DiaryDao : BaseDao<DiaryEntity> {
    @Query("SELECT * FROM diary ORDER BY epochDay DESC, timeMin DESC, createdAt DESC")
    fun observeAll(): Flow<List<DiaryEntity>>

    @Query("SELECT * FROM diary WHERE id = :id LIMIT 1")
    suspend fun get(id: String): DiaryEntity?

    @Query("DELETE FROM diary WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("SELECT * FROM diary")
    suspend fun all(): List<DiaryEntity>

    @Query("DELETE FROM diary")
    suspend fun clear()
}

@Dao
interface TimeEntryDao : BaseDao<TimeEntryEntity> {
    @Query("SELECT * FROM time_entries ORDER BY startAt DESC")
    fun observeAll(): Flow<List<TimeEntryEntity>>

    @Query("DELETE FROM time_entries WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("SELECT * FROM time_entries")
    suspend fun all(): List<TimeEntryEntity>

    @Query("DELETE FROM time_entries")
    suspend fun clear()
}

@Dao
interface FocusSessionDao : BaseDao<FocusSessionEntity> {
    @Query("SELECT * FROM focus_sessions ORDER BY startAt DESC")
    fun observeAll(): Flow<List<FocusSessionEntity>>

    @Query("SELECT * FROM focus_sessions")
    suspend fun all(): List<FocusSessionEntity>

    @Query("DELETE FROM focus_sessions")
    suspend fun clear()
}

@Dao
interface TxnDao : BaseDao<TxnEntity> {
    @Query("SELECT * FROM txns ORDER BY epochDay DESC, createdAt DESC")
    fun observeAll(): Flow<List<TxnEntity>>

    @Query("SELECT * FROM txns WHERE id = :id LIMIT 1")
    suspend fun get(id: String): TxnEntity?

    @Query("DELETE FROM txns WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("SELECT * FROM txns")
    suspend fun all(): List<TxnEntity>

    @Query("DELETE FROM txns")
    suspend fun clear()
}

@Dao
interface BudgetDao : BaseDao<BudgetEntity> {
    @Query("SELECT * FROM budgets")
    fun observeAll(): Flow<List<BudgetEntity>>

    @Query("DELETE FROM budgets WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("SELECT * FROM budgets")
    suspend fun all(): List<BudgetEntity>

    @Query("DELETE FROM budgets")
    suspend fun clear()
}

@Dao
interface SavingsGoalDao : BaseDao<SavingsGoalEntity> {
    @Query("SELECT * FROM savings_goals ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<SavingsGoalEntity>>

    @Query("SELECT * FROM savings_goals")
    suspend fun all(): List<SavingsGoalEntity>

    @Query("DELETE FROM savings_goals")
    suspend fun clear()
}

@Dao
interface SavingsEntryDao : BaseDao<SavingsEntryEntity> {
    @Query("SELECT * FROM savings_entries ORDER BY epochDay DESC, createdAt DESC")
    fun observeAll(): Flow<List<SavingsEntryEntity>>

    @Query("DELETE FROM savings_entries WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("SELECT * FROM savings_entries")
    suspend fun all(): List<SavingsEntryEntity>

    @Query("DELETE FROM savings_entries")
    suspend fun clear()
}
