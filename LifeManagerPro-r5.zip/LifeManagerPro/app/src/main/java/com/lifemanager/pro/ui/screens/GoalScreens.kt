@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.lifemanager.pro.ui.screens

import android.app.Application
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.lifemanager.pro.R
import com.lifemanager.pro.data.GoalEntity
import com.lifemanager.pro.data.GoalLogEntity
import com.lifemanager.pro.data.Graph
import com.lifemanager.pro.data.MilestoneEntity
import com.lifemanager.pro.ui.components.AppCard
import com.lifemanager.pro.ui.components.AppScaffold
import com.lifemanager.pro.ui.components.ChoiceChips
import com.lifemanager.pro.ui.components.EmptyState
import com.lifemanager.pro.ui.components.GOAL_CATS
import com.lifemanager.pro.ui.components.PickerField
import com.lifemanager.pro.ui.components.Pill
import com.lifemanager.pro.ui.components.ProgressBar
import com.lifemanager.pro.ui.components.ProgressRing
import com.lifemanager.pro.ui.components.SectionTitle
import com.lifemanager.pro.ui.components.goalCatEmoji
import com.lifemanager.pro.ui.components.goalCatLabel
import com.lifemanager.pro.ui.components.goalStatusColor
import com.lifemanager.pro.ui.components.goalStatusLabel
import com.lifemanager.pro.ui.components.showDatePicker
import com.lifemanager.pro.ui.nav.Routes
import com.lifemanager.pro.ui.theme.Danger
import com.lifemanager.pro.ui.theme.Success
import com.lifemanager.pro.util.D
import com.lifemanager.pro.util.Fmt
import com.lifemanager.pro.util.currentLocale
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale

class GoalsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Graph.repo

    val goals: StateFlow<List<GoalEntity>> =
        repo.goals.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    val milestones: StateFlow<List<MilestoneEntity>> =
        repo.milestones.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    val logs: StateFlow<List<GoalLogEntity>> =
        repo.goalLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    fun setProgress(g: GoalEntity, p: Int) {
        viewModelScope.launch { repo.setGoalProgress(g, p) }
    }

    fun setArchived(g: GoalEntity, archived: Boolean) {
        viewModelScope.launch { repo.saveGoal(g.copy(archived = archived, updatedAt = D.now())) }
    }

    fun markCompleted(g: GoalEntity) {
        viewModelScope.launch { repo.setGoalProgress(g, 100) }
    }

    fun toggleMilestone(m: MilestoneEntity) {
        viewModelScope.launch {
            repo.saveMilestone(m.copy(done = !m.done, updatedAt = D.now()))
            repo.recomputeGoalFromMilestones(m.goalId)
        }
    }

    fun addMilestone(goalId: String, title: String, order: Int) {
        viewModelScope.launch {
            val now = D.now()
            repo.saveMilestone(
                MilestoneEntity(
                    id = D.id(), goalId = goalId, title = title.trim(), done = false,
                    sortOrder = order, createdAt = now, updatedAt = now
                )
            )
            repo.recomputeGoalFromMilestones(goalId)
        }
    }

    fun deleteMilestone(m: MilestoneEntity) {
        viewModelScope.launch {
            repo.deleteMilestone(m.id)
            repo.recomputeGoalFromMilestones(m.goalId)
        }
    }
}

class GoalEditViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Graph.repo

    suspend fun load(id: String): GoalEntity? = repo.getGoal(id)

    fun save(g: GoalEntity, oldProgress: Int?, onDone: () -> Unit) {
        viewModelScope.launch {
            repo.saveGoal(g)
            if (oldProgress == null || oldProgress != g.progress) {
                repo.addGoalLog(g.id, g.progress)
            }
            onDone()
        }
    }
}

@Composable
fun GoalsScreen(nav: NavHostController, vm: GoalsViewModel = viewModel()) {
    val goals by vm.goals.collectAsState()
    val loc = currentLocale()
    val today = D.today()
    var tab by remember { mutableStateOf(0) }
    var catFilter by remember { mutableStateOf("") }
    var showFilters by remember { mutableStateOf(false) }

    val shown = goals.filter { g ->
        val tabOk = when (tab) {
            0 -> !g.archived && g.status != "COMPLETED"
            1 -> !g.archived && g.status == "COMPLETED"
            else -> g.archived
        }
        tabOk && (catFilter.isEmpty() || g.category == catFilter)
    }
    val tabs = listOf(R.string.goals_active, R.string.goals_completed, R.string.goals_archived)

    AppScaffold(
        title = stringResource(R.string.goals_title),
        tab = true,
        actions = {
            TextButton(onClick = { showFilters = !showFilters }) {
                Text(stringResource(R.string.filters))
            }
        },
        fab = {
            FloatingActionButton(onClick = { nav.navigate(Routes.goalEdit("new")) }) {
                Icon(Icons.Default.Add, contentDescription = null)
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            TabRow(selectedTabIndex = tab) {
                tabs.forEachIndexed { i, res ->
                    Tab(
                        selected = tab == i,
                        onClick = { tab = i },
                        text = { Text(stringResource(res)) }
                    )
                }
            }
            if (showFilters) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    ChoiceChips(
                        options = listOf("") + GOAL_CATS,
                        selected = catFilter,
                        onSelect = { catFilter = it }
                    ) { c -> if (c.isEmpty()) stringResource(R.string.all) else goalCatLabel(c) }
                }
            }
            if (shown.isEmpty()) {
                EmptyState("🎯", stringResource(R.string.goals_empty), Modifier.weight(1f))
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(shown, key = { it.id }) { g ->
                        GoalCard(g, today, loc) { nav.navigate(Routes.goalDetail(g.id)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun GoalCard(g: GoalEntity, today: Long, loc: Locale, onOpen: () -> Unit) {
    val daysLeft: Long? = if (g.targetEpochDay > 0L) g.targetEpochDay - today else null
    val leftText = when {
        daysLeft == null -> ""
        daysLeft >= 0L -> stringResource(R.string.goal_days_left, Fmt.num(daysLeft.toInt(), loc))
        else -> stringResource(R.string.goal_overdue)
    }
    AppCard(Modifier.fillMaxWidth(), onClick = onOpen) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(goalCatEmoji(g.category), fontSize = 24.sp)
                Spacer(Modifier.size(10.dp))
                Text(
                    g.title,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    Fmt.num(g.progress, loc) + "%",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            ProgressBar(g.progress / 100f)
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Pill(goalCatLabel(g.category), MaterialTheme.colorScheme.secondary)
                Pill(goalStatusLabel(g.status), goalStatusColor(g.status))
                if (leftText.isNotEmpty()) {
                    Pill(leftText, if (daysLeft != null && daysLeft < 0L) Danger else MaterialTheme.colorScheme.tertiary)
                }
            }
        }
    }
}

@Composable
fun GoalDetailScreen(nav: NavHostController, id: String, vm: GoalsViewModel = viewModel()) {
    val goals by vm.goals.collectAsState()
    val allMs by vm.milestones.collectAsState()
    val allLogs by vm.logs.collectAsState()
    val g = goals.firstOrNull { it.id == id }
    val loc = currentLocale()
    var newMs by remember { mutableStateOf("") }

    AppScaffold(
        title = g?.title ?: "",
        onBack = { nav.popBackStack() },
        actions = {
            TextButton(onClick = { nav.navigate(Routes.goalEdit(id)) }) {
                Text(stringResource(R.string.edit))
            }
        }
    ) { pad ->
        if (g == null) {
            EmptyState("🎯", stringResource(R.string.goals_empty), Modifier.padding(pad))
        } else {
            val ms = allMs.filter { it.goalId == id }
            val logs = allLogs.filter { it.goalId == id }.take(8)
            var slider by remember(g.progress) { mutableStateOf(g.progress.toFloat()) }

            Column(
                Modifier
                    .padding(pad)
                    .verticalScroll(rememberScrollState())
                    .imePadding()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                AppCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(goalCatEmoji(g.category), fontSize = 32.sp)
                            Spacer(Modifier.size(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(g.title, style = MaterialTheme.typography.titleLarge)
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Pill(goalCatLabel(g.category), MaterialTheme.colorScheme.secondary)
                                    Pill(goalStatusLabel(g.status), goalStatusColor(g.status))
                                    if (g.archived) {
                                        Pill(stringResource(R.string.goals_archived), MaterialTheme.colorScheme.outline)
                                    }
                                }
                            }
                        }
                        if (g.description.isNotBlank()) {
                            Text(g.description, style = MaterialTheme.typography.bodyMedium)
                        }
                        Text(
                            stringResource(R.string.goal_start) + ": " + Fmt.date(g.startEpochDay, loc),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            stringResource(R.string.goal_target) + ": " +
                                if (g.targetEpochDay > 0L) Fmt.date(g.targetEpochDay, loc) else stringResource(R.string.goal_no_date),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                AppCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        SectionTitle(stringResource(R.string.goal_progress))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            ProgressRing(
                                progress = g.progress / 100f,
                                diameter = 88.dp,
                                label = Fmt.num(g.progress, loc) + "%"
                            )
                            Column(Modifier.weight(1f)) {
                                if (ms.isEmpty()) {
                                    Slider(
                                        value = slider,
                                        onValueChange = { slider = it },
                                        onValueChangeFinished = { vm.setProgress(g, slider.toInt()) },
                                        valueRange = 0f..100f,
                                        steps = 19
                                    )
                                    Text(
                                        Fmt.num(slider.toInt(), loc) + "%",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                } else {
                                    Text(
                                        stringResource(R.string.goal_auto_progress),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }

                AppCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        SectionTitle(stringResource(R.string.goal_milestones))
                        ms.forEach { m ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = m.done, onCheckedChange = { vm.toggleMilestone(m) })
                                Text(
                                    m.title,
                                    modifier = Modifier.weight(1f),
                                    textDecoration = if (m.done) TextDecoration.LineThrough else TextDecoration.None
                                )
                                IconButton(onClick = { vm.deleteMilestone(m) }) {
                                    Icon(Icons.Default.Close, contentDescription = null)
                                }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = newMs,
                                onValueChange = { newMs = it },
                                singleLine = true,
                                placeholder = { Text(stringResource(R.string.goal_milestone_hint)) },
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = {
                                if (newMs.isNotBlank()) {
                                    vm.addMilestone(id, newMs, ms.size)
                                    newMs = ""
                                }
                            }) {
                                Icon(Icons.Default.Add, contentDescription = null)
                            }
                        }
                    }
                }

                if (logs.isNotEmpty()) {
                    AppCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            SectionTitle(stringResource(R.string.goal_history))
                            logs.forEach { l ->
                                Text(
                                    Fmt.date(l.epochDay, loc) + "  —  " + Fmt.num(l.progress, loc) + "%",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }
                }

                if (g.notes.isNotBlank()) {
                    AppCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            SectionTitle(stringResource(R.string.goal_notes))
                            Text(g.notes, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (g.status != "COMPLETED") {
                        Button(onClick = { vm.markCompleted(g) }, modifier = Modifier.weight(1f)) {
                            Text(stringResource(R.string.goal_mark_done))
                        }
                    }
                    OutlinedButton(
                        onClick = { vm.setArchived(g, !g.archived) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(stringResource(if (g.archived) R.string.goal_unarchive else R.string.goal_archive))
                    }
                }
                Text(
                    stringResource(R.string.goal_history_safe),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun GoalEditScreen(nav: NavHostController, id: String, vm: GoalEditViewModel = viewModel()) {
    val ctx = LocalContext.current
    val loc = currentLocale()
    val isNew = id == "new"
    var original by remember { mutableStateOf<GoalEntity?>(null) }
    var title by rememberSaveable { mutableStateOf("") }
    var desc by rememberSaveable { mutableStateOf("") }
    var category by rememberSaveable { mutableStateOf("personal") }
    var start by rememberSaveable { mutableStateOf(D.today()) }
    var target by rememberSaveable { mutableStateOf(0L) }
    var status by rememberSaveable { mutableStateOf("ACTIVE") }
    var notes by rememberSaveable { mutableStateOf("") }
    var showErr by remember { mutableStateOf(false) }
    var dateErr by remember { mutableStateOf(false) }

    LaunchedEffect(id) {
        if (!isNew) {
            val g = vm.load(id)
            if (g != null) {
                original = g
                if (title.isEmpty()) {
                    title = g.title
                    desc = g.description
                    category = g.category
                    start = g.startEpochDay
                    target = g.targetEpochDay
                    status = g.status
                    notes = g.notes
                }
            }
        }
    }

    AppScaffold(
        title = stringResource(if (isNew) R.string.goal_new else R.string.goal_edit),
        onBack = { nav.popBackStack() }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .imePadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text(stringResource(R.string.goal_title)) },
                isError = showErr && title.isBlank(),
                supportingText = {
                    if (showErr && title.isBlank()) Text(stringResource(R.string.goal_title_required))
                },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = desc,
                onValueChange = { desc = it },
                label = { Text(stringResource(R.string.goal_desc)) },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )

            Text(stringResource(R.string.goal_category), style = MaterialTheme.typography.labelLarge)
            ChoiceChips(
                options = GOAL_CATS,
                selected = category,
                onSelect = { category = it }
            ) { c -> goalCatEmoji(c) + " " + goalCatLabel(c) }

            PickerField(stringResource(R.string.goal_start), Fmt.date(start, loc)) {
                showDatePicker(ctx, start) { picked -> start = picked }
            }
            PickerField(
                stringResource(R.string.goal_target),
                if (target > 0L) Fmt.date(target, loc) else stringResource(R.string.goal_no_date)
            ) {
                showDatePicker(ctx, if (target > 0L) target else start + 30) { picked -> target = picked }
            }
            if (target > 0L) {
                TextButton(onClick = { target = 0L }) { Text(stringResource(R.string.clear)) }
            }
            if (dateErr) {
                Text(
                    stringResource(R.string.goal_date_invalid),
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Text(stringResource(R.string.goal_status), style = MaterialTheme.typography.labelLarge)
            ChoiceChips(
                options = listOf("ACTIVE", "PAUSED", "COMPLETED"),
                selected = status,
                onSelect = { status = it }
            ) { s -> goalStatusLabel(s) }

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text(stringResource(R.string.goal_notes)) },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(4.dp))
            Button(
                onClick = {
                    showErr = true
                    val bad = target > 0L && target < start
                    dateErr = bad
                    if (title.isNotBlank() && !bad) {
                        val now = D.now()
                        val o = original
                        var p = o?.progress ?: 0
                        if (status == "COMPLETED") p = 100
                        if (status != "COMPLETED" && p >= 100) p = 99
                        val g = GoalEntity(
                            id = o?.id ?: D.id(),
                            title = title.trim(),
                            description = desc.trim(),
                            category = category,
                            startEpochDay = start,
                            targetEpochDay = target,
                            progress = p,
                            status = status,
                            notes = notes.trim(),
                            archived = o?.archived ?: false,
                            createdAt = o?.createdAt ?: now,
                            updatedAt = now
                        )
                        vm.save(g, o?.progress) { nav.popBackStack() }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text(stringResource(R.string.save))
            }
        }
    }
}
