package com.lifemanager.pro.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        TaskEntity::class, GoalEntity::class, MilestoneEntity::class, GoalLogEntity::class,
        HabitEntity::class, HabitLogEntity::class, ReminderEntity::class, DiaryEntity::class,
        TimeEntryEntity::class, FocusSessionEntity::class, TxnEntity::class, BudgetEntity::class,
        SavingsGoalEntity::class, SavingsEntryEntity::class, PrayerEntity::class,
        QuranLogEntity::class, AmalEntity::class, AmalLogEntity::class, DeedEntity::class,
        ReviewEntity::class, LetterEntity::class, NoteEntity::class, CategoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class LifeDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
    abstract fun categoryDao(): CategoryDao
    abstract fun habitDao(): HabitDao
    abstract fun habitLogDao(): HabitLogDao
    abstract fun goalDao(): GoalDao
    abstract fun milestoneDao(): MilestoneDao
    abstract fun goalLogDao(): GoalLogDao
    abstract fun reminderDao(): ReminderDao
    abstract fun diaryDao(): DiaryDao
    abstract fun timeEntryDao(): TimeEntryDao
    abstract fun focusSessionDao(): FocusSessionDao
    abstract fun txnDao(): TxnDao
    abstract fun budgetDao(): BudgetDao
    abstract fun savingsGoalDao(): SavingsGoalDao
    abstract fun savingsEntryDao(): SavingsEntryDao

    companion object {
        @Volatile
        private var instance: LifeDatabase? = null

        fun get(context: Context): LifeDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    LifeDatabase::class.java,
                    "life_manager.db"
                ).build().also { instance = it }
            }
        }
    }
}
