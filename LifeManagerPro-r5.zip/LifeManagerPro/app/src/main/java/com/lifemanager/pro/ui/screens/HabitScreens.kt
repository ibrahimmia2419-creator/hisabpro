@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.lifemanager.pro.ui.screens

import android.app.Application
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.lifemanager.pro.R
import com.lifemanager.pro.data.Graph
import com.lifemanager.pro.data.HabitEntity
import com.lifemanager.pro.data.HabitLogEntity
import com.lifemanager.pro.data.HabitMath
import com.lifemanager.pro.ui.components.AppCard
import com.lifemanager.pro.ui.components.AppScaffold
import com.lifemanager.pro.ui.components.CheckCircle
import com.lifemanager.pro.ui.components.ChoiceChips
import com.lifemanager.pro.ui.components.ConfirmDialog
import com.lifemanager.pro.ui.components.EmptyState
import com.lifemanager.pro.ui.components.MonthGrid
import com.lifemanager.pro.ui.components.Pill
import com.lifemanager.pro.ui.components.ProgressRing
import com.lifemanager.pro.ui.components.StatTile
import com.lifemanager.pro.ui.components.WeekDots
import com.lifemanager.pro.ui.components.freqLabel
import com.lifemanager.pro.ui.components.unitLabel
import com.lifemanager.pro.ui.nav.Routes
import com.lifemanager.pro.ui.theme.Info
import com.lifemanager.pro.ui.theme.Muted
import com.lifemanager.pro.ui.theme.Success
import com.lifemanager.pro.ui.theme.Warning
import com.lifemanager.pro.util.D
import com.lifemanager.pro.util.Fmt
import com.lifemanager.pro.util.currentLocale
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.YearMonth
import java.util.Locale

class HabitsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Graph.repo

    val habits: StateFlow<List<HabitEntity>> =
        repo.habits.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    val logs: StateFlow<List<HabitLogEntity>> =
        repo.habitLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    fun toggle(habitId: String, day: Long) {
        viewModelScope.launch { repo.toggleHabit(habitId, day) }
    }
}

class HabitEditViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Graph.repo

    suspend fun load(id: String): HabitEntity? = repo.getHabit(id)

    fun save(h: HabitEntity, onDone: () -> Unit) {
        viewModelScope.launch {
            repo.saveHabit(h)
            onDone()
        }
    }
}

/** habit id -> set of days it was done. */
fun daysByHabit(logs: List<HabitLogEntity>): Map<String, Set<Long>> =
    logs.groupBy { it.habitId }.mapValues { entry -> entry.value.map { it.epochDay }.toSet() }

@Composable
fun HabitsScreen(nav: NavHostController, vm: HabitsViewModel = viewModel()) {
    val habits by vm.habits.collectAsState()
    val logs by vm.logs.collectAsState()
    var archived by remember { mutableStateOf(false) }
    val loc = currentLocale()
    val today = D.today()
    val byHabit = remember(logs) { daysByHabit(logs) }
    val shown = habits.filter { it.archived == archived }
    val active = habits.filter { !it.archived }
    val doneToday = active.count { byHabit[it.id]?.contains(today) == true }

    AppScaffold(
        title = stringResource(R.string.habits_title),
        tab = true,
        actions = {
            TextButton(onClick = { archived = !archived }) {
                Text(stringResource(if (archived) R.string.habits_active else R.string.habits_archived))
            }
        },
        fab = {
            FloatingActionButton(onClick = { nav.navigate(Routes.habitEdit("new")) }) {
                Icon(Icons.Default.Add, contentDescription = null)
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (!archived && active.isNotEmpty()) {
                AppCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(
                        Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        ProgressRing(
                            progress = doneToday.toFloat() / active.size.toFloat(),
                            diameter = 64.dp,
                            stroke = 8.dp
                        )
                        Text(
                            stringResource(
                                R.string.habit_today_summary,
                                Fmt.num(doneToday, loc),
                                Fmt.num(active.size, loc)
                            ),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
            if (shown.isEmpty()) {
                EmptyState("🔁", stringResource(R.string.habits_empty), Modifier.weight(1f))
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(shown, key = { it.id }) { h ->
                        HabitCard(
                            h = h,
                            days = byHabit[h.id] ?: emptySet(),
                            today = today,
                            loc = loc,
                            showCheck = !archived,
                            onToggle = { vm.toggle(h.id, today) },
                            onOpen = { nav.navigate(Routes.habitDetail(h.id)) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HabitCard(
    h: HabitEntity,
    days: Set<Long>,
    today: Long,
    loc: Locale,
    showCheck: Boolean,
    onToggle: () -> Unit,
    onOpen: () -> Unit
) {
    val st = HabitMath.stat(h.frequency, h.target, days, today)
    val fl = freqLabel(h.frequency)
    val ul = unitLabel(h.frequency)
    val sub = if (h.frequency == "DAILY") {
        fl
    } else {
        fl + " · " + Fmt.num(st.periodCount, loc) + "/" + Fmt.num(st.periodNeed, loc)
    }
    AppCard(Modifier.fillMaxWidth(), onClick = onOpen) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(h.emoji, fontSize = 28.sp)
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    h.name,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    sub,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(6.dp))
                WeekDots(days, today)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("🔥 " + Fmt.num(st.current, loc), fontWeight = FontWeight.Bold)
                Text(
                    ul,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (showCheck) {
                    Spacer(Modifier.height(6.dp))
                    CheckCircle(done = st.doneToday, onClick = onToggle)
                }
            }
        }
    }
}

@Composable
fun HabitDetailScreen(nav: NavHostController, id: String, vm: HabitsViewModel = viewModel()) {
    val habits by vm.habits.collectAsState()
    val logs by vm.logs.collectAsState()
    val h = habits.firstOrNull { it.id == id }
    val loc = currentLocale()
    val today = D.today()
    var month by remember { mutableStateOf(YearMonth.now()) }
    val days = remember(logs, id) { logs.filter { it.habitId == id }.map { it.epochDay }.toSet() }

    AppScaffold(
        title = h?.name ?: "",
        onBack = { nav.popBackStack() },
        actions = {
            TextButton(onClick = { nav.navigate(Routes.habitEdit(id)) }) {
                Text(stringResource(R.string.edit))
            }
        }
    ) { pad ->
        if (h == null) {
            EmptyState("🔁", stringResource(R.string.habits_empty), Modifier.padding(pad))
        } else {
            val st = HabitMath.stat(h.frequency, h.target, days, today)
            val periodLabel = when (h.frequency) {
                "MONTHLY" -> stringResource(R.string.stat_this_month)
                "WEEKLY" -> stringResource(R.string.stat_this_week)
                else -> stringResource(R.string.stat_today)
            }
            Column(
                Modifier
                    .padding(pad)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(h.emoji, fontSize = 40.sp)
                    Column {
                        Text(h.name, style = MaterialTheme.typography.titleLarge)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Pill(freqLabel(h.frequency), MaterialTheme.colorScheme.secondary)
                            if (h.archived) {
                                Pill(stringResource(R.string.habits_archived), Muted)
                            }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile("🔥 " + Fmt.num(st.current, loc), stringResource(R.string.stat_streak_now), Warning, Modifier.weight(1f))
                    StatTile(Fmt.num(st.best, loc), stringResource(R.string.stat_streak_best), Success, Modifier.weight(1f))
                    StatTile(Fmt.percent(st.rate, loc), stringResource(R.string.stat_rate), Info, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile(Fmt.num(st.total, loc), stringResource(R.string.stat_total), MaterialTheme.colorScheme.secondary, Modifier.weight(1f))
                    StatTile(
                        Fmt.num(st.periodCount, loc) + "/" + Fmt.num(st.periodNeed, loc),
                        periodLabel,
                        MaterialTheme.colorScheme.tertiary,
                        Modifier.weight(1f)
                    )
                }
                MonthGrid(
                    month = month,
                    selected = -1L,
                    marked = emptySet(),
                    filled = days,
                    onSelect = { d -> if (d <= today) vm.toggle(id, d) },
                    onPrev = { month = month.minusMonths(1) },
                    onNext = { month = month.plusMonths(1) }
                )
                Text(
                    stringResource(R.string.habit_tap_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun HabitEditScreen(nav: NavHostController, id: String, vm: HabitEditViewModel = viewModel()) {
    val isNew = id == "new"
    var original by remember { mutableStateOf<HabitEntity?>(null) }
    var name by rememberSaveable { mutableStateOf("") }
    var emoji by rememberSaveable { mutableStateOf("✅") }
    var freq by rememberSaveable { mutableStateOf("DAILY") }
    var target by rememberSaveable { mutableStateOf(3) }
    var showErr by remember { mutableStateOf(false) }
    var confirmArchive by remember { mutableStateOf(false) }
    val loc = currentLocale()

    LaunchedEffect(id) {
        if (!isNew) {
            val h = vm.load(id)
            if (h != null) {
                original = h
                if (name.isEmpty()) {
                    name = h.name
                    emoji = h.emoji
                    freq = h.frequency
                    target = h.target
                }
            }
        }
    }

    val presetEmoji = listOf("📖", "🏃", "💧", "⏰", "📚", "🌙")
    val presetName = listOf(
        stringResource(R.string.preset_reading),
        stringResource(R.string.preset_exercise),
        stringResource(R.string.preset_water),
        stringResource(R.string.preset_wake),
        stringResource(R.string.preset_english),
        stringResource(R.string.preset_sleep)
    )
    val maxTarget = if (freq == "WEEKLY") 7 else 31

    AppScaffold(
        title = stringResource(if (isNew) R.string.habit_new else R.string.habit_edit),
        onBack = { nav.popBackStack() }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .imePadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (isNew) {
                Text(stringResource(R.string.habit_suggestions), style = MaterialTheme.typography.labelLarge)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    for (i in presetName.indices) {
                        AssistChip(
                            onClick = {
                                name = presetName[i]
                                emoji = presetEmoji[i]
                            },
                            label = { Text(presetEmoji[i] + " " + presetName[i]) }
                        )
                    }
                }
            }

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                singleLine = true,
                label = { Text(stringResource(R.string.habit_name)) },
                isError = showErr && name.isBlank(),
                supportingText = {
                    if (showErr && name.isBlank()) Text(stringResource(R.string.habit_name_required))
                },
                modifier = Modifier.fillMaxWidth()
            )

            Text(stringResource(R.string.habit_icon), style = MaterialTheme.typography.labelLarge)
            ChoiceChips(
                options = listOf("✅", "📖", "🏃", "💧", "⏰", "🌙", "🥗", "🧘", "✍️", "🙏", "💪", "🎯"),
                selected = emoji,
                onSelect = { emoji = it }
            ) { e -> e }

            Text(stringResource(R.string.habit_freq), style = MaterialTheme.typography.labelLarge)
            ChoiceChips(
                options = listOf("DAILY", "WEEKLY", "MONTHLY"),
                selected = freq,
                onSelect = {
                    freq = it
                    if (target > (if (it == "WEEKLY") 7 else 31)) target = 1
                }
            ) { f -> freqLabel(f) }

            if (freq != "DAILY") {
                Text(
                    stringResource(if (freq == "WEEKLY") R.string.habit_target_week else R.string.habit_target_month),
                    style = MaterialTheme.typography.labelLarge
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = { if (target > 1) target-- }) { Text("−") }
                    Text(Fmt.num(target, loc), style = MaterialTheme.typography.titleLarge)
                    OutlinedButton(onClick = { if (target < maxTarget) target++ }) { Text("+") }
                }
            }

            Spacer(Modifier.height(4.dp))
            Button(
                onClick = {
                    showErr = true
                    if (name.isNotBlank()) {
                        val now = D.now()
                        val o = original
                        val h = HabitEntity(
                            id = o?.id ?: D.id(),
                            name = name.trim(),
                            emoji = emoji,
                            frequency = freq,
                            target = if (freq == "DAILY") 1 else target.coerceIn(1, maxTarget),
                            archived = o?.archived ?: false,
                            sortOrder = o?.sortOrder ?: 0,
                            createdAt = o?.createdAt ?: now,
                            updatedAt = now
                        )
                        vm.save(h) { nav.popBackStack() }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text(stringResource(R.string.save))
            }

            val o = original
            if (!isNew && o != null) {
                OutlinedButton(
                    onClick = { confirmArchive = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(stringResource(if (o.archived) R.string.habit_unarchive else R.string.habit_archive))
                }
                Text(
                    stringResource(R.string.habit_history_safe),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    val cur = original
    if (confirmArchive && cur != null) {
        ConfirmDialog(
            title = stringResource(if (cur.archived) R.string.habit_unarchive else R.string.habit_archive),
            text = stringResource(R.string.habit_archive_text),
            confirm = stringResource(R.string.ok),
            cancel = stringResource(R.string.cancel),
            onConfirm = {
                confirmArchive = false
                vm.save(cur.copy(archived = !cur.archived, updatedAt = D.now())) { nav.popBackStack() }
            },
            onDismiss = { confirmArchive = false }
        )
    }
}
