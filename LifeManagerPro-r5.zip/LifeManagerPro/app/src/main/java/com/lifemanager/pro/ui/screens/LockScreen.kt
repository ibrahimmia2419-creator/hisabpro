package com.lifemanager.pro.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.lifemanager.pro.R
import com.lifemanager.pro.data.AppSettings
import com.lifemanager.pro.data.Graph
import com.lifemanager.pro.security.Biometrics
import kotlinx.coroutines.launch

@Composable
fun LockScreen(activity: FragmentActivity, onUnlocked: () -> Unit) {
    val s by Graph.prefs.settings.collectAsState(initial = AppSettings())
    val scope = rememberCoroutineScope()
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    val canBio = remember { Biometrics.available(activity) }
    val bioTitle = stringResource(R.string.lock_biometric_title)
    val bioCancel = stringResource(R.string.cancel)

    LaunchedEffect(s.biometric) {
        if (s.biometric && canBio) {
            Biometrics.prompt(activity, bioTitle, bioCancel, onUnlocked)
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .imePadding()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("🔒", fontSize = 48.sp)
            Text(
                stringResource(R.string.lock_title),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                stringResource(R.string.lock_enter_pin),
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedTextField(
                value = pin,
                onValueChange = { v ->
                    if (v.length <= 6 && v.all { it.isDigit() }) {
                        pin = v
                        wrong = false
                    }
                },
                singleLine = true,
                isError = wrong,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier.fillMaxWidth()
            )
            if (wrong) {
                Text(stringResource(R.string.pin_wrong), color = MaterialTheme.colorScheme.error)
            }
            Button(
                onClick = {
                    scope.launch {
                        if (Graph.prefs.verifyPin(pin)) {
                            onUnlocked()
                        } else {
                            wrong = true
                            pin = ""
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(stringResource(R.string.lock_unlock))
            }
            if (s.biometric && canBio) {
                OutlinedButton(
                    onClick = { Biometrics.prompt(activity, bioTitle, bioCancel, onUnlocked) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(stringResource(R.string.lock_use_biometric))
                }
            }
        }
    }
}
