package com.lifemanager.pro.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream

/** Photos and files attached to diary entries and notes live in the app's private folder. */
object Attachments {
    private fun dir(ctx: Context): File {
        val d = File(ctx.filesDir, "attachments")
        if (!d.exists()) d.mkdirs()
        return d
    }

    fun file(ctx: Context, name: String): File = File(dir(ctx), name)

    fun delete(ctx: Context, name: String) {
        try {
            file(ctx, name).delete()
        } catch (e: Exception) {
            // ignore
        }
    }

    fun split(names: String): List<String> = names.split("\n").filter { it.isNotBlank() }

    fun join(list: List<String>): String = list.joinToString("\n")

    /** Copies a picked picture into app storage (smaller, upright) and returns its file name. */
    fun importImage(ctx: Context, uri: Uri): String? {
        return try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            var bmp: Bitmap = ctx.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return null
            val orientation = ctx.contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
            val degrees = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (degrees != 0f) {
                val m = Matrix()
                m.postRotate(degrees)
                val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                if (rotated !== bmp) bmp.recycle()
                bmp = rotated
            }
            val name = D.id() + ".jpg"
            FileOutputStream(file(ctx, name)).use { out -> bmp.compress(Bitmap.CompressFormat.JPEG, 85, out) }
            bmp.recycle()
            name
        } catch (e: Exception) {
            null
        }
    }

    fun decodeSampled(f: File, maxPx: Int): Bitmap? {
        if (!f.exists()) return null
        val bounds = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        BitmapFactory.decodeFile(f.absolutePath, bounds)
        var sample = 1
        while (bounds.outWidth / sample > maxPx || bounds.outHeight / sample > maxPx) sample *= 2
        val opts = BitmapFactory.Options()
        opts.inSampleSize = sample
        return BitmapFactory.decodeFile(f.absolutePath, opts)
    }
}
