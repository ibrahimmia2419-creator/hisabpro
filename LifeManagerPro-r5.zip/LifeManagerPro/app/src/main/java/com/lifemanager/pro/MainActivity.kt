package com.lifemanager.pro

import android.os.Bundle
import android.os.SystemClock
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.lifemanager.pro.data.BootPrefs
import com.lifemanager.pro.ui.nav.AppRoot
import com.lifemanager.pro.ui.screens.LockScreen
import com.lifemanager.pro.ui.theme.LifeTheme
import com.lifemanager.pro.util.applySecure

class MainActivity : AppCompatActivity() {
    private var locked by mutableStateOf(false)
    private var lastStop = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        locked = savedInstanceState?.getBoolean("locked") ?: BootPrefs.pinEnabled(this)
        applySecure(BootPrefs.secure(this))
        setContent {
            LifeTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    if (locked) {
                        LockScreen(activity = this@MainActivity, onUnlocked = { locked = false })
                    } else {
                        AppRoot()
                    }
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean("locked", locked)
    }

    override fun onStart() {
        super.onStart()
        val away = SystemClock.elapsedRealtime() - lastStop
        if (BootPrefs.pinEnabled(this) && lastStop > 0L && away > 30_000L) {
            locked = true
        }
        applySecure(BootPrefs.secure(this))
    }

    override fun onStop() {
        super.onStop()
        lastStop = SystemClock.elapsedRealtime()
    }
}
