package com.lifemanager.pro.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.lifemanager.pro.R
import com.lifemanager.pro.ui.components.AppCard
import com.lifemanager.pro.ui.components.AppScaffold
import com.lifemanager.pro.ui.components.Pill
import com.lifemanager.pro.ui.nav.Routes
import com.lifemanager.pro.ui.theme.Muted

private class MoreItem(val emoji: String, val title: Int, val subtitle: Int, val route: String?)

@Composable
fun MoreScreen(nav: NavHostController) {
    val modules = listOf(
        MoreItem("⏰", R.string.mod_reminders, R.string.mod_reminders_sub, Routes.REMINDERS),
        MoreItem("📔", R.string.mod_diary, R.string.mod_diary_sub, Routes.DIARY),
        MoreItem("⏱️", R.string.mod_time, R.string.mod_time_sub, Routes.TIME),
        MoreItem("💰", R.string.mod_finance, R.string.mod_finance_sub, Routes.FINANCE),
        MoreItem("🕌", R.string.mod_islamic, R.string.mod_islamic_sub, null),
        MoreItem("📝", R.string.mod_review, R.string.mod_review_sub, null),
        MoreItem("📚", R.string.mod_library, R.string.mod_library_sub, null),
        MoreItem("📊", R.string.mod_reports, R.string.mod_reports_sub, null),
        MoreItem("💾", R.string.mod_backup, R.string.mod_backup_sub, null),
        MoreItem("⚙️", R.string.settings_title, R.string.mod_settings_sub, Routes.SETTINGS)
    )

    AppScaffold(title = stringResource(R.string.more_title), tab = true) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(modules) { item -> MoreRow(item, nav) }
        }
    }
}

@Composable
private fun MoreRow(item: MoreItem, nav: NavHostController) {
    val r = item.route
    val click: (() -> Unit)? = if (r == null) null else fun() { nav.navigate(r) }
    AppCard(Modifier.fillMaxWidth(), onClick = click) {
        Row(
            Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(item.emoji, fontSize = 26.sp)
            Spacer(Modifier.size(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    stringResource(item.title),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    stringResource(item.subtitle),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (r == null) {
                Pill(stringResource(R.string.soon), Muted)
            }
        }
    }
}
