package com.lifemanager.pro.reminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.lifemanager.pro.data.FocusSessionEntity
import com.lifemanager.pro.data.FocusState
import com.lifemanager.pro.data.Graph
import com.lifemanager.pro.util.D
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Focus / break sessions. An alarm tells you when the time is up even if the app is closed. */
object FocusEngine {
    private const val CODE = 7001

    private fun pending(ctx: Context): PendingIntent {
        val i = Intent(ctx, FocusReceiver::class.java)
        return PendingIntent.getBroadcast(
            ctx, CODE, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun cancelAlarm(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(ctx))
    }

    suspend fun start(ctx: Context, kind: String, minutes: Int, label: String) {
        val now = System.currentTimeMillis()
        val end = now + minutes * 60_000L
        Graph.prefs.setFocusState(FocusState(kind, now, end, minutes, label))
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(ctx)
        try {
            if (ReminderScheduler.canUseExact(ctx)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, end, pi)
        }
    }

    /** Records a finished session once. Safe to call from both the alarm and the screen. */
    suspend fun complete(ctx: Context, notify: Boolean) {
        val f = Graph.prefs.currentFocus()
        if (!f.running) return
        val now = System.currentTimeMillis()
        if (now < f.endAt - 2000L) return
        Graph.repo.saveFocusSession(
            FocusSessionEntity(
                id = D.id(), label = f.label, startAt = f.startAt, endAt = f.endAt,
                plannedMin = f.plannedMin, actualMin = f.plannedMin, kind = f.kind,
                completed = true, epochDay = D.epochDayOf(f.startAt)
            )
        )
        Graph.prefs.setFocusState(FocusState())
        cancelAlarm(ctx)
        if (notify) NotificationHelper.showFocusDone(ctx, f.kind)
    }

    /** Stopping early keeps the minutes that were really spent. */
    suspend fun stop(ctx: Context) {
        val f = Graph.prefs.currentFocus()
        if (!f.running) return
        val now = System.currentTimeMillis()
        val spent = ((now - f.startAt) / 60_000L).toInt()
        if (spent >= 1) {
            Graph.repo.saveFocusSession(
                FocusSessionEntity(
                    id = D.id(), label = f.label, startAt = f.startAt, endAt = now,
                    plannedMin = f.plannedMin, actualMin = spent, kind = f.kind,
                    completed = false, epochDay = D.epochDayOf(f.startAt)
                )
            )
        }
        Graph.prefs.setFocusState(FocusState())
        cancelAlarm(ctx)
    }
}

class FocusReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val pending = goAsync()
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            try {
                FocusEngine.complete(app, true)
            } finally {
                pending.finish()
            }
        }
    }
}
