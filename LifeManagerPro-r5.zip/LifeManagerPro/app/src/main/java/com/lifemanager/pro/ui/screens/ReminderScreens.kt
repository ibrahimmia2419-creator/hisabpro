@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.lifemanager.pro.ui.screens

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.lifemanager.pro.R
import com.lifemanager.pro.data.Graph
import com.lifemanager.pro.data.ReminderEntity
import com.lifemanager.pro.reminder.ReminderScheduler
import com.lifemanager.pro.ui.components.AppCard
import com.lifemanager.pro.ui.components.AppScaffold
import com.lifemanager.pro.ui.components.ChoiceChips
import com.lifemanager.pro.ui.components.ConfirmDialog
import com.lifemanager.pro.ui.components.EmptyState
import com.lifemanager.pro.ui.components.PickerField
import com.lifemanager.pro.ui.components.Pill
import com.lifemanager.pro.ui.components.SectionTitle
import com.lifemanager.pro.ui.components.repeatLabel
import com.lifemanager.pro.ui.components.showDatePicker
import com.lifemanager.pro.ui.components.showTimePicker
import com.lifemanager.pro.ui.nav.Routes
import com.lifemanager.pro.ui.theme.Info
import com.lifemanager.pro.ui.theme.Muted
import com.lifemanager.pro.util.D
import com.lifemanager.pro.util.Fmt
import com.lifemanager.pro.util.currentLocale
import com.lifemanager.pro.util.openAutostart
import com.lifemanager.pro.util.openBatterySettings
import com.lifemanager.pro.util.openExactAlarmSettings
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale

class RemindersViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Graph.repo

    val reminders: StateFlow<List<ReminderEntity>> =
        repo.reminders.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    fun setEnabled(r: ReminderEntity, on: Boolean) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            var upd = r.copy(enabled = on, updatedAt = now)
            if (on && upd.repeatMode != "NONE" && upd.triggerAt <= now) {
                upd = upd.copy(triggerAt = ReminderScheduler.nextAfter(upd, now))
            }
            repo.saveReminder(upd)
            ReminderScheduler.schedule(getApplication<Application>(), upd)
        }
    }
}

class ReminderEditViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Graph.repo

    suspend fun load(id: String): ReminderEntity? = repo.getReminder(id)

    fun save(r: ReminderEntity, onDone: () -> Unit) {
        viewModelScope.launch {
            repo.saveReminder(r)
            ReminderScheduler.schedule(getApplication<Application>(), r)
            onDone()
        }
    }

    fun delete(id: String, onDone: () -> Unit) {
        viewModelScope.launch {
            repo.deleteReminder(id)
            ReminderScheduler.cancel(getApplication<Application>(), id)
            onDone()
        }
    }
}

@Composable
fun RemindersScreen(nav: NavHostController, vm: RemindersViewModel = viewModel()) {
    val list by vm.reminders.collectAsState()
    val loc = currentLocale()
    val now = System.currentTimeMillis()
    val sorted = list.sortedWith(compareBy<ReminderEntity>({ !it.enabled }, { it.triggerAt }))

    AppScaffold(
        title = stringResource(R.string.reminders_title),
        onBack = { nav.popBackStack() },
        fab = {
            FloatingActionButton(onClick = { nav.navigate(Routes.reminderEdit("new")) }) {
                Icon(Icons.Default.Add, contentDescription = null)
            }
        }
    ) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { HealthCard() }
            if (sorted.isEmpty()) {
                item { EmptyState("⏰", stringResource(R.string.reminders_empty)) }
            } else {
                items(sorted, key = { it.id }) { r ->
                    ReminderCard(
                        r = r,
                        now = now,
                        loc = loc,
                        onOpen = {
                            if (r.linkedTaskId.isNotEmpty()) {
                                nav.navigate(Routes.taskEdit(r.linkedTaskId))
                            } else {
                                nav.navigate(Routes.reminderEdit(r.id))
                            }
                        },
                        onToggle = { on -> vm.setEnabled(r, on) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ReminderCard(
    r: ReminderEntity,
    now: Long,
    loc: Locale,
    onOpen: () -> Unit,
    onToggle: (Boolean) -> Unit
) {
    val day = D.epochDayOf(r.triggerAt)
    val whenText = Fmt.date(day, loc) + " · " + Fmt.time(D.minuteOfDay(r.triggerAt), loc)
    val passed = r.repeatMode == "NONE" && r.triggerAt <= now
    AppCard(Modifier.fillMaxWidth(), onClick = onOpen) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    r.title,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    whenText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(6.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Pill(repeatLabel(r.repeatMode), MaterialTheme.colorScheme.secondary)
                    if (r.linkedTaskId.isNotEmpty()) {
                        Pill(stringResource(R.string.reminder_from_task), Info)
                    }
                    if (passed) {
                        Pill(stringResource(R.string.reminder_passed), Muted)
                    }
                }
            }
            Switch(checked = r.enabled && !passed, onCheckedChange = onToggle, enabled = !passed)
        }
    }
}

@Composable
private fun HealthCard() {
    val ctx = LocalContext.current
    var notifOk by remember {
        mutableStateOf(
            Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> notifOk = granted }
    val exactOk = ReminderScheduler.canUseExact(ctx)

    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionTitle(stringResource(R.string.reminder_health_title))
            if (!notifOk) {
                Text(
                    stringResource(R.string.notif_not_allowed),
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium
                )
                Button(onClick = {
                    if (Build.VERSION.SDK_INT >= 33) {
                        launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }) { Text(stringResource(R.string.notif_allow)) }
            }
            if (!exactOk) {
                Text(
                    stringResource(R.string.reminder_exact_needed),
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium
                )
                Button(onClick = { ctx.openExactAlarmSettings() }) {
                    Text(stringResource(R.string.reminder_exact_allow))
                }
            }
            Text(
                stringResource(R.string.set_battery_hint),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                OutlinedButton(onClick = { ctx.openBatterySettings() }) {
                    Text(stringResource(R.string.set_battery))
                }
                OutlinedButton(onClick = { ctx.openAutostart() }) {
                    Text(stringResource(R.string.reminder_autostart))
                }
            }
        }
    }
}

@Composable
fun ReminderEditScreen(nav: NavHostController, id: String, vm: ReminderEditViewModel = viewModel()) {
    val ctx = LocalContext.current
    val loc = currentLocale()
    val isNew = id == "new"
    var original by remember { mutableStateOf<ReminderEntity?>(null) }
    var title by rememberSaveable { mutableStateOf("") }
    var note by rememberSaveable { mutableStateOf("") }
    var day by rememberSaveable { mutableStateOf(D.today()) }
    var minutes by rememberSaveable { mutableStateOf(minOf(23, D.minuteOfDay(D.now()) / 60 + 1) * 60) }
    var mode by rememberSaveable { mutableStateOf("NONE") }
    var interval by rememberSaveable { mutableStateOf("2") }
    var enabled by rememberSaveable { mutableStateOf(true) }
    var showErr by remember { mutableStateOf(false) }
    var pastErr by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    LaunchedEffect(id) {
        if (!isNew) {
            val r = vm.load(id)
            if (r != null) {
                original = r
                if (title.isEmpty()) {
                    title = r.title
                    note = r.note
                    day = D.epochDayOf(r.triggerAt)
                    minutes = D.minuteOfDay(r.triggerAt)
                    mode = r.repeatMode
                    interval = r.intervalDays.toString()
                    enabled = r.enabled
                }
            }
        }
    }

    AppScaffold(
        title = stringResource(if (isNew) R.string.reminder_new else R.string.reminder_edit),
        onBack = { nav.popBackStack() }
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .verticalScroll(rememberScrollState())
                .imePadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text(stringResource(R.string.reminder_title)) },
                isError = showErr && title.isBlank(),
                supportingText = {
                    if (showErr && title.isBlank()) Text(stringResource(R.string.task_title_required))
                },
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text(stringResource(R.string.reminder_note)) },
                minLines = 2,
                modifier = Modifier.fillMaxWidth()
            )

            PickerField(stringResource(R.string.reminder_date), Fmt.date(day, loc)) {
                showDatePicker(ctx, day) { picked -> day = picked }
            }
            PickerField(stringResource(R.string.reminder_time), Fmt.time(minutes, loc)) {
                showTimePicker(ctx, minutes) { picked -> minutes = picked }
            }

            Text(stringResource(R.string.reminder_repeat), style = MaterialTheme.typography.labelLarge)
            ChoiceChips(
                options = listOf("NONE", "DAILY", "WEEKLY", "MONTHLY", "CUSTOM"),
                selected = mode,
                onSelect = { mode = it }
            ) { m -> repeatLabel(m) }

            if (mode == "CUSTOM") {
                OutlinedTextField(
                    value = interval,
                    onValueChange = { v -> if (v.length <= 3 && v.all { it.isDigit() }) interval = v },
                    singleLine = true,
                    label = { Text(stringResource(R.string.reminder_interval)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.reminder_enabled),
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.bodyLarge
                )
                Switch(checked = enabled, onCheckedChange = { enabled = it })
            }

            if (pastErr) {
                Text(
                    stringResource(R.string.reminder_past),
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            Spacer(Modifier.height(4.dp))
            Button(
                onClick = {
                    showErr = true
                    val at = D.dayStartMillis(day) + minutes * 60_000L
                    val now = D.now()
                    val bad = enabled && mode == "NONE" && at <= now
                    pastErr = bad
                    if (title.isNotBlank() && !bad) {
                        val o = original
                        var r = ReminderEntity(
                            id = o?.id ?: D.id(),
                            title = title.trim(),
                            note = note.trim(),
                            triggerAt = at,
                            repeatMode = mode,
                            intervalDays = (interval.toIntOrNull() ?: 1).coerceIn(1, 365),
                            enabled = enabled,
                            linkedTaskId = o?.linkedTaskId ?: "",
                            createdAt = o?.createdAt ?: now,
                            updatedAt = now
                        )
                        if (r.repeatMode != "NONE" && r.triggerAt <= now) {
                            r = r.copy(triggerAt = ReminderScheduler.nextAfter(r, now))
                        }
                        vm.save(r) { nav.popBackStack() }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text(stringResource(R.string.save))
            }

            if (!isNew) {
                OutlinedButton(
                    onClick = { confirmDelete = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(stringResource(R.string.delete), color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }

    if (confirmDelete) {
        ConfirmDialog(
            title = stringResource(R.string.confirm_delete_title),
            text = stringResource(R.string.confirm_delete_reminder),
            confirm = stringResource(R.string.delete),
            cancel = stringResource(R.string.cancel),
            onConfirm = {
                confirmDelete = false
                vm.delete(id) { nav.popBackStack() }
            },
            onDismiss = { confirmDelete = false }
        )
    }
}
