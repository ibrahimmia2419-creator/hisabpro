@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.lifemanager.pro.ui.screens

import android.app.Application
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.lifemanager.pro.R
import com.lifemanager.pro.data.CategoryEntity
import com.lifemanager.pro.data.Graph
import com.lifemanager.pro.data.TaskEntity
import com.lifemanager.pro.ui.components.AppCard
import com.lifemanager.pro.ui.components.AppScaffold
import com.lifemanager.pro.ui.components.ChoiceChips
import com.lifemanager.pro.ui.components.ConfirmDialog
import com.lifemanager.pro.ui.components.EmptyState
import com.lifemanager.pro.ui.components.MonthGrid
import com.lifemanager.pro.ui.components.Pill
import com.lifemanager.pro.ui.components.catLabel
import com.lifemanager.pro.ui.components.prioColor
import com.lifemanager.pro.ui.components.prioLabel
import com.lifemanager.pro.ui.components.statusColor
import com.lifemanager.pro.ui.components.statusLabel
import com.lifemanager.pro.ui.nav.Routes
import com.lifemanager.pro.util.D
import com.lifemanager.pro.util.Fmt
import com.lifemanager.pro.util.currentLocale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.YearMonth
import java.util.Locale

data class PlannerUi(
    val tab: Int = 0,
    val query: String = "",
    val searching: Boolean = false,
    val status: String = "",
    val priority: Int = -1,
    val category: String = "",
    val selectedDay: Long = D.today(),
    val month: YearMonth = YearMonth.now()
)

/** Pure function so the planner logic is easy to reason about: which tasks to show. */
fun filterTasks(all: List<TaskEntity>, u: PlannerUi, today: Long): List<TaskEntity> {
    var l: List<TaskEntity> = all
    if (u.query.isNotBlank()) {
        val q = u.query.trim().lowercase()
        l = l.filter {
            it.title.lowercase().contains(q) ||
                it.description.lowercase().contains(q) ||
                it.category.lowercase().contains(q)
        }
    } else {
        l = when (u.tab) {
            0 -> l.filter { it.epochDay == today }
            1 -> l.filter { it.epochDay == today + 1 }
            2 -> l.filter { it.epochDay > today + 1 }
            3 -> l.filter { it.epochDay < today }
            else -> l.filter { it.epochDay == u.selectedDay }
        }
    }
    if (u.status.isNotEmpty()) l = l.filter { it.status == u.status }
    if (u.priority >= 0) l = l.filter { it.priority == u.priority }
    if (u.category.isNotEmpty()) l = l.filter { it.category == u.category }

    val newestFirst = u.tab == 3 || u.query.isNotBlank()
    return if (newestFirst) {
        l.sortedWith(compareByDescending<TaskEntity> { it.epochDay }.thenBy { it.startMin })
    } else {
        l.sortedWith(
            compareBy<TaskEntity> { it.epochDay }
                .thenBy { if (it.startMin < 0) 1440 else it.startMin }
                .thenByDescending { it.priority }
        )
    }
}

class PlannerViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Graph.repo

    val ui = MutableStateFlow(PlannerUi())

    val all: StateFlow<List<TaskEntity>> =
        repo.tasks.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    val shown: StateFlow<List<TaskEntity>> =
        combine(repo.tasks, ui) { list, u -> filterTasks(list, u, D.today()) }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    val categories: StateFlow<List<CategoryEntity>> =
        repo.categories("TASK")
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    fun toggleDone(t: TaskEntity) {
        viewModelScope.launch {
            repo.setTaskStatus(t, if (t.status == "COMPLETED") "PENDING" else "COMPLETED")
        }
    }

    fun setStatus(t: TaskEntity, status: String) {
        viewModelScope.launch { repo.setTaskStatus(t, status) }
    }

    fun delete(t: TaskEntity) {
        viewModelScope.launch { repo.deleteTask(t.id) }
    }
}

@Composable
fun PlannerScreen(nav: NavHostController, vm: PlannerViewModel = viewModel()) {
    val ui by vm.ui.collectAsState()
    val list by vm.shown.collectAsState()
    val all by vm.all.collectAsState()
    val cats by vm.categories.collectAsState()
    val loc = currentLocale()
    var showFilters by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<TaskEntity?>(null) }

    val tabs = listOf(
        R.string.tab_today, R.string.tab_tomorrow, R.string.tab_upcoming,
        R.string.tab_previous, R.string.tab_calendar
    )
    val marked = remember(all) { all.map { it.epochDay }.toSet() }
    val searching = ui.query.isNotBlank()
    val showDate = searching || ui.tab == 2 || ui.tab == 3

    AppScaffold(
        title = stringResource(R.string.planner_title),
        tab = true,
        actions = {
            IconButton(onClick = {
                vm.ui.update { it.copy(searching = !it.searching, query = if (it.searching) "" else it.query) }
            }) {
                Icon(Icons.Default.Search, contentDescription = null)
            }
            TextButton(onClick = { showFilters = !showFilters }) {
                Text(stringResource(R.string.filters))
            }
        },
        fab = {
            FloatingActionButton(onClick = {
                val day = if (ui.tab == 4) ui.selectedDay else -1L
                nav.navigate(Routes.taskEdit("new", day))
            }) {
                Icon(Icons.Default.Add, contentDescription = null)
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            ScrollableTabRow(selectedTabIndex = ui.tab, edgePadding = 12.dp) {
                tabs.forEachIndexed { i, res ->
                    Tab(
                        selected = ui.tab == i,
                        onClick = { vm.ui.update { u -> u.copy(tab = i) } },
                        text = { Text(stringResource(res)) }
                    )
                }
            }

            if (ui.searching) {
                OutlinedTextField(
                    value = ui.query,
                    onValueChange = { q -> vm.ui.update { u -> u.copy(query = q) } },
                    singleLine = true,
                    placeholder = { Text(stringResource(R.string.search_hint)) },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }

            if (showFilters) {
                FilterBar(ui, cats.map { it.name }) { changed -> vm.ui.value = changed }
            }

            if (ui.tab == 4 && !searching) {
                Box(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    MonthGrid(
                        month = ui.month,
                        selected = ui.selectedDay,
                        marked = marked,
                        onSelect = { d -> vm.ui.update { u -> u.copy(selectedDay = d) } },
                        onPrev = { vm.ui.update { u -> u.copy(month = u.month.minusMonths(1)) } },
                        onNext = { vm.ui.update { u -> u.copy(month = u.month.plusMonths(1)) } }
                    )
                }
            }

            if (list.isEmpty()) {
                EmptyState(
                    emoji = "🗓️",
                    text = stringResource(if (searching) R.string.no_results else R.string.empty_tasks),
                    modifier = Modifier.weight(1f)
                )
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(list, key = { it.id }) { t ->
                        TaskCard(
                            t = t,
                            loc = loc,
                            showDate = showDate,
                            onToggle = { vm.toggleDone(t) },
                            onOpen = { nav.navigate(Routes.taskEdit(t.id)) },
                            onStatus = { s -> vm.setStatus(t, s) },
                            onDelete = { pendingDelete = t }
                        )
                    }
                }
            }
        }
    }

    val pd = pendingDelete
    if (pd != null) {
        ConfirmDialog(
            title = stringResource(R.string.confirm_delete_title),
            text = stringResource(R.string.confirm_delete_task),
            confirm = stringResource(R.string.delete),
            cancel = stringResource(R.string.cancel),
            onConfirm = {
                vm.delete(pd)
                pendingDelete = null
            },
            onDismiss = { pendingDelete = null }
        )
    }
}

@Composable
private fun FilterBar(ui: PlannerUi, cats: List<String>, onChange: (PlannerUi) -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(stringResource(R.string.filter_status), style = MaterialTheme.typography.labelMedium)
        ChoiceChips(
            options = listOf("", "PENDING", "IN_PROGRESS", "COMPLETED", "CANCELLED"),
            selected = ui.status,
            onSelect = { onChange(ui.copy(status = it)) }
        ) { s -> if (s.isEmpty()) stringResource(R.string.all) else statusLabel(s) }

        Text(stringResource(R.string.filter_priority), style = MaterialTheme.typography.labelMedium)
        ChoiceChips(
            options = listOf(-1, 0, 1, 2),
            selected = ui.priority,
            onSelect = { onChange(ui.copy(priority = it)) }
        ) { p -> if (p < 0) stringResource(R.string.all) else prioLabel(p) }

        Text(stringResource(R.string.filter_category), style = MaterialTheme.typography.labelMedium)
        ChoiceChips(
            options = listOf("") + cats,
            selected = ui.category,
            onSelect = { onChange(ui.copy(category = it)) }
        ) { c -> if (c.isEmpty()) stringResource(R.string.all) else catLabel(c) }
    }
}

private fun taskWhen(t: TaskEntity, loc: Locale, showDate: Boolean): String {
    val timePart = when {
        t.startMin >= 0 && t.endMin >= 0 -> Fmt.time(t.startMin, loc) + " – " + Fmt.time(t.endMin, loc)
        t.startMin >= 0 -> Fmt.time(t.startMin, loc)
        t.endMin >= 0 -> Fmt.time(t.endMin, loc)
        else -> ""
    }
    val datePart = if (showDate) Fmt.date(t.epochDay, loc) else ""
    return listOf(datePart, timePart).filter { it.isNotEmpty() }.joinToString(" · ")
}

@Composable
private fun TaskCard(
    t: TaskEntity,
    loc: Locale,
    showDate: Boolean,
    onToggle: () -> Unit,
    onOpen: () -> Unit,
    onStatus: (String) -> Unit,
    onDelete: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    val done = t.status == "COMPLETED"
    val dim = done || t.status == "CANCELLED"
    val whenText = taskWhen(t, loc, showDate)

    AppCard(Modifier.fillMaxWidth(), onClick = onOpen) {
        Row(
            Modifier.padding(horizontal = 4.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(checked = done, onCheckedChange = { onToggle() })
            Column(Modifier.weight(1f)) {
                Text(
                    t.title,
                    style = MaterialTheme.typography.titleMedium,
                    textDecoration = if (dim) TextDecoration.LineThrough else TextDecoration.None,
                    color = if (dim) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                if (whenText.isNotEmpty()) {
                    Text(
                        whenText,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.height(6.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Pill(catLabel(t.category), MaterialTheme.colorScheme.secondary)
                    Pill(prioLabel(t.priority), prioColor(t.priority))
                    Pill(statusLabel(t.status), statusColor(t.status))
                }
            }
            Box {
                IconButton(onClick = { menu = true }) {
                    Icon(Icons.Default.MoreVert, contentDescription = null)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.edit)) },
                        onClick = {
                            menu = false
                            onOpen()
                        }
                    )
                    listOf("PENDING", "IN_PROGRESS", "COMPLETED", "CANCELLED")
                        .filter { it != t.status }
                        .forEach { s ->
                            DropdownMenuItem(
                                text = { Text(statusLabel(s)) },
                                onClick = {
                                    menu = false
                                    onStatus(s)
                                }
                            )
                        }
                    DropdownMenuItem(
                        text = {
                            Text(
                                stringResource(R.string.delete),
                                color = MaterialTheme.colorScheme.error
                            )
                        },
                        onClick = {
                            menu = false
                            onDelete()
                        }
                    )
                }
            }
        }
    }
}
