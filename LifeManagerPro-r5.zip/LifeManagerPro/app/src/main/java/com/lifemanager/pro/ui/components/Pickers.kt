@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.lifemanager.pro.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import com.lifemanager.pro.R
import com.lifemanager.pro.data.Graph
import com.lifemanager.pro.util.Attachments
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Category chips for one kind (TIME, INCOME, EXPENSE ...) with a "+ new category" chip. */
@Composable
fun CategoryPicker(kind: String, selected: String, onSelect: (String) -> Unit) {
    val flow = remember(kind) { Graph.repo.categories(kind) }
    val cats by flow.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var adding by remember { mutableStateOf(false) }

    ChoiceChips(
        options = cats.map { it.name } + "+",
        selected = selected,
        onSelect = { c ->
            if (c == "+") {
                adding = true
            } else {
                onSelect(c)
            }
        }
    ) { c -> if (c == "+") "＋ " + stringResource(R.string.new_category) else catLabel(c) }

    if (adding) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { adding = false },
            title = { Text(stringResource(R.string.new_category)) },
            text = {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    label = { Text(stringResource(R.string.category_name)) }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val clean = name.trim()
                    if (clean.isNotEmpty()) {
                        scope.launch { Graph.repo.addCategory(kind, clean) }
                        onSelect(clean)
                    }
                    adding = false
                }) { Text(stringResource(R.string.add)) }
            },
            dismissButton = {
                TextButton(onClick = { adding = false }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }
}

/** Shows a picture stored in the app's attachment folder. */
@Composable
fun FileImage(file: File, modifier: Modifier = Modifier, maxPx: Int = 480) {
    val bmp by produceState<ImageBitmap?>(initialValue = null, file) {
        value = withContext(Dispatchers.IO) {
            Attachments.decodeSampled(file, maxPx)?.asImageBitmap()
        }
    }
    val b = bmp
    if (b != null) {
        Image(bitmap = b, contentDescription = null, modifier = modifier, contentScale = ContentScale.Crop)
    } else {
        Box(modifier.background(MaterialTheme.colorScheme.surfaceVariant))
    }
}
