@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.lifemanager.pro.ui.screens

import android.app.Application
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.lifemanager.pro.R
import com.lifemanager.pro.data.AppSettings
import com.lifemanager.pro.data.FocusSessionEntity
import com.lifemanager.pro.data.FocusState
import com.lifemanager.pro.data.Graph
import com.lifemanager.pro.data.HabitMath
import com.lifemanager.pro.data.TimeEntryEntity
import com.lifemanager.pro.data.TimerState
import com.lifemanager.pro.reminder.FocusEngine
import com.lifemanager.pro.ui.components.AppCard
import com.lifemanager.pro.ui.components.AppScaffold
import com.lifemanager.pro.ui.components.CategoryPicker
import com.lifemanager.pro.ui.components.ChoiceChips
import com.lifemanager.pro.ui.components.EmptyState
import com.lifemanager.pro.ui.components.Pill
import com.lifemanager.pro.ui.components.PickerField
import com.lifemanager.pro.ui.components.ProgressBar
import com.lifemanager.pro.ui.components.ProgressRing
import com.lifemanager.pro.ui.components.SectionTitle
import com.lifemanager.pro.ui.components.catLabel
import com.lifemanager.pro.ui.components.durationText
import com.lifemanager.pro.ui.components.showDatePicker
import com.lifemanager.pro.ui.components.showTimePicker
import com.lifemanager.pro.util.D
import com.lifemanager.pro.util.Fmt
import com.lifemanager.pro.util.currentLocale
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.YearMonth
import java.util.Locale

class TimeViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Graph.repo

    val entries: StateFlow<List<TimeEntryEntity>> =
        repo.timeEntries.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    val sessions: StateFlow<List<FocusSessionEntity>> =
        repo.focusSessions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    fun saveEntry(e: TimeEntryEntity) {
        viewModelScope.launch { repo.saveTimeEntry(e) }
    }

    fun deleteEntry(id: String) {
        viewModelScope.launch { repo.deleteTimeEntry(id) }
    }

    fun startTimer(title: String, category: String) {
        viewModelScope.launch {
            Graph.prefs.setTimerState(TimerState(System.currentTimeMillis(), title.trim(), category))
        }
    }

    fun stopTimer(t: TimerState) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val sec = (now - t.startAt) / 1000L
            if (sec >= 5L) {
                repo.saveTimeEntry(
                    TimeEntryEntity(
                        id = D.id(), title = t.title, category = t.category, startAt = t.startAt,
                        endAt = now, seconds = sec, manual = false,
                        epochDay = D.epochDayOf(t.startAt), createdAt = now, updatedAt = now
                    )
                )
            }
            Graph.prefs.setTimerState(TimerState())
        }
    }

    fun discardTimer() {
        viewModelScope.launch { Graph.prefs.setTimerState(TimerState()) }
    }

    fun startFocus(kind: String, minutes: Int) {
        viewModelScope.launch { FocusEngine.start(getApplication<Application>(), kind, minutes, "") }
    }

    fun stopFocus() {
        viewModelScope.launch { FocusEngine.stop(getApplication<Application>()) }
    }

    fun completeFocus() {
        viewModelScope.launch { FocusEngine.complete(getApplication<Application>(), false) }
    }

    fun setFocusBreak(focus: Int, brk: Int) {
        viewModelScope.launch { Graph.prefs.setFocusBreak(focus, brk) }
    }
}

@Composable
fun TimeScreen(nav: NavHostController, vm: TimeViewModel = viewModel()) {
    var tab by remember { mutableStateOf(0) }
    val tabs = listOf(R.string.time_tab_timer, R.string.time_tab_focus, R.string.time_tab_summary)

    AppScaffold(
        title = stringResource(R.string.time_title),
        onBack = { nav.popBackStack() }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            TabRow(selectedTabIndex = tab) {
                tabs.forEachIndexed { i, res ->
                    Tab(
                        selected = tab == i,
                        onClick = { tab = i },
                        text = { Text(stringResource(res)) }
                    )
                }
            }
            when (tab) {
                0 -> TimerTab(vm)
                1 -> FocusTab(vm)
                else -> SummaryTab(vm)
            }
        }
    }
}

@Composable
private fun TimerTab(vm: TimeViewModel) {
    val loc = currentLocale()
    val timer by Graph.prefs.timerState.collectAsState(initial = TimerState())
    val entries by vm.entries.collectAsState()
    var title by rememberSaveable { mutableStateOf("") }
    var category by rememberSaveable { mutableStateOf("work") }
    var day by remember { mutableStateOf(D.today()) }
    var editing by remember { mutableStateOf<TimeEntryEntity?>(null) }
    var adding by remember { mutableStateOf(false) }

    val dayEntries = entries.filter { it.epochDay == day }.sortedBy { it.startAt }
    val dayTotal = dayEntries.sumOf { it.seconds }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            AppCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (timer.running) {
                        RunningTimer(timer, loc, onStop = { vm.stopTimer(timer) }, onDiscard = { vm.discardTimer() })
                    } else {
                        OutlinedTextField(
                            value = title,
                            onValueChange = { title = it },
                            singleLine = true,
                            label = { Text(stringResource(R.string.timer_title_hint)) },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(stringResource(R.string.task_category), style = MaterialTheme.typography.labelLarge)
                        CategoryPicker("TIME", category) { category = it }
                        Button(
                            onClick = {
                                vm.startTimer(title, category)
                                title = ""
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("▶  " + stringResource(R.string.timer_start)) }
                        OutlinedButton(
                            onClick = { adding = true },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(stringResource(R.string.time_add_manual)) }
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { day -= 1L }) { Text("‹", fontSize = 26.sp) }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(Fmt.dateLong(day, loc), style = MaterialTheme.typography.titleMedium)
                    Text(
                        durationText(dayTotal),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                TextButton(onClick = { day += 1L }) { Text("›", fontSize = 26.sp) }
            }
        }
        if (dayEntries.isEmpty()) {
            item { EmptyState("⏱️", stringResource(R.string.time_empty_day)) }
        } else {
            items(dayEntries, key = { it.id }) { e ->
                EntryRow(e, loc) { editing = e }
            }
        }
    }

    if (adding) {
        EntryDialog(
            initial = null,
            defaultDay = day,
            onSave = {
                vm.saveEntry(it)
                adding = false
            },
            onDelete = null,
            onDismiss = { adding = false }
        )
    }
    val ed = editing
    if (ed != null) {
        EntryDialog(
            initial = ed,
            defaultDay = day,
            onSave = {
                vm.saveEntry(it)
                editing = null
            },
            onDelete = {
                vm.deleteEntry(ed.id)
                editing = null
            },
            onDismiss = { editing = null }
        )
    }
}

@Composable
private fun RunningTimer(t: TimerState, loc: Locale, onStop: () -> Unit, onDiscard: () -> Unit) {
    val now by produceState(initialValue = System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(1000L)
        }
    }
    Text(
        stringResource(R.string.timer_running),
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary
    )
    if (t.title.isNotBlank()) {
        Text(t.title, style = MaterialTheme.typography.titleMedium)
    }
    Pill(catLabel(t.category), MaterialTheme.colorScheme.secondary)
    Text(
        Fmt.clock((now - t.startAt) / 1000L, loc),
        fontSize = 40.sp,
        fontWeight = FontWeight.Bold
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = onStop, modifier = Modifier.weight(1f)) {
            Text("■  " + stringResource(R.string.timer_stop))
        }
        OutlinedButton(onClick = onDiscard) { Text(stringResource(R.string.timer_discard)) }
    }
}

@Composable
private fun EntryRow(e: TimeEntryEntity, loc: Locale, onOpen: () -> Unit) {
    AppCard(Modifier.fillMaxWidth(), onClick = onOpen) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    if (e.title.isNotBlank()) e.title else catLabel(e.category),
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    Fmt.time(D.minuteOfDay(e.startAt), loc) + " – " + Fmt.time(D.minuteOfDay(e.endAt), loc),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(4.dp))
                Pill(catLabel(e.category), MaterialTheme.colorScheme.secondary)
            }
            Text(durationText(e.seconds), fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun EntryDialog(
    initial: TimeEntryEntity?,
    defaultDay: Long,
    onSave: (TimeEntryEntity) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    val loc = currentLocale()
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var cat by remember { mutableStateOf(initial?.category ?: "work") }
    var day by remember { mutableStateOf(initial?.epochDay ?: defaultDay) }
    var startMin by remember { mutableStateOf(if (initial != null) D.minuteOfDay(initial.startAt) else 9 * 60) }
    var minutes by remember { mutableStateOf(if (initial != null) (initial.seconds / 60L).toString() else "30") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(stringResource(if (initial == null) R.string.time_add_manual else R.string.time_edit_entry))
        },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    singleLine = true,
                    label = { Text(stringResource(R.string.timer_title_hint)) },
                    modifier = Modifier.fillMaxWidth()
                )
                CategoryPicker("TIME", cat) { cat = it }
                PickerField(stringResource(R.string.task_date), Fmt.date(day, loc)) {
                    showDatePicker(ctx, day) { picked -> day = picked }
                }
                PickerField(stringResource(R.string.task_start), Fmt.time(startMin, loc)) {
                    showTimePicker(ctx, startMin) { picked -> startMin = picked }
                }
                OutlinedTextField(
                    value = minutes,
                    onValueChange = { v -> if (v.length <= 4) minutes = v },
                    singleLine = true,
                    label = { Text(stringResource(R.string.time_minutes)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val mins = Fmt.parseInt(minutes) ?: 0
                if (mins > 0) {
                    val now = D.now()
                    val startAt = D.dayStartMillis(day) + startMin * 60_000L
                    val seconds = mins * 60L
                    onSave(
                        TimeEntryEntity(
                            id = initial?.id ?: D.id(),
                            title = title.trim(),
                            category = cat,
                            startAt = startAt,
                            endAt = startAt + seconds * 1000L,
                            seconds = seconds,
                            manual = true,
                            epochDay = day,
                            createdAt = initial?.createdAt ?: now,
                            updatedAt = now
                        )
                    )
                }
            }) { Text(stringResource(R.string.save)) }
        },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = onDelete) {
                        Text(stringResource(R.string.delete), color = MaterialTheme.colorScheme.error)
                    }
                }
                TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
            }
        }
    )
}

@Composable
private fun FocusTab(vm: TimeViewModel) {
    val loc = currentLocale()
    val s by Graph.prefs.settings.collectAsState(initial = AppSettings())
    val focus by Graph.prefs.focusState.collectAsState(initial = FocusState())
    val sessions by vm.sessions.collectAsState()
    val now by produceState(initialValue = System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(500L)
        }
    }
    val due = focus.running && now >= focus.endAt
    LaunchedEffect(due, focus.endAt) {
        if (due) vm.completeFocus()
    }

    val today = D.today()
    val todayFocus = sessions.filter { it.epochDay == today && it.kind == "FOCUS" }
    val todayMin = todayFocus.sumOf { it.actualMin }

    val remainingMs = if (focus.running) maxOf(0L, focus.endAt - now) else s.focusMin * 60_000L
    val totalMs = if (focus.running) maxOf(1L, focus.plannedMin * 60_000L) else 1L
    val progress = if (focus.running) 1f - remainingMs.toFloat() / totalMs.toFloat() else 0f

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        AppCard(Modifier.fillMaxWidth()) {
            Column(
                Modifier.padding(16.dp).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (focus.running) {
                    Pill(
                        stringResource(if (focus.kind == "BREAK") R.string.focus_kind_break else R.string.focus_kind_focus),
                        MaterialTheme.colorScheme.tertiary
                    )
                } else {
                    Text(
                        stringResource(R.string.focus_ready),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                ProgressRing(
                    progress = progress,
                    diameter = 200.dp,
                    stroke = 14.dp,
                    label = Fmt.clock(remainingMs / 1000L, loc)
                )
                if (focus.running) {
                    OutlinedButton(onClick = { vm.stopFocus() }) {
                        Text("■  " + stringResource(R.string.focus_stop))
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { vm.startFocus("FOCUS", s.focusMin) }) {
                            Text("▶  " + stringResource(R.string.focus_start))
                        }
                        OutlinedButton(onClick = { vm.startFocus("BREAK", s.breakMin) }) {
                            Text("☕  " + stringResource(R.string.break_start))
                        }
                    }
                }
            }
        }

        AppCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Stepper(
                    label = stringResource(R.string.focus_minutes),
                    value = s.focusMin,
                    loc = loc,
                    onMinus = { vm.setFocusBreak(maxOf(5, s.focusMin - 5), s.breakMin) },
                    onPlus = { vm.setFocusBreak(minOf(120, s.focusMin + 5), s.breakMin) }
                )
                Stepper(
                    label = stringResource(R.string.break_minutes),
                    value = s.breakMin,
                    loc = loc,
                    onMinus = { vm.setFocusBreak(s.focusMin, maxOf(1, s.breakMin - 1)) },
                    onPlus = { vm.setFocusBreak(s.focusMin, minOf(60, s.breakMin + 1)) }
                )
            }
        }

        AppCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                SectionTitle(stringResource(R.string.focus_today))
                Text(
                    "🎯 " + durationText(todayMin * 60L) + " · " +
                        stringResource(R.string.focus_sessions, Fmt.num(todayFocus.size, loc)),
                    style = MaterialTheme.typography.bodyLarge
                )
                SectionTitle(stringResource(R.string.focus_history), Modifier.padding(top = 8.dp))
                if (sessions.isEmpty()) {
                    Text(
                        stringResource(R.string.focus_no_history),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                sessions.take(8).forEach { f ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (f.kind == "BREAK") "☕" else "🎯", fontSize = 20.sp)
                        Spacer(Modifier.size(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                Fmt.date(f.epochDay, loc) + " · " + Fmt.time(D.minuteOfDay(f.startAt), loc),
                                style = MaterialTheme.typography.bodyMedium
                            )
                            if (!f.completed) {
                                Text(
                                    stringResource(R.string.focus_stopped_early),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Text(durationText(f.actualMin * 60L), fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
private fun Stepper(label: String, value: Int, loc: Locale, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        OutlinedButton(onClick = onMinus) { Text("−") }
        Text(
            Fmt.num(value, loc),
            modifier = Modifier.padding(horizontal = 12.dp),
            style = MaterialTheme.typography.titleMedium
        )
        OutlinedButton(onClick = onPlus) { Text("+") }
    }
}

@Composable
private fun SummaryTab(vm: TimeViewModel) {
    val loc = currentLocale()
    val entries by vm.entries.collectAsState()
    val sessions by vm.sessions.collectAsState()
    var range by remember { mutableStateOf(0) }
    var anchor by remember { mutableStateOf(D.today()) }

    val bounds = when (range) {
        0 -> anchor to anchor
        1 -> {
            val f = HabitMath.periodKey("WEEKLY", anchor)
            f to (f + 6L)
        }
        else -> {
            val ym = YearMonth.from(D.date(anchor))
            ym.atDay(1).toEpochDay() to ym.atEndOfMonth().toEpochDay()
        }
    }
    val from = bounds.first
    val to = bounds.second
    val label = when (range) {
        0 -> Fmt.date(anchor, loc)
        1 -> Fmt.date(from, loc) + " – " + Fmt.date(to, loc)
        else -> Fmt.month(YearMonth.from(D.date(anchor)), loc)
    }

    val inRange = entries.filter { it.epochDay in from..to }
    val total = inRange.sumOf { it.seconds }
    val byCat = inRange.groupBy { it.category }
        .map { entry -> entry.key to entry.value.sumOf { e -> e.seconds } }
        .sortedByDescending { it.second }
    val maxSec = maxOf(1L, byCat.maxOfOrNull { it.second } ?: 1L)
    val focusMin = sessions.filter { it.epochDay in from..to && it.kind == "FOCUS" }.sumOf { it.actualMin }

    fun shift(dir: Int) {
        anchor = when (range) {
            0 -> anchor + dir.toLong()
            1 -> anchor + 7L * dir.toLong()
            else -> D.date(anchor).plusMonths(dir.toLong()).toEpochDay()
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ChoiceChips(
            options = listOf(0, 1, 2),
            selected = range,
            onSelect = { range = it }
        ) { r ->
            when (r) {
                0 -> stringResource(R.string.sum_day)
                1 -> stringResource(R.string.sum_week)
                else -> stringResource(R.string.sum_month)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { shift(-1) }) { Text("‹", fontSize = 26.sp) }
            Text(
                label,
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.titleMedium,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            TextButton(onClick = { shift(1) }) { Text("›", fontSize = 26.sp) }
        }
        AppCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    stringResource(R.string.sum_total),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(durationText(total), fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Text(
                    "🎯 " + stringResource(R.string.sum_focus) + ": " + durationText(focusMin * 60L),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
        if (byCat.isEmpty()) {
            EmptyState("⏱️", stringResource(R.string.time_empty_range))
        } else {
            AppCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    byCat.forEach { pair ->
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row {
                                Text(catLabel(pair.first), modifier = Modifier.weight(1f))
                                Text(durationText(pair.second), fontWeight = FontWeight.SemiBold)
                            }
                            ProgressBar(pair.second.toFloat() / maxSec.toFloat())
                        }
                    }
                }
            }
        }
    }
}
