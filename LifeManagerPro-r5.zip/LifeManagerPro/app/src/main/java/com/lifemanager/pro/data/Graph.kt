package com.lifemanager.pro.data

import android.app.Application

/** Simple service locator: one database, one repository, one settings store. */
object Graph {
    lateinit var db: LifeDatabase
    lateinit var repo: Repository
    lateinit var prefs: Prefs

    fun init(app: Application) {
        db = LifeDatabase.get(app)
        repo = Repository(db)
        prefs = Prefs(app)
    }
}
