package com.lifemanager.pro.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import com.lifemanager.pro.R
import com.lifemanager.pro.ui.theme.Danger
import com.lifemanager.pro.ui.theme.Info
import com.lifemanager.pro.ui.theme.Muted
import com.lifemanager.pro.ui.theme.Success
import com.lifemanager.pro.ui.theme.Warning
import com.lifemanager.pro.util.Fmt
import com.lifemanager.pro.util.currentLocale

@Composable
fun statusLabel(s: String): String = when (s) {
    "PENDING" -> stringResource(R.string.status_pending)
    "IN_PROGRESS" -> stringResource(R.string.status_in_progress)
    "COMPLETED" -> stringResource(R.string.status_completed)
    "CANCELLED" -> stringResource(R.string.status_cancelled)
    else -> s
}

fun statusColor(s: String): Color = when (s) {
    "PENDING" -> Warning
    "IN_PROGRESS" -> Info
    "COMPLETED" -> Success
    else -> Muted
}

@Composable
fun prioLabel(p: Int): String = when (p) {
    0 -> stringResource(R.string.prio_low)
    2 -> stringResource(R.string.prio_high)
    else -> stringResource(R.string.prio_medium)
}

fun prioColor(p: Int): Color = when (p) {
    0 -> Success
    2 -> Danger
    else -> Warning
}

/** Built-in categories are stored as keys and translated here; custom ones show as typed. */
@Composable
fun catLabel(name: String): String = when (name) {
    "personal" -> stringResource(R.string.cat_personal)
    "work" -> stringResource(R.string.cat_work)
    "study" -> stringResource(R.string.cat_study)
    "health" -> stringResource(R.string.cat_health)
    "family" -> stringResource(R.string.cat_family)
    "finance" -> stringResource(R.string.cat_finance)
    "islamic" -> stringResource(R.string.cat_islamic)
    "other" -> stringResource(R.string.cat_other)
    "rest" -> stringResource(R.string.cat_rest)
    "salary" -> stringResource(R.string.cat_salary)
    "bonus" -> stringResource(R.string.cat_bonus)
    "business" -> stringResource(R.string.cat_business)
    "gift" -> stringResource(R.string.cat_gift)
    "food" -> stringResource(R.string.cat_food)
    "transport" -> stringResource(R.string.cat_transport)
    "bills" -> stringResource(R.string.cat_bills)
    "rent" -> stringResource(R.string.cat_rent)
    "education" -> stringResource(R.string.cat_education)
    "shopping" -> stringResource(R.string.cat_shopping)
    "mobile" -> stringResource(R.string.cat_mobile)
    else -> name
}

@Composable
fun durationText(totalSec: Long): String {
    val loc = currentLocale()
    val minutes = (totalSec / 60L).toInt()
    val h = minutes / 60
    val m = minutes % 60
    return if (h > 0) {
        stringResource(R.string.dur_h_m, Fmt.num(h, loc), Fmt.num(m, loc))
    } else {
        stringResource(R.string.dur_m, Fmt.num(m, loc))
    }
}

val MOOD_EMOJI = listOf("", "😞", "😕", "😐", "🙂", "😄")

@Composable
fun moodLabel(m: Int): String = when (m) {
    1 -> stringResource(R.string.mood_1)
    2 -> stringResource(R.string.mood_2)
    3 -> stringResource(R.string.mood_3)
    4 -> stringResource(R.string.mood_4)
    5 -> stringResource(R.string.mood_5)
    else -> stringResource(R.string.mood_none)
}

val GOAL_CATS = listOf("personal", "professional", "educational", "financial", "health", "islamic", "other")

@Composable
fun freqLabel(f: String): String = when (f) {
    "WEEKLY" -> stringResource(R.string.freq_weekly)
    "MONTHLY" -> stringResource(R.string.freq_monthly)
    else -> stringResource(R.string.freq_daily)
}

@Composable
fun unitLabel(f: String): String = when (f) {
    "WEEKLY" -> stringResource(R.string.unit_week)
    "MONTHLY" -> stringResource(R.string.unit_month)
    else -> stringResource(R.string.unit_day)
}

@Composable
fun goalCatLabel(k: String): String = when (k) {
    "personal" -> stringResource(R.string.cat_personal)
    "professional" -> stringResource(R.string.cat_professional)
    "educational" -> stringResource(R.string.cat_educational)
    "financial" -> stringResource(R.string.cat_financial)
    "health" -> stringResource(R.string.cat_health)
    "islamic" -> stringResource(R.string.cat_islamic)
    else -> stringResource(R.string.cat_other)
}

fun goalCatEmoji(k: String): String = when (k) {
    "personal" -> "👤"
    "professional" -> "💼"
    "educational" -> "🎓"
    "financial" -> "💰"
    "health" -> "💪"
    "islamic" -> "🕌"
    else -> "🏷️"
}

@Composable
fun goalStatusLabel(s: String): String = when (s) {
    "COMPLETED" -> stringResource(R.string.goal_status_completed)
    "PAUSED" -> stringResource(R.string.goal_status_paused)
    else -> stringResource(R.string.goal_status_active)
}

fun goalStatusColor(s: String): Color = when (s) {
    "COMPLETED" -> Success
    "PAUSED" -> Muted
    else -> Info
}

@Composable
fun repeatLabel(m: String): String = when (m) {
    "DAILY" -> stringResource(R.string.repeat_daily)
    "WEEKLY" -> stringResource(R.string.repeat_weekly)
    "MONTHLY" -> stringResource(R.string.repeat_monthly)
    "CUSTOM" -> stringResource(R.string.repeat_custom)
    else -> stringResource(R.string.repeat_none)
}

@Composable
fun remindLabel(minutes: Int): String = when (minutes) {
    -1 -> stringResource(R.string.remind_off)
    0 -> stringResource(R.string.remind_at_start)
    60 -> stringResource(R.string.remind_60)
    else -> stringResource(R.string.remind_before_min, Fmt.num(minutes, currentLocale()))
}
