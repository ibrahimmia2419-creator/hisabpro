package com.lifemanager.pro.reminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.lifemanager.pro.data.Graph
import com.lifemanager.pro.data.ReminderEntity
import java.time.Instant
import java.time.ZoneId

/**
 * Sets, cancels and re-sets Android alarms for reminders.
 * Alarms are lost when the phone restarts, so BootReceiver and a periodic worker call
 * rescheduleAll() to put every enabled reminder back.
 */
object ReminderScheduler {
    const val EXTRA_ID = "reminder_id"
    private const val MISSED_WINDOW_MS = 12L * 60L * 60L * 1000L

    private fun pending(ctx: Context, id: String): PendingIntent {
        val i = Intent(ctx, ReminderReceiver::class.java)
        i.putExtra(EXTRA_ID, id)
        return PendingIntent.getBroadcast(
            ctx, id.hashCode(), i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun canUseExact(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 31) return true
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return am.canScheduleExactAlarms()
    }

    fun schedule(ctx: Context, r: ReminderEntity) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(ctx, r.id)
        if (!r.enabled || r.triggerAt <= System.currentTimeMillis()) {
            am.cancel(pi)
            return
        }
        try {
            if (canUseExact(ctx)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.triggerAt, pi)
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.triggerAt, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.triggerAt, pi)
        }
    }

    fun cancel(ctx: Context, id: String) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(ctx, id))
    }

    /** The first occurrence of a repeating reminder that is later than `after`. */
    fun nextAfter(r: ReminderEntity, after: Long): Long {
        if (r.repeatMode == "NONE") return r.triggerAt
        var t = r.triggerAt
        var guard = 0
        while (t <= after && guard < 20000) {
            t = advance(r, t)
            guard++
        }
        return t
    }

    private fun advance(r: ReminderEntity, t: Long): Long {
        val z = Instant.ofEpochMilli(t).atZone(ZoneId.systemDefault())
        val n = when (r.repeatMode) {
            "DAILY" -> z.plusDays(1)
            "WEEKLY" -> z.plusWeeks(1)
            "MONTHLY" -> z.plusMonths(1)
            else -> z.plusDays(maxOf(1, r.intervalDays).toLong())
        }
        return n.toInstant().toEpochMilli()
    }

    private suspend fun taskStillActive(taskId: String): Boolean {
        val t = Graph.repo.getTask(taskId) ?: return false
        return t.status != "COMPLETED" && t.status != "CANCELLED"
    }

    private suspend fun afterFire(ctx: Context, r: ReminderEntity) {
        val now = System.currentTimeMillis()
        if (r.repeatMode == "NONE") {
            Graph.repo.saveReminder(r.copy(enabled = false, updatedAt = now))
        } else {
            val upd = r.copy(triggerAt = nextAfter(r, now), updatedAt = now)
            Graph.repo.saveReminder(upd)
            schedule(ctx, upd)
        }
    }

    /** Called by the alarm when a reminder is due. */
    suspend fun onFire(ctx: Context, id: String) {
        val repo = Graph.repo
        val r = repo.getReminder(id) ?: return
        if (!r.enabled) return
        if (r.linkedTaskId.isNotEmpty() && !taskStillActive(r.linkedTaskId)) {
            repo.deleteReminder(id)
            cancel(ctx, id)
            return
        }
        NotificationHelper.showReminder(ctx, r, false)
        afterFire(ctx, r)
    }

    /** Puts every enabled reminder back on the alarm clock; tells about recently missed ones. */
    suspend fun rescheduleAll(ctx: Context) {
        val repo = Graph.repo
        val now = System.currentTimeMillis()
        for (r in repo.allReminders()) {
            if (!r.enabled) {
                cancel(ctx, r.id)
                continue
            }
            if (r.triggerAt > now) {
                schedule(ctx, r)
                continue
            }
            if (r.linkedTaskId.isNotEmpty() && !taskStillActive(r.linkedTaskId)) {
                repo.deleteReminder(r.id)
                continue
            }
            if (now - r.triggerAt <= MISSED_WINDOW_MS) {
                NotificationHelper.showReminder(ctx, r, true)
            }
            afterFire(ctx, r)
        }
    }
}
