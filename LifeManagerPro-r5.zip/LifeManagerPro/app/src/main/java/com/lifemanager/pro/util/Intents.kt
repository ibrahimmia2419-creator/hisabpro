package com.lifemanager.pro.util

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings

/** Opens system settings pages without ever crashing if a phone does not have them. */
fun Context.startSafely(intent: Intent) {
    try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    } catch (e: Exception) {
        // The page does not exist on this phone.
    }
}

fun Context.openAppInfo() {
    startSafely(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + packageName)))
}

fun Context.openBatterySettings() {
    startSafely(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
}

fun Context.openNotificationSettings() {
    val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
    i.putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
    startSafely(i)
}

fun Context.openExactAlarmSettings() {
    if (Build.VERSION.SDK_INT >= 31) {
        startSafely(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + packageName)))
    }
}

/** Xiaomi / MIUI "Autostart" page; falls back to the app info page on other phones. */
fun Context.openAutostart() {
    try {
        val i = Intent()
        i.component = ComponentName(
            "com.miui.securitycenter",
            "com.miui.permcenter.autostart.AutoStartManagementActivity"
        )
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    } catch (e: Exception) {
        openAppInfo()
    }
}
