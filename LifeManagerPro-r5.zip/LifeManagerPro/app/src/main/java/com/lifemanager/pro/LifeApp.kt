package com.lifemanager.pro

import android.app.Application
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.lifemanager.pro.data.BootPrefs
import com.lifemanager.pro.data.Graph
import com.lifemanager.pro.reminder.NotificationHelper
import com.lifemanager.pro.reminder.ReminderScheduler
import com.lifemanager.pro.reminder.ReminderSyncWorker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class LifeApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Graph.init(this)
        BootPrefs.applyAppearance(this)
        NotificationHelper.createChannels(this)
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            Graph.repo.seedDefaults()
            ReminderScheduler.rescheduleAll(applicationContext)
        }
        val request = PeriodicWorkRequestBuilder<ReminderSyncWorker>(6, TimeUnit.HOURS).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "reminder-sync", ExistingPeriodicWorkPolicy.KEEP, request
        )
    }
}
