package com.lifemanager.pro.pdf

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.text.StaticLayout
import android.text.TextPaint
import com.lifemanager.pro.util.D
import com.lifemanager.pro.util.Fmt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.OutputStream
import java.text.NumberFormat
import java.util.Locale

/**
 * Builds an A4 PDF with a header, page numbers, headings, paragraphs and tables.
 * Text is drawn with Android's text engine, so Bangla letters join correctly. If a Bangla
 * font was bundled at build time it is used, otherwise the phone's own font is used.
 */
class PdfBuilder(ctx: Context, private val docTitle: String, private val locale: Locale) {
    private val pageW = 595
    private val pageH = 842
    private val margin = 42f
    private val contentW = pageW - 2 * margin
    private val doc = PdfDocument()
    private var page: PdfDocument.Page? = null
    private var canvas: android.graphics.Canvas? = null
    private var y = 0f
    private var pageNo = 0
    private val brand = Color.parseColor("#0F766E")

    private val typeface: Typeface = try {
        Typeface.createFromAsset(ctx.assets, "fonts/bengali.ttf")
    } catch (e: Exception) {
        Typeface.DEFAULT
    }

    private fun paint(size: Float, bold: Boolean, color: Int): TextPaint {
        val p = TextPaint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = typeface
        p.textSize = size
        p.isFakeBoldText = bold
        p.color = color
        return p
    }

    private val body = paint(11f, false, Color.BLACK)
    private val bold = paint(11f, true, Color.BLACK)
    private val small = paint(9f, false, Color.DKGRAY)
    private val h1 = paint(20f, true, brand)
    private val h2 = paint(14f, true, Color.BLACK)
    private val linePaint = Paint().apply {
        color = Color.LTGRAY
        strokeWidth = 0.8f
    }
    private val headBg = Paint().apply {
        color = Color.parseColor("#E4ECEA")
        style = Paint.Style.FILL
    }

    init {
        newPage()
    }

    private fun layoutOf(text: String, p: TextPaint, width: Int): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, p, width)
            .setLineSpacing(0f, 1.18f)
            .setIncludePad(false)
            .build()

    private fun newPage() {
        finishPage()
        pageNo++
        val info = PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create()
        val p = doc.startPage(info)
        page = p
        canvas = p.canvas
        drawHeader()
        y = margin + 26f
    }

    private fun finishPage() {
        val p = page ?: return
        drawFooter()
        doc.finishPage(p)
        page = null
        canvas = null
    }

    private fun drawHeader() {
        val c = canvas ?: return
        c.drawText(docTitle, margin, margin - 12f, small)
        val d = Fmt.date(D.today(), locale)
        c.drawText(d, pageW - margin - small.measureText(d), margin - 12f, small)
        c.drawLine(margin, margin - 6f, pageW - margin, margin - 6f, linePaint)
    }

    private fun drawFooter() {
        val c = canvas ?: return
        val label = NumberFormat.getInstance(locale).format(pageNo.toLong())
        c.drawText(label, (pageW - small.measureText(label)) / 2f, pageH - margin + 16f, small)
    }

    private fun room(h: Float): Boolean = y + h <= pageH - margin - 8f

    fun spacer(h: Float) {
        y += h
        if (!room(0f)) newPage()
    }

    /** Draws wrapped text; a long paragraph continues on the next page when needed. */
    private fun write(text: String, p: TextPaint, indent: Float) {
        val width = (contentW - indent).toInt()
        val layout = layoutOf(text, p, width)
        val c0 = canvas ?: return
        var i = 0
        var cv = c0
        while (i < layout.lineCount) {
            val top = layout.getLineTop(i)
            val h = (layout.getLineBottom(i) - top).toFloat()
            if (!room(h)) {
                newPage()
                cv = canvas ?: return
            }
            val baseline = y + (layout.getLineBaseline(i) - top)
            cv.drawText(text, layout.getLineStart(i), layout.getLineEnd(i), margin + indent, baseline, p)
            y += h
            i++
        }
    }

    fun title(text: String) {
        write(text, h1, 0f)
        spacer(6f)
    }

    fun heading(text: String) {
        spacer(8f)
        write(text, h2, 0f)
        spacer(3f)
    }

    fun paragraph(text: String) {
        write(text, body, 0f)
        spacer(4f)
    }

    fun boldLine(text: String) {
        write(text, bold, 0f)
    }

    fun note(text: String) {
        write(text, small, 0f)
    }

    fun rule() {
        val c = canvas ?: return
        spacer(2f)
        c.drawLine(margin, y, pageW - margin, y, linePaint)
        spacer(4f)
    }

    /** A simple table. `weights` gives each column's share of the page width. */
    fun table(headers: List<String>, rows: List<List<String>>, weights: List<Float>) {
        val total = weights.sum()
        val widths = weights.map { (it / total * contentW) }
        drawRow(headers, widths, bold, true)
        for (r in rows) {
            drawRow(r, widths, body, false, headers)
        }
        spacer(6f)
    }

    private fun drawRow(cells: List<String>, widths: List<Float>, p: TextPaint, isHead: Boolean, headers: List<String>? = null) {
        val pad = 4f
        val layouts = cells.mapIndexed { i, t ->
            layoutOf(t, p, (widths[i] - 2 * pad).toInt().coerceAtLeast(10))
        }
        val h = (layouts.maxOfOrNull { it.height } ?: 12) + 2 * pad
        if (!room(h)) {
            newPage()
            if (!isHead && headers != null) drawRow(headers, widths, bold, true)
        }
        val c = canvas ?: return
        if (isHead) {
            c.drawRect(margin, y, pageW - margin, y + h, headBg)
        }
        var x = margin
        for (i in layouts.indices) {
            c.save()
            c.translate(x + pad, y + pad)
            layouts[i].draw(c)
            c.restore()
            x += widths[i]
        }
        c.drawLine(margin, y + h, pageW - margin, y + h, linePaint)
        y += h
    }

    fun writeTo(out: OutputStream) {
        finishPage()
        doc.writeTo(out)
        doc.close()
    }
}

object PdfExport {
    /** Builds a PDF with `fill` and writes it to the file the person chose. Returns true on success. */
    suspend fun save(
        ctx: Context,
        uri: Uri,
        title: String,
        locale: Locale,
        fill: (PdfBuilder) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val b = PdfBuilder(ctx, title, locale)
            fill(b)
            val out = ctx.contentResolver.openOutputStream(uri)
            if (out == null) {
                false
            } else {
                out.use { b.writeTo(it) }
                true
            }
        } catch (e: Exception) {
            false
        }
    }
}
