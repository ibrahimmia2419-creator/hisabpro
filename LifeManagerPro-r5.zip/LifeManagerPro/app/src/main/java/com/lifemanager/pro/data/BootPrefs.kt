package com.lifemanager.pro.data

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

/**
 * Tiny synchronous mirror of the few settings that must be known before the first
 * screen is drawn (language, theme, PIN lock, screenshot privacy).
 * The full settings live in DataStore (see Prefs).
 */
object BootPrefs {
    private fun sp(c: Context) =
        c.applicationContext.getSharedPreferences("lmp_boot", Context.MODE_PRIVATE)

    fun lang(c: Context): String = sp(c).getString("lang", "bn") ?: "bn"
    fun theme(c: Context): String = sp(c).getString("theme", "system") ?: "system"
    fun pinEnabled(c: Context): Boolean = sp(c).getBoolean("pin", false)
    fun secure(c: Context): Boolean = sp(c).getBoolean("secure", false)

    fun setLang(c: Context, v: String) { sp(c).edit().putString("lang", v).apply() }
    fun setTheme(c: Context, v: String) { sp(c).edit().putString("theme", v).apply() }
    fun setPinEnabled(c: Context, v: Boolean) { sp(c).edit().putBoolean("pin", v).apply() }
    fun setSecure(c: Context, v: Boolean) { sp(c).edit().putBoolean("secure", v).apply() }

    /** Applies the saved theme (light/dark/system) and language to the whole app. */
    fun applyAppearance(c: Context) {
        val mode = when (theme(c)) {
            "light" -> AppCompatDelegate.MODE_NIGHT_NO
            "dark" -> AppCompatDelegate.MODE_NIGHT_YES
            else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        }
        AppCompatDelegate.setDefaultNightMode(mode)
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(lang(c)))
    }
}
