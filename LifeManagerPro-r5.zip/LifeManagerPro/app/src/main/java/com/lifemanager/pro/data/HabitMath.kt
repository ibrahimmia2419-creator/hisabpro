package com.lifemanager.pro.data

import java.time.LocalDate

data class HabitStat(
    val current: Int,
    val best: Int,
    val rate: Float,
    val total: Int,
    val doneToday: Boolean,
    val periodCount: Int,
    val periodNeed: Int
)

/**
 * Streak and completion logic. A habit is DAILY, WEEKLY (target times per week) or
 * MONTHLY (target times per month). Weeks start on Saturday, like the calendar.
 * A "period" is met when it has at least `need` completions.
 */
object HabitMath {
    fun periodKey(freq: String, day: Long): Long = when (freq) {
        "WEEKLY" -> day - ((LocalDate.ofEpochDay(day).dayOfWeek.value + 1) % 7)
        "MONTHLY" -> LocalDate.ofEpochDay(day).withDayOfMonth(1).toEpochDay()
        else -> day
    }

    fun prevKey(freq: String, key: Long): Long = when (freq) {
        "WEEKLY" -> key - 7
        "MONTHLY" -> LocalDate.ofEpochDay(key).minusMonths(1).toEpochDay()
        else -> key - 1
    }

    fun nextKey(freq: String, key: Long): Long = when (freq) {
        "WEEKLY" -> key + 7
        "MONTHLY" -> LocalDate.ofEpochDay(key).plusMonths(1).toEpochDay()
        else -> key + 1
    }

    fun need(freq: String, target: Int): Int = if (freq == "DAILY") 1 else maxOf(1, target)

    fun stat(freq: String, target: Int, days: Set<Long>, today: Long): HabitStat {
        val need = need(freq, target)

        val counts = HashMap<Long, Int>()
        for (d in days) {
            val k = periodKey(freq, d)
            counts[k] = (counts[k] ?: 0) + 1
        }
        val met = HashSet<Long>()
        for (entry in counts.entries) {
            if (entry.value >= need) met.add(entry.key)
        }

        // Best streak: start counting only at the first period of each run.
        var best = 0
        for (k in met) {
            if (met.contains(prevKey(freq, k))) continue
            var len = 0
            var cur = k
            while (met.contains(cur)) {
                len++
                cur = nextKey(freq, cur)
            }
            if (len > best) best = len
        }

        // Current streak: the running period may still be unfinished, so look back one more.
        val thisKey = periodKey(freq, today)
        var k = if (met.contains(thisKey)) thisKey else prevKey(freq, thisKey)
        var current = 0
        while (met.contains(k)) {
            current++
            k = prevKey(freq, k)
        }

        // Completion rate over the recent periods.
        val n = when (freq) {
            "WEEKLY" -> 8
            "MONTHLY" -> 6
            else -> 30
        }
        var sum = 0f
        var key = thisKey
        for (i in 0 until n) {
            val c = counts[key] ?: 0
            sum += minOf(c, need).toFloat() / need.toFloat()
            key = prevKey(freq, key)
        }

        return HabitStat(
            current = current,
            best = best,
            rate = sum / n.toFloat(),
            total = days.size,
            doneToday = days.contains(today),
            periodCount = counts[thisKey] ?: 0,
            periodNeed = need
        )
    }
}
