#!/usr/bin/env bash
# Build script used by GitHub Actions. It runs inside the unpacked LifeManagerPro folder.
# Keeping the build steps here (inside the zip) means the small workflow file never has to change.
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REPO="${GITHUB_WORKSPACE:-$(pwd)}"
cd "$SRC"

echo "== Signing key (created once, kept in the repository, so updates keep your data) =="
mkdir -p "$SRC/keystore"
if [ -f "$REPO/keystore/lmp-release.jks" ]; then
  cp "$REPO/keystore/lmp-release.jks" "$SRC/keystore/lmp-release.jks"
else
  mkdir -p "$REPO/keystore"
  keytool -genkeypair -keystore "$REPO/keystore/lmp-release.jks" -storetype PKCS12 \
    -alias lmp -keyalg RSA -keysize 2048 -validity 36500 \
    -storepass lmp-keystore-2026 -keypass lmp-keystore-2026 \
    -dname "CN=Life Manager Pro, O=Personal, C=BD"
  git -C "$REPO" config user.name "github-actions[bot]"
  git -C "$REPO" config user.email "41898282+github-actions[bot]@users.noreply.github.com"
  git -C "$REPO" add keystore/lmp-release.jks
  git -C "$REPO" commit -m "Add app signing key (created once so updates keep your data)"
  git -C "$REPO" push origin "HEAD:${GITHUB_REF_NAME}"
  cp "$REPO/keystore/lmp-release.jks" "$SRC/keystore/lmp-release.jks"
fi

echo "== Android SDK =="
SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
echo "sdk.dir=$SDK" > "$SRC/local.properties"
SDKM="$SDK/cmdline-tools/latest/bin/sdkmanager"
if [ -x "$SDKM" ]; then
  yes | "$SDKM" --licenses > /dev/null 2>&1 || true
  "$SDKM" "platforms;android-35" "build-tools;34.0.0" > /dev/null 2>&1 || true
fi

echo "== Build =="
gradle --version
LOG="$SRC/gradle.log"
set +e
gradle assembleRelease --no-daemon --stacktrace 2>&1 | tee "$LOG"
STATUS=${PIPESTATUS[0]}
set -e

if [ "$STATUS" -ne 0 ]; then
  # Show the important errors in one place (log end, Annotations box, run summary),
  # so one screenshot from a phone is enough to find the problem.
  ERRS="$SRC/key-errors.txt"
  grep -E "^e: |error: |Unresolved reference|What went wrong|Execution failed for task|FAILED$|Could not resolve|AAPT:|Cannot find|Failed to compile" "$LOG" \
    | sed 's#file://##' | awk '!seen[$0]++' | head -40 > "$ERRS" || true
  echo "================ BUILD FAILED: KEY ERRORS ================"
  cat "$ERRS" || true
  echo "================ LAST 30 LINES ================"
  tail -30 "$LOG" || true
  head -10 "$ERRS" | while IFS= read -r line; do
    line="${line//%/%25}"
    echo "::error::${line:0:450}"
  done
  {
    echo "### Build failed - key errors"
    echo '```'
    cat "$ERRS"
    echo '```'
  } >> "${GITHUB_STEP_SUMMARY:-/dev/null}"
  exit 1
fi

APK="$SRC/app/build/outputs/apk/release/app-release.apk"
cp "$APK" "$REPO/LifeManagerPro.apk"
ls -l "$REPO/LifeManagerPro.apk"

echo "== Publish on the Releases page =="
if command -v gh > /dev/null 2>&1 && [ -n "${GH_TOKEN:-}" ] && [ -n "${GITHUB_REPOSITORY:-}" ]; then
  gh release delete latest --yes --cleanup-tag -R "$GITHUB_REPOSITORY" || true
  gh release create latest "$REPO/LifeManagerPro.apk" -R "$GITHUB_REPOSITORY" \
    --title "Life Manager Pro - build ${GITHUB_RUN_NUMBER:-0}" \
    --notes "Download LifeManagerPro.apk and install it on your phone." \
    --target "${GITHUB_SHA:-HEAD}"
else
  echo "gh or GH_TOKEN not available; the APK is in the build artifact instead."
fi
echo "== Done =="
