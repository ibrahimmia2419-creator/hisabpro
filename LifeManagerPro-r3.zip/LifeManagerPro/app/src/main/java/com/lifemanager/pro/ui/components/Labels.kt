package com.lifemanager.pro.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import com.lifemanager.pro.R
import com.lifemanager.pro.ui.theme.Danger
import com.lifemanager.pro.ui.theme.Info
import com.lifemanager.pro.ui.theme.Muted
import com.lifemanager.pro.ui.theme.Success
import com.lifemanager.pro.ui.theme.Warning

@Composable
fun statusLabel(s: String): String = when (s) {
    "PENDING" -> stringResource(R.string.status_pending)
    "IN_PROGRESS" -> stringResource(R.string.status_in_progress)
    "COMPLETED" -> stringResource(R.string.status_completed)
    "CANCELLED" -> stringResource(R.string.status_cancelled)
    else -> s
}

fun statusColor(s: String): Color = when (s) {
    "PENDING" -> Warning
    "IN_PROGRESS" -> Info
    "COMPLETED" -> Success
    else -> Muted
}

@Composable
fun prioLabel(p: Int): String = when (p) {
    0 -> stringResource(R.string.prio_low)
    2 -> stringResource(R.string.prio_high)
    else -> stringResource(R.string.prio_medium)
}

fun prioColor(p: Int): Color = when (p) {
    0 -> Success
    2 -> Danger
    else -> Warning
}

/** Built-in categories are stored as keys and translated here; custom ones show as typed. */
@Composable
fun catLabel(name: String): String = when (name) {
    "personal" -> stringResource(R.string.cat_personal)
    "work" -> stringResource(R.string.cat_work)
    "study" -> stringResource(R.string.cat_study)
    "health" -> stringResource(R.string.cat_health)
    "family" -> stringResource(R.string.cat_family)
    "finance" -> stringResource(R.string.cat_finance)
    "islamic" -> stringResource(R.string.cat_islamic)
    "other" -> stringResource(R.string.cat_other)
    else -> name
}
