package com.lifemanager.pro.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lifemanager.pro.util.D
import com.lifemanager.pro.util.Fmt
import com.lifemanager.pro.util.currentLocale
import java.time.DayOfWeek
import java.time.YearMonth
import java.time.format.TextStyle

/** A simple month calendar. Weeks start on Saturday. `marked` days get a small dot. */
@Composable
fun MonthGrid(
    month: YearMonth,
    selected: Long,
    marked: Set<Long>,
    onSelect: (Long) -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit
) {
    val loc = currentLocale()
    val today = D.today()
    val first = month.atDay(1)
    val offset = (first.dayOfWeek.value + 1) % 7
    val days = month.lengthOfMonth()
    val rows = (offset + days + 6) / 7
    val order = listOf(
        DayOfWeek.SATURDAY, DayOfWeek.SUNDAY, DayOfWeek.MONDAY, DayOfWeek.TUESDAY,
        DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY
    )

    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onPrev) { Text("‹", fontSize = 26.sp) }
                Text(
                    Fmt.month(month, loc),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
                TextButton(onClick = onNext) { Text("›", fontSize = 26.sp) }
            }
            Row(Modifier.fillMaxWidth()) {
                order.forEach { d ->
                    Text(
                        d.getDisplayName(TextStyle.SHORT, loc),
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1
                    )
                }
            }
            for (r in 0 until rows) {
                Row(Modifier.fillMaxWidth()) {
                    for (c in 0 until 7) {
                        val dayNum = r * 7 + c - offset + 1
                        if (dayNum in 1..days) {
                            val ed = month.atDay(dayNum).toEpochDay()
                            DayCell(
                                label = Fmt.num(dayNum, loc),
                                selected = ed == selected,
                                isToday = ed == today,
                                marked = marked.contains(ed),
                                modifier = Modifier.weight(1f),
                                onClick = { onSelect(ed) }
                            )
                        } else {
                            Spacer(Modifier.weight(1f).height(44.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DayCell(
    label: String,
    selected: Boolean,
    isToday: Boolean,
    marked: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val primary = MaterialTheme.colorScheme.primary
    val textColor = when {
        selected -> MaterialTheme.colorScheme.onPrimary
        isToday -> primary
        else -> MaterialTheme.colorScheme.onSurface
    }
    Column(
        modifier
            .height(44.dp)
            .padding(2.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) primary else Color.Transparent)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
    ) {
        Text(
            label,
            color = textColor,
            fontWeight = if (isToday || selected) FontWeight.Bold else FontWeight.Normal
        )
        if (marked) {
            androidx.compose.foundation.layout.Box(
                Modifier
                    .size(5.dp)
                    .clip(CircleShape)
                    .background(if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.tertiary)
            )
        } else {
            Spacer(Modifier.size(5.dp))
        }
    }
}
