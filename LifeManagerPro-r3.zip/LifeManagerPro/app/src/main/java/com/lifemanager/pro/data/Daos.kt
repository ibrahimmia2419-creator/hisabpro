package com.lifemanager.pro.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

interface BaseDao<T> {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: T)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<T>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertIgnore(items: List<T>): List<Long>

    @Delete
    suspend fun delete(item: T)
}

@Dao
interface TaskDao : BaseDao<TaskEntity> {
    @Query("SELECT * FROM tasks ORDER BY epochDay ASC, startMin ASC")
    fun observeAll(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE id = :id LIMIT 1")
    suspend fun get(id: String): TaskEntity?

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun deleteById(id: String)

    @Query("SELECT * FROM tasks")
    suspend fun all(): List<TaskEntity>

    @Query("DELETE FROM tasks")
    suspend fun clear()
}

@Dao
interface CategoryDao : BaseDao<CategoryEntity> {
    @Query("SELECT * FROM categories WHERE kind = :kind AND archived = 0 ORDER BY sortOrder ASC, name ASC")
    fun observe(kind: String): Flow<List<CategoryEntity>>

    @Query("SELECT COUNT(*) FROM categories WHERE kind = :kind AND name = :name")
    suspend fun countByName(kind: String, name: String): Int

    @Query("SELECT * FROM categories")
    suspend fun all(): List<CategoryEntity>

    @Query("DELETE FROM categories")
    suspend fun clear()
}
