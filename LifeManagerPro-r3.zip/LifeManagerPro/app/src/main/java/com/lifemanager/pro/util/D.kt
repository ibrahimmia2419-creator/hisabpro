package com.lifemanager.pro.util

import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.util.UUID

/** Small date/time helpers. All "days" are stored as epoch-day numbers (Long). */
object D {
    private val zone: ZoneId get() = ZoneId.systemDefault()

    fun today(): Long = LocalDate.now().toEpochDay()
    fun now(): Long = System.currentTimeMillis()
    fun id(): String = UUID.randomUUID().toString()
    fun date(epochDay: Long): LocalDate = LocalDate.ofEpochDay(epochDay)

    fun epochDayOf(millis: Long): Long =
        Instant.ofEpochMilli(millis).atZone(zone).toLocalDate().toEpochDay()

    fun dayStartMillis(epochDay: Long): Long =
        LocalDate.ofEpochDay(epochDay).atStartOfDay(zone).toInstant().toEpochMilli()

    /** Machine-readable month key such as 2026-11 (never localised). */
    fun monthKey(epochDay: Long): String = YearMonth.from(LocalDate.ofEpochDay(epochDay)).toString()
}
