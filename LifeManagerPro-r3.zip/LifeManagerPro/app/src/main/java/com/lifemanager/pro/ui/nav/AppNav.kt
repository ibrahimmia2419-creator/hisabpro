package com.lifemanager.pro.ui.nav

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.lifemanager.pro.R
import com.lifemanager.pro.ui.screens.HomeScreen
import com.lifemanager.pro.ui.screens.MoreScreen
import com.lifemanager.pro.ui.screens.PlannerScreen
import com.lifemanager.pro.ui.screens.SettingsScreen
import com.lifemanager.pro.ui.screens.TaskEditScreen

object Routes {
    const val HOME = "home"
    const val PLANNER = "planner"
    const val MORE = "more"
    const val SETTINGS = "settings"
    const val TASK_EDIT = "task_edit/{id}?day={day}"

    fun taskEdit(id: String, day: Long = -1L): String = "task_edit/$id?day=$day"
}

private data class TabItem(val route: String, val label: Int, val emoji: String)

fun NavHostController.goTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

@Composable
fun AppRoot() {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val tabs = listOf(
        TabItem(Routes.HOME, R.string.nav_home, "🏠"),
        TabItem(Routes.PLANNER, R.string.nav_planner, "🗓️"),
        TabItem(Routes.MORE, R.string.nav_more, "☰")
    )
    val showBar = tabs.any { it.route == route }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        bottomBar = {
            if (showBar) {
                NavigationBar {
                    tabs.forEach { t ->
                        NavigationBarItem(
                            selected = route == t.route,
                            onClick = { nav.goTab(t.route) },
                            icon = { Text(t.emoji, fontSize = 20.sp) },
                            label = { Text(stringResource(t.label)) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = Routes.HOME,
            modifier = Modifier.padding(padding)
        ) {
            composable(Routes.HOME) { HomeScreen(nav) }
            composable(Routes.PLANNER) { PlannerScreen(nav) }
            composable(Routes.MORE) { MoreScreen(nav) }
            composable(Routes.SETTINGS) { SettingsScreen(nav) }
            composable(
                route = Routes.TASK_EDIT,
                arguments = listOf(
                    navArgument("id") { type = NavType.StringType },
                    navArgument("day") {
                        type = NavType.LongType
                        defaultValue = -1L
                    }
                )
            ) { backStackEntry ->
                TaskEditScreen(
                    nav = nav,
                    id = backStackEntry.arguments?.getString("id") ?: "new",
                    presetDay = backStackEntry.arguments?.getLong("day") ?: -1L
                )
            }
        }
    }
}
