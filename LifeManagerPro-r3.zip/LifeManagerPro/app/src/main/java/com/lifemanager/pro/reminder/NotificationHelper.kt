package com.lifemanager.pro.reminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import com.lifemanager.pro.R

object NotificationHelper {
    const val CH_REMINDERS = "reminders"
    const val CH_FOCUS = "focus"
    const val CH_GENERAL = "general"

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val reminders = NotificationChannel(
            CH_REMINDERS, ctx.getString(R.string.ch_reminders), NotificationManager.IMPORTANCE_HIGH
        )
        reminders.description = ctx.getString(R.string.ch_reminders_desc)
        nm.createNotificationChannel(reminders)

        val focus = NotificationChannel(
            CH_FOCUS, ctx.getString(R.string.ch_focus), NotificationManager.IMPORTANCE_DEFAULT
        )
        focus.description = ctx.getString(R.string.ch_focus_desc)
        nm.createNotificationChannel(focus)

        val general = NotificationChannel(
            CH_GENERAL, ctx.getString(R.string.ch_general), NotificationManager.IMPORTANCE_LOW
        )
        general.description = ctx.getString(R.string.ch_general_desc)
        nm.createNotificationChannel(general)
    }
}
