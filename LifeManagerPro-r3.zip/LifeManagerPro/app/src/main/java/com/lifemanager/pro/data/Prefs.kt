package com.lifemanager.pro.data

import android.content.Context
import android.util.Base64
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.security.MessageDigest
import java.security.SecureRandom

private val Context.lmpStore: DataStore<Preferences> by preferencesDataStore(name = "lmp_settings")

data class AppSettings(
    val lang: String = "bn",
    val theme: String = "system",
    val userName: String = "",
    val biometric: Boolean = false,
    val secure: Boolean = false,
    val pinSet: Boolean = false,
    val focusMin: Int = 25,
    val breakMin: Int = 5,
    val quranGoal: Int = 10,
    val wTask: Int = 40,
    val wHabit: Int = 30,
    val wGoal: Int = 20,
    val wPlan: Int = 10,
    val autoBackup: Boolean = false
)

private object K {
    val LANG = stringPreferencesKey("lang")
    val THEME = stringPreferencesKey("theme")
    val NAME = stringPreferencesKey("user_name")
    val BIO = booleanPreferencesKey("biometric")
    val SECURE = booleanPreferencesKey("secure")
    val PIN_HASH = stringPreferencesKey("pin_hash")
    val PIN_SALT = stringPreferencesKey("pin_salt")
    val FOCUS = intPreferencesKey("focus_min")
    val BREAK = intPreferencesKey("break_min")
    val QURAN = intPreferencesKey("quran_goal")
    val W_TASK = intPreferencesKey("w_task")
    val W_HABIT = intPreferencesKey("w_habit")
    val W_GOAL = intPreferencesKey("w_goal")
    val W_PLAN = intPreferencesKey("w_plan")
    val AUTO_BACKUP = booleanPreferencesKey("auto_backup")
}

class Prefs(context: Context) {
    private val ctx: Context = context.applicationContext
    private val store: DataStore<Preferences> get() = ctx.lmpStore

    val settings: Flow<AppSettings> = store.data.map { p ->
        AppSettings(
            lang = p[K.LANG] ?: BootPrefs.lang(ctx),
            theme = p[K.THEME] ?: BootPrefs.theme(ctx),
            userName = p[K.NAME] ?: "",
            biometric = p[K.BIO] ?: false,
            secure = p[K.SECURE] ?: false,
            pinSet = (p[K.PIN_HASH] ?: "").isNotEmpty(),
            focusMin = p[K.FOCUS] ?: 25,
            breakMin = p[K.BREAK] ?: 5,
            quranGoal = p[K.QURAN] ?: 10,
            wTask = p[K.W_TASK] ?: 40,
            wHabit = p[K.W_HABIT] ?: 30,
            wGoal = p[K.W_GOAL] ?: 20,
            wPlan = p[K.W_PLAN] ?: 10,
            autoBackup = p[K.AUTO_BACKUP] ?: false
        )
    }

    suspend fun setLang(v: String) {
        store.edit { it[K.LANG] = v }
        BootPrefs.setLang(ctx, v)
    }

    suspend fun setTheme(v: String) {
        store.edit { it[K.THEME] = v }
        BootPrefs.setTheme(ctx, v)
    }

    suspend fun setName(v: String) {
        store.edit { it[K.NAME] = v }
    }

    suspend fun setBiometric(v: Boolean) {
        store.edit { it[K.BIO] = v }
    }

    suspend fun setSecure(v: Boolean) {
        store.edit { it[K.SECURE] = v }
        BootPrefs.setSecure(ctx, v)
    }

    suspend fun setFocusBreak(focus: Int, brk: Int) {
        store.edit {
            it[K.FOCUS] = focus
            it[K.BREAK] = brk
        }
    }

    suspend fun setQuranGoal(v: Int) {
        store.edit { it[K.QURAN] = v }
    }

    suspend fun setWeights(task: Int, habit: Int, goal: Int, plan: Int) {
        store.edit {
            it[K.W_TASK] = task
            it[K.W_HABIT] = habit
            it[K.W_GOAL] = goal
            it[K.W_PLAN] = plan
        }
    }

    suspend fun setAutoBackup(v: Boolean) {
        store.edit { it[K.AUTO_BACKUP] = v }
    }

    // ---------- PIN lock ----------

    suspend fun setPin(pin: String) {
        val salt = ByteArray(16)
        SecureRandom().nextBytes(salt)
        val saltStr = Base64.encodeToString(salt, Base64.NO_WRAP)
        val hashed = hash(saltStr, pin)
        store.edit {
            it[K.PIN_SALT] = saltStr
            it[K.PIN_HASH] = hashed
        }
        BootPrefs.setPinEnabled(ctx, true)
    }

    suspend fun clearPin() {
        store.edit {
            it.remove(K.PIN_HASH)
            it.remove(K.PIN_SALT)
            it[K.BIO] = false
        }
        BootPrefs.setPinEnabled(ctx, false)
    }

    suspend fun verifyPin(pin: String): Boolean {
        val p = store.data.first()
        val salt = p[K.PIN_SALT] ?: return false
        val saved = p[K.PIN_HASH] ?: return false
        return hash(salt, pin) == saved
    }

    private fun hash(salt: String, pin: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val bytes = md.digest((salt + ":" + pin).toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }
}
