package com.lifemanager.pro

import android.app.Application
import com.lifemanager.pro.data.BootPrefs
import com.lifemanager.pro.data.Graph
import com.lifemanager.pro.reminder.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class LifeApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Graph.init(this)
        BootPrefs.applyAppearance(this)
        NotificationHelper.createChannels(this)
        CoroutineScope(SupervisorJob() + Dispatchers.IO).launch {
            Graph.repo.seedDefaults()
        }
    }
}
