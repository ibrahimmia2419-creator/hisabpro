package com.lifemanager.pro.data

import com.lifemanager.pro.util.D
import kotlinx.coroutines.flow.Flow

class Repository(private val db: LifeDatabase) {

    // ---------- Tasks ----------
    val tasks: Flow<List<TaskEntity>> = db.taskDao().observeAll()

    suspend fun getTask(id: String): TaskEntity? = db.taskDao().get(id)

    suspend fun saveTask(t: TaskEntity) {
        db.taskDao().upsert(t)
    }

    suspend fun deleteTask(id: String) {
        db.taskDao().deleteById(id)
    }

    suspend fun setTaskStatus(t: TaskEntity, status: String) {
        val now = D.now()
        val completedAt = if (status == "COMPLETED") now else 0L
        db.taskDao().upsert(t.copy(status = status, completedAt = completedAt, updatedAt = now))
    }

    // ---------- Categories ----------
    fun categories(kind: String): Flow<List<CategoryEntity>> = db.categoryDao().observe(kind)

    suspend fun addCategory(kind: String, name: String, emoji: String = "🏷️") {
        val clean = name.trim()
        if (clean.isEmpty()) return
        if (db.categoryDao().countByName(kind, clean) > 0) return
        db.categoryDao().upsert(
            CategoryEntity(
                id = D.id(), kind = kind, name = clean, emoji = emoji,
                custom = true, archived = false, sortOrder = 100
            )
        )
    }

    /** Safe to call on every start: uses fixed ids and IGNORE, so it never duplicates. */
    suspend fun seedDefaults() {
        val taskCats = listOf(
            "personal" to "👤", "work" to "💼", "study" to "📚", "health" to "💪",
            "family" to "👪", "finance" to "💰", "islamic" to "🕌", "other" to "🏷️"
        )
        val list = taskCats.mapIndexed { i, pair ->
            CategoryEntity(
                id = "cat_TASK_" + pair.first, kind = "TASK", name = pair.first,
                emoji = pair.second, custom = false, archived = false, sortOrder = i
            )
        }
        db.categoryDao().insertIgnore(list)
    }
}
