package com.lifemanager.pro.ui.screens

import android.app.Application
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.lifemanager.pro.R
import com.lifemanager.pro.data.AppSettings
import com.lifemanager.pro.data.GoalEntity
import com.lifemanager.pro.data.Graph
import com.lifemanager.pro.data.HabitEntity
import com.lifemanager.pro.data.HabitLogEntity
import com.lifemanager.pro.data.ReminderEntity
import com.lifemanager.pro.data.TaskEntity
import com.lifemanager.pro.ui.components.AppCard
import com.lifemanager.pro.ui.components.AppScaffold
import com.lifemanager.pro.ui.components.CheckCircle
import com.lifemanager.pro.ui.components.ProgressBar
import com.lifemanager.pro.ui.components.ProgressRing
import com.lifemanager.pro.ui.components.SectionTitle
import com.lifemanager.pro.ui.components.StatTile
import com.lifemanager.pro.ui.components.goalCatEmoji
import com.lifemanager.pro.ui.components.prioColor
import com.lifemanager.pro.ui.nav.Routes
import com.lifemanager.pro.ui.nav.goTab
import com.lifemanager.pro.ui.theme.Brand
import com.lifemanager.pro.ui.theme.BrandLight
import com.lifemanager.pro.ui.theme.Info
import com.lifemanager.pro.ui.theme.Success
import com.lifemanager.pro.ui.theme.Warning
import com.lifemanager.pro.util.D
import com.lifemanager.pro.util.Fmt
import com.lifemanager.pro.util.currentLocale
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalTime
import java.util.Locale

class HomeViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Graph.repo

    private val dayFlow: Flow<Long> = flow {
        while (true) {
            emit(D.today())
            delay(30_000L)
        }
    }.distinctUntilChanged()

    val today: StateFlow<Long> = dayFlow.stateIn(viewModelScope, SharingStarted.Eagerly, D.today())

    val todayTasks: StateFlow<List<TaskEntity>> =
        combine(repo.tasks, dayFlow) { all, d ->
            all.filter { it.epochDay == d }
                .sortedBy { if (it.startMin < 0) 1440 else it.startMin }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    val upcoming: StateFlow<List<TaskEntity>> =
        combine(repo.tasks, dayFlow) { all, d ->
            all.filter {
                it.epochDay > d && it.epochDay <= d + 7 &&
                    it.status != "COMPLETED" && it.status != "CANCELLED"
            }
                .sortedWith(compareBy<TaskEntity>({ it.epochDay }, { it.startMin }))
                .take(5)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    val habits: StateFlow<List<HabitEntity>> =
        repo.habits.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    val habitLogs: StateFlow<List<HabitLogEntity>> =
        repo.habitLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    val goals: StateFlow<List<GoalEntity>> =
        repo.goals.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    val reminders: StateFlow<List<ReminderEntity>> =
        repo.reminders.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000L), emptyList())

    fun toggle(t: TaskEntity) {
        viewModelScope.launch {
            repo.setTaskStatus(t, if (t.status == "COMPLETED") "PENDING" else "COMPLETED")
        }
    }

    fun toggleHabit(habitId: String) {
        viewModelScope.launch { repo.toggleHabit(habitId, D.today()) }
    }
}

@Composable
fun HomeScreen(nav: NavHostController, vm: HomeViewModel = viewModel()) {
    val settings by Graph.prefs.settings.collectAsState(initial = AppSettings())
    val tasks by vm.todayTasks.collectAsState()
    val upcoming by vm.upcoming.collectAsState()
    val today by vm.today.collectAsState()
    val habits by vm.habits.collectAsState()
    val habitLogs by vm.habitLogs.collectAsState()
    val goals by vm.goals.collectAsState()
    val reminders by vm.reminders.collectAsState()
    val loc = currentLocale()

    val active = tasks.filter { it.status != "CANCELLED" }
    val done = active.count { it.status == "COMPLETED" }
    val total = active.size
    val inProgress = active.count { it.status == "IN_PROGRESS" }
    val pending = total - done - inProgress
    val progress = if (total == 0) 0f else done.toFloat() / total.toFloat()
    val byHabit = remember(habitLogs) { daysByHabit(habitLogs) }

    AppScaffold(
        title = stringResource(R.string.app_name),
        tab = true,
        actions = {
            IconButton(onClick = { nav.navigate(Routes.SETTINGS) }) {
                Icon(Icons.Default.Settings, contentDescription = null)
            }
        }
    ) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { GreetingCard(settings.userName, today, loc) }
            item { ProgressCard(progress, done, total, pending, inProgress, loc) }
            item {
                TodayCard(
                    tasks = tasks,
                    loc = loc,
                    onToggle = { t -> vm.toggle(t) },
                    onOpen = { t -> nav.navigate(Routes.taskEdit(t.id)) },
                    onAdd = { nav.navigate(Routes.taskEdit("new")) },
                    onAll = { nav.goTab(Routes.PLANNER) }
                )
            }
            item {
                HabitsHomeCard(
                    habits = habits,
                    byHabit = byHabit,
                    today = today,
                    loc = loc,
                    onToggle = { h -> vm.toggleHabit(h.id) },
                    onAll = { nav.goTab(Routes.HABITS) },
                    onAdd = { nav.navigate(Routes.habitEdit("new")) }
                )
            }
            item {
                GoalsHomeCard(
                    goals = goals,
                    loc = loc,
                    onOpen = { g -> nav.navigate(Routes.goalDetail(g.id)) },
                    onAll = { nav.goTab(Routes.GOALS) }
                )
            }
            item {
                RemindersHomeCard(
                    reminders = reminders,
                    loc = loc,
                    onAll = { nav.navigate(Routes.REMINDERS) }
                )
            }
            if (upcoming.isNotEmpty()) {
                item {
                    UpcomingCard(
                        tasks = upcoming,
                        loc = loc,
                        onOpen = { t -> nav.navigate(Routes.taskEdit(t.id)) }
                    )
                }
            }
        }
    }
}

@Composable
private fun GreetingCard(name: String, today: Long, loc: Locale) {
    val hour = LocalTime.now().hour
    val greet = when (hour) {
        in 5..11 -> R.string.greet_morning
        in 12..14 -> R.string.greet_noon
        in 15..17 -> R.string.greet_afternoon
        in 18..19 -> R.string.greet_evening
        else -> R.string.greet_night
    }
    val suffix = if (name.isNotBlank()) ", " + name.trim() else ""
    val title = stringResource(greet) + suffix
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(Brand, BrandLight)))
            .padding(20.dp)
    ) {
        Column {
            Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(
                Fmt.dateLong(today, loc),
                color = Color.White.copy(alpha = 0.88f),
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun ProgressCard(
    progress: Float,
    done: Int,
    total: Int,
    pending: Int,
    inProgress: Int,
    loc: Locale
) {
    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            SectionTitle(stringResource(R.string.home_progress))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                ProgressRing(progress = progress, diameter = 96.dp, label = Fmt.percent(progress, loc))
                Column(Modifier.weight(1f)) {
                    if (total == 0) {
                        Text(
                            stringResource(R.string.home_no_tasks),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        Text(
                            stringResource(
                                R.string.home_tasks_done,
                                Fmt.num(done, loc),
                                Fmt.num(total, loc)
                            ),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile(Fmt.num(done, loc), stringResource(R.string.stat_completed), Success, Modifier.weight(1f))
                StatTile(Fmt.num(pending, loc), stringResource(R.string.stat_pending), Warning, Modifier.weight(1f))
                StatTile(Fmt.num(inProgress, loc), stringResource(R.string.stat_progress), Info, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun TodayCard(
    tasks: List<TaskEntity>,
    loc: Locale,
    onToggle: (TaskEntity) -> Unit,
    onOpen: (TaskEntity) -> Unit,
    onAdd: () -> Unit,
    onAll: () -> Unit
) {
    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SectionTitle(stringResource(R.string.tab_today), Modifier.weight(1f))
                TextButton(onClick = onAll) { Text(stringResource(R.string.home_see_all)) }
            }
            if (tasks.isEmpty()) {
                Text(
                    stringResource(R.string.home_no_tasks),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                tasks.take(6).forEach { t ->
                    MiniTaskRow(t, loc, { onToggle(t) }, { onOpen(t) })
                }
            }
            Spacer(Modifier.height(4.dp))
            Button(onClick = onAdd, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.size(8.dp))
                Text(stringResource(R.string.home_add_task))
            }
        }
    }
}

@Composable
private fun HabitsHomeCard(
    habits: List<HabitEntity>,
    byHabit: Map<String, Set<Long>>,
    today: Long,
    loc: Locale,
    onToggle: (HabitEntity) -> Unit,
    onAll: () -> Unit,
    onAdd: () -> Unit
) {
    val active = habits.filter { !it.archived }
    val done = active.count { byHabit[it.id]?.contains(today) == true }
    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SectionTitle(stringResource(R.string.home_habits), Modifier.weight(1f))
                if (active.isNotEmpty()) {
                    Text(
                        Fmt.num(done, loc) + "/" + Fmt.num(active.size, loc),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                TextButton(onClick = onAll) { Text(stringResource(R.string.home_see_all)) }
            }
            if (active.isEmpty()) {
                Text(
                    stringResource(R.string.home_habits_none),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedButton(onClick = onAdd) { Text(stringResource(R.string.habit_new)) }
            } else {
                active.take(5).forEach { h ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(h.emoji, fontSize = 22.sp)
                        Spacer(Modifier.size(10.dp))
                        Text(
                            h.name,
                            modifier = Modifier.weight(1f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        CheckCircle(
                            done = byHabit[h.id]?.contains(today) == true,
                            onClick = { onToggle(h) },
                            diameter = 32.dp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun GoalsHomeCard(
    goals: List<GoalEntity>,
    loc: Locale,
    onOpen: (GoalEntity) -> Unit,
    onAll: () -> Unit
) {
    val active = goals
        .filter { !it.archived && it.status == "ACTIVE" }
        .sortedBy { if (it.targetEpochDay > 0L) it.targetEpochDay else Long.MAX_VALUE }
        .take(3)
    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SectionTitle(stringResource(R.string.home_goals), Modifier.weight(1f))
                TextButton(onClick = onAll) { Text(stringResource(R.string.home_see_all)) }
            }
            if (active.isEmpty()) {
                Text(
                    stringResource(R.string.home_goals_none),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                active.forEach { g ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onOpen(g) }
                            .padding(vertical = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                goalCatEmoji(g.category) + " " + g.title,
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(Fmt.num(g.progress, loc) + "%", fontWeight = FontWeight.Bold)
                        }
                        ProgressBar(g.progress / 100f)
                    }
                }
            }
        }
    }
}

@Composable
private fun RemindersHomeCard(reminders: List<ReminderEntity>, loc: Locale, onAll: () -> Unit) {
    val now = System.currentTimeMillis()
    val next = reminders.filter { it.enabled && it.triggerAt > now }.sortedBy { it.triggerAt }.take(3)
    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SectionTitle(stringResource(R.string.home_reminders), Modifier.weight(1f))
                TextButton(onClick = onAll) { Text(stringResource(R.string.home_see_all)) }
            }
            if (next.isEmpty()) {
                Text(
                    stringResource(R.string.home_reminders_none),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                next.forEach { r ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("⏰", fontSize = 20.sp)
                        Spacer(Modifier.size(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(r.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                Fmt.date(D.epochDayOf(r.triggerAt), loc) + " · " + Fmt.time(D.minuteOfDay(r.triggerAt), loc),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun UpcomingCard(tasks: List<TaskEntity>, loc: Locale, onOpen: (TaskEntity) -> Unit) {
    AppCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            SectionTitle(stringResource(R.string.home_upcoming_tasks))
            tasks.forEach { t ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onOpen(t) }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(prioColor(t.priority))
                    )
                    Spacer(Modifier.size(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            Fmt.date(t.epochDay, loc),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MiniTaskRow(t: TaskEntity, loc: Locale, onToggle: () -> Unit, onOpen: () -> Unit) {
    val done = t.status == "COMPLETED"
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onOpen() },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(checked = done, onCheckedChange = { onToggle() })
        Column(Modifier.weight(1f)) {
            Text(
                t.title,
                textDecoration = if (done) TextDecoration.LineThrough else TextDecoration.None,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (t.startMin >= 0) {
                Text(
                    Fmt.time(t.startMin, loc),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Box(
            Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(prioColor(t.priority))
        )
        Spacer(Modifier.size(6.dp))
    }
}
