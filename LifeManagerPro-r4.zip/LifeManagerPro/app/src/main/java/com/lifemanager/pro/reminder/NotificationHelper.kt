package com.lifemanager.pro.reminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.lifemanager.pro.MainActivity
import com.lifemanager.pro.R
import com.lifemanager.pro.data.BootPrefs
import com.lifemanager.pro.data.ReminderEntity
import java.util.Locale

object NotificationHelper {
    const val CH_REMINDERS = "reminders"
    const val CH_FOCUS = "focus"
    const val CH_GENERAL = "general"

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val reminders = NotificationChannel(
            CH_REMINDERS, ctx.getString(R.string.ch_reminders), NotificationManager.IMPORTANCE_HIGH
        )
        reminders.description = ctx.getString(R.string.ch_reminders_desc)
        nm.createNotificationChannel(reminders)

        val focus = NotificationChannel(
            CH_FOCUS, ctx.getString(R.string.ch_focus), NotificationManager.IMPORTANCE_DEFAULT
        )
        focus.description = ctx.getString(R.string.ch_focus_desc)
        nm.createNotificationChannel(focus)

        val general = NotificationChannel(
            CH_GENERAL, ctx.getString(R.string.ch_general), NotificationManager.IMPORTANCE_LOW
        )
        general.description = ctx.getString(R.string.ch_general_desc)
        nm.createNotificationChannel(general)
    }

    /** A context that uses the language chosen inside the app (for text shown by notifications). */
    fun localized(ctx: Context): Context {
        val conf = Configuration(ctx.resources.configuration)
        conf.setLocale(Locale.forLanguageTag(BootPrefs.lang(ctx)))
        return ctx.createConfigurationContext(conf)
    }

    fun showReminder(ctx: Context, r: ReminderEntity, missed: Boolean) {
        val lc = localized(ctx)
        val open = Intent(ctx, MainActivity::class.java)
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(
            ctx, r.id.hashCode(), open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val text = if (r.note.isNotBlank()) {
            r.note
        } else {
            lc.getString(if (missed) R.string.notif_missed else R.string.notif_reminder)
        }
        val n = NotificationCompat.Builder(ctx, CH_REMINDERS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(r.title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(r.id.hashCode(), n)
        } catch (e: SecurityException) {
            // Notifications are not allowed; nothing else to do.
        }
    }
}
