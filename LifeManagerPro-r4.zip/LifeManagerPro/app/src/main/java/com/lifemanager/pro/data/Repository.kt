package com.lifemanager.pro.data

import com.lifemanager.pro.util.D
import kotlinx.coroutines.flow.Flow

class Repository(private val db: LifeDatabase) {

    // ---------- Tasks ----------
    val tasks: Flow<List<TaskEntity>> = db.taskDao().observeAll()

    suspend fun getTask(id: String): TaskEntity? = db.taskDao().get(id)

    suspend fun saveTask(t: TaskEntity) {
        db.taskDao().upsert(t)
    }

    suspend fun deleteTask(id: String) {
        db.taskDao().deleteById(id)
    }

    suspend fun setTaskStatus(t: TaskEntity, status: String) {
        val now = D.now()
        val completedAt = if (status == "COMPLETED") now else 0L
        db.taskDao().upsert(t.copy(status = status, completedAt = completedAt, updatedAt = now))
    }

    // ---------- Habits ----------
    val habits: Flow<List<HabitEntity>> = db.habitDao().observeAll()
    val habitLogs: Flow<List<HabitLogEntity>> = db.habitLogDao().observeAll()

    suspend fun getHabit(id: String): HabitEntity? = db.habitDao().get(id)

    suspend fun saveHabit(h: HabitEntity) {
        db.habitDao().upsert(h)
    }

    /** Marks / unmarks a habit for one day. The log id is fixed, so it can never be duplicated. */
    suspend fun toggleHabit(habitId: String, day: Long) {
        val id = habitId + "|" + day
        val dao = db.habitLogDao()
        if (dao.exists(id) > 0) {
            dao.deleteById(id)
        } else {
            dao.upsert(HabitLogEntity(id = id, habitId = habitId, epochDay = day, createdAt = D.now()))
        }
    }

    // ---------- Goals ----------
    val goals: Flow<List<GoalEntity>> = db.goalDao().observeAll()
    val milestones: Flow<List<MilestoneEntity>> = db.milestoneDao().observeAll()
    val goalLogs: Flow<List<GoalLogEntity>> = db.goalLogDao().observeAll()

    suspend fun getGoal(id: String): GoalEntity? = db.goalDao().get(id)

    suspend fun saveGoal(g: GoalEntity) {
        db.goalDao().upsert(g)
    }

    suspend fun addGoalLog(goalId: String, progress: Int, note: String = "") {
        db.goalLogDao().upsert(
            GoalLogEntity(
                id = D.id(), goalId = goalId, epochDay = D.today(),
                progress = progress, note = note, createdAt = D.now()
            )
        )
    }

    /** Changes a goal's progress and keeps a history entry, so earlier progress is never lost. */
    suspend fun setGoalProgress(g: GoalEntity, progress: Int) {
        val p = progress.coerceIn(0, 100)
        val status = when {
            p >= 100 -> "COMPLETED"
            g.status == "COMPLETED" -> "ACTIVE"
            else -> g.status
        }
        db.goalDao().upsert(g.copy(progress = p, status = status, updatedAt = D.now()))
        addGoalLog(g.id, p)
    }

    suspend fun saveMilestone(m: MilestoneEntity) {
        db.milestoneDao().upsert(m)
    }

    suspend fun deleteMilestone(id: String) {
        db.milestoneDao().deleteById(id)
    }

    /** When a goal has milestones, its progress follows the finished milestones. */
    suspend fun recomputeGoalFromMilestones(goalId: String) {
        val g = db.goalDao().get(goalId) ?: return
        val ms = db.milestoneDao().forGoal(goalId)
        if (ms.isEmpty()) return
        val p = 100 * ms.count { it.done } / ms.size
        if (p != g.progress) setGoalProgress(g, p)
    }

    // ---------- Reminders ----------
    val reminders: Flow<List<ReminderEntity>> = db.reminderDao().observeAll()

    suspend fun getReminder(id: String): ReminderEntity? = db.reminderDao().get(id)

    suspend fun allReminders(): List<ReminderEntity> = db.reminderDao().all()

    suspend fun saveReminder(r: ReminderEntity) {
        db.reminderDao().upsert(r)
    }

    suspend fun deleteReminder(id: String) {
        db.reminderDao().deleteById(id)
    }

    // ---------- Categories ----------
    fun categories(kind: String): Flow<List<CategoryEntity>> = db.categoryDao().observe(kind)

    suspend fun addCategory(kind: String, name: String, emoji: String = "🏷️") {
        val clean = name.trim()
        if (clean.isEmpty()) return
        if (db.categoryDao().countByName(kind, clean) > 0) return
        db.categoryDao().upsert(
            CategoryEntity(
                id = D.id(), kind = kind, name = clean, emoji = emoji,
                custom = true, archived = false, sortOrder = 100
            )
        )
    }

    /** Safe to call on every start: uses fixed ids and IGNORE, so it never duplicates. */
    suspend fun seedDefaults() {
        val taskCats = listOf(
            "personal" to "👤", "work" to "💼", "study" to "📚", "health" to "💪",
            "family" to "👪", "finance" to "💰", "islamic" to "🕌", "other" to "🏷️"
        )
        val list = taskCats.mapIndexed { i, pair ->
            CategoryEntity(
                id = "cat_TASK_" + pair.first, kind = "TASK", name = pair.first,
                emoji = pair.second, custom = false, archived = false, sortOrder = i
            )
        }
        db.categoryDao().insertIgnore(list)
    }
}
